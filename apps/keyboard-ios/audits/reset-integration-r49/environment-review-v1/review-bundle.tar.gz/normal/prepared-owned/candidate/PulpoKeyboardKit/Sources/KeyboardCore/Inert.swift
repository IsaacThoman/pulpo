// owned inert marker candidate; never compiled
