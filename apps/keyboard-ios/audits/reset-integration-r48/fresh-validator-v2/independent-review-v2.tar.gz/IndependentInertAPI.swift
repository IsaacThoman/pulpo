import Foundation
public struct KeyPoint { public let x:Double; public let y:Double; public init(x:Double,y:Double){fatalError("declaration only")} }
public struct TypedWord { public init(text:String,taps:[KeyPoint?]){fatalError("declaration only")} }
public struct LetterGeometry { public static var qwerty:Self{fatalError("declaration only")}; public func center(_ b:UInt8)->KeyPoint?{fatalError("declaration only")} }
public enum LearningPersistenceResult:String {case ok,busy,capacity,invalid,io,uncertain,cleanup}
public final class TouchModel {
 public init(url:URL?){fatalError("declaration only")}
 public var weight:Double{fatalError("declaration only")}
 public var offsets:[KeyPoint]{fatalError("declaration only")}
 public var persistenceResult:LearningPersistenceResult{fatalError("declaration only")}
 public var isLearning:Bool{get{fatalError("declaration only")}set{fatalError("declaration only")}}
 public func learn(_ w:TypedWord,intended:String,geometry:LetterGeometry)->Bool{fatalError("declaration only")}
 public func save(inBackground:Bool=false)->Bool{fatalError("declaration only")}
 public func reloadIfChangedOnDisk()->Bool{fatalError("declaration only")}
}
public enum TextNormalizer {public static func key(_ s:String)->String{fatalError("declaration only")}}
