#!/usr/bin/env python3
"""Validate all retained synthetic reports with the local dependency-free subset
of JSON Schema keywords used by report-schema.json (not a raw evaluator).
"""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent

def same(a,b):
 if isinstance(a,bool) or isinstance(b,bool):return type(a) is type(b) and a==b
 if type(a) is dict and type(b) is dict:return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
 if type(a) is list and type(b) is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b

def valid(value,schema):
 allowed={'$schema','$comment','type','oneOf','const','enum','properties','additionalProperties','required','items','uniqueItems','minimum','minLength'}
 if not set(schema)<=allowed:raise RuntimeError('unsupported report schema keyword')
 if 'oneOf' in schema and sum(valid(value,x) for x in schema['oneOf'])!=1:return False
 if 'const' in schema and not same(value,schema['const']):return False
 if 'enum' in schema and not any(same(value,x) for x in schema['enum']):return False
 if 'type' in schema:
  choices=schema['type'] if isinstance(schema['type'],list) else [schema['type']]
  actual={dict:'object',list:'array',str:'string',bool:'boolean',int:'integer',float:'number',type(None):'null'}.get(type(value))
  if actual not in choices and not (actual=='integer' and 'number' in choices):return False
 if type(value) is dict:
  if not set(schema.get('required',[]))<=set(value):return False
  props=schema.get('properties',{})
  if schema.get('additionalProperties') is False and not set(value)<=set(props):return False
  if not all(valid(v,props[k]) for k,v in value.items() if k in props):return False
 if type(value) is list:
  if 'items' in schema and not all(valid(v,schema['items']) for v in value):return False
  if schema.get('uniqueItems') and len(set(json.dumps(v,sort_keys=True) for v in value))!=len(value):return False
 if 'minimum' in schema and value<schema['minimum']:return False
 if 'minLength' in schema and len(value)<schema['minLength']:return False
 return True

def main():
 schema=json.loads((D/'report-schema.json').read_text());count=0
 for name in ('adversarial-results.json','accounting-results.json'):
  source=json.loads((D/name).read_text())
  for record in source['results']:
   if not valid(record['report'],schema):raise RuntimeError('report schema: '+name+' '+record['id'])
   count+=1
 result={'result':'pass','reports_validated':count,'schema_sha256':hashlib.sha256((D/'report-schema.json').read_bytes()).hexdigest(),'synthetic_only':True}
 (D/'report-schema-results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
