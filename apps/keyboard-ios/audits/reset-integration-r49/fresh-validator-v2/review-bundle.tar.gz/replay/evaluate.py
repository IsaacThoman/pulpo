#!/usr/bin/env python3
"""Standalone strict evaluator. No product imports, calls or external dependencies.
Exit 0 = complete pass; 1 = well-formed failed/unavailable workload;
2 = corrupt data, invalid binding, incomplete accounting or malformed schema.
The operation and check denominators always include unavailable/unfired records.
"""
from pathlib import Path
import hashlib,json,math,re,sys
D=Path(__file__).resolve().parent
class Invalid(Exception):pass

def require(ok,message):
 if not ok:raise Invalid(message)
def pairs(items):
 out={}
 for k,v in items:
  require(k not in out,'duplicate JSON key: '+k);out[k]=v
 return out
def reject_constant(s):raise Invalid('nonfinite JSON constant: '+s)
def load(path):
 try:
  value=json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject_constant)
 except (ValueError,UnicodeError,OSError,OverflowError) as e:raise Invalid('JSON input: '+str(e))
 def visit(v):
  if isinstance(v,str):
   try:v.encode('utf-8')
   except UnicodeError:raise Invalid('unpaired Unicode surrogate')
  elif isinstance(v,float):require(math.isfinite(v),'nonfinite JSON number')
  elif isinstance(v,list):
   for x in v:visit(x)
  elif isinstance(v,dict):
   for k,x in v.items():visit(k);visit(x)
 visit(value);return value

def exact_keys(v,keys,where):require(type(v) is dict and set(v)==set(keys),where+': exact keys required')
def number(v,where):require(type(v) in (int,float) and math.isfinite(v),where+': finite numeric required')
def point(v,where,tags=False):
 exact_keys(v,['x','y'],where)
 for k in ('x','y'):
  if tags and type(v[k]) is str:require(v[k] in ('nan','posInf','negInf'),where+': invalid number tag')
  else:number(v[k],where+'.'+k)
def same(a,b):
 # Python bool/int equality cannot stand in for wire-type identity.
 if type(a) is not type(b):
  return type(a) in (int,float) and type(b) in (int,float) and a==b
 if isinstance(a,dict):return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 return a==b

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def author_binding():
 manifest=load(D/'author-manifest.json');exact_keys(manifest,['format','files'],'manifest')
 require(manifest['format']=='pulpo-r49-author-manifest-v2','manifest format')
 for name,digest in manifest['files'].items():
  require(type(name) is str and '/' not in name and name not in ('.','..'),'manifest path')
  require(type(digest) is str and re.fullmatch('[0-9a-f]{64}',digest) is not None,'manifest digest')
  require(sha(D/name)==digest,'immutable author binding: '+name)
 return manifest

def planned_accounting(expected,spec):
 return {'operations':len(expected),'learn_calls':sum(o['op']=='learn' for o in expected),'expected_accepted_learn_calls':sum(o['op']=='learn' and spec[o['id']]['returned'] is True for o in expected),'intended_invalid_learn_calls':sum(o['op']=='learn' and spec[o['id']]['returned'] is False and spec[o['id']]['status']=='invalid' for o in expected)}

def observed_accounting(expected,spec,rows):
 # Called only after ALL strict record/binding validation. Outcome verification
 # requires available, invoked, correctly typed matching expected return/status.
 # Invoked status claims are retained BEFORE availability filtering; an unfired
 # row's stale/null status is never an observed operation status.
 groups={k:[] for k in ('actual_invocation','actual_learn_call','observed_true_learn_return','observed_true_ok_learn_outcome','verified_expected_accepted_learn','verified_intended_invalid_rejection','unexpected_learn_outcome','unavailable_operation','unfired_operation','unknown_learn_outcome','unknown_invoked_model_status','unexpected_observed_status','unexpected_storage_status')}
 status_ledger=[];learn_ledger=[];status_counts={k:0 for k in ('ok','invalid','busy','capacity','io','uncertain','cleanup')}
 for o,r in zip(expected,rows):
  id=o['id'];e=spec[id]
  if not r['available']:groups['unavailable_operation'].append(id)
  if not r['invoked']:groups['unfired_operation'].append(id)
  if o['op']=='learn' and not (r['available'] and r['invoked']):groups['unknown_learn_outcome'].append(id)
  if not r['invoked']:continue
  groups['actual_invocation'].append(id)
  if o.get('session'):
   status=r['status']
   if status is None:groups['unknown_invoked_model_status'].append(id)
   else:
    unexpected=status!=e['status'];status_counts[status]+=1
    status_ledger.append({'id':id,'status':status,'available':r['available'],'expected_status':e['status'],'unexpected':unexpected})
    if unexpected:groups['unexpected_observed_status'].append(id)
    if status not in ('ok','invalid'):groups['unexpected_storage_status'].append(id)
  if o['op']!='learn':continue
  groups['actual_learn_call'].append(id)
  if r['returned'] is True:groups['observed_true_learn_return'].append(id)
  if r['returned'] is True and r['status']=='ok':groups['observed_true_ok_learn_outcome'].append(id)
  verified_accept=r['available'] and e['returned'] is True and r['returned'] is True and r['status']=='ok'
  verified_invalid=r['available'] and e['returned'] is False and e['status']=='invalid' and r['returned'] is False and r['status']=='invalid'
  if verified_accept:groups['verified_expected_accepted_learn'].append(id)
  if verified_invalid:groups['verified_intended_invalid_rejection'].append(id)
  unexpected_outcome=r['returned'] is not None and (not same(r['returned'],e['returned']) or (r['status'] is not None and r['status']!=e['status']))
  if unexpected_outcome:groups['unexpected_learn_outcome'].append(id)
  classification='verified_expected_acceptance' if verified_accept else 'verified_intended_invalid_rejection' if verified_invalid else 'unavailable_outcome' if not r['available'] else 'unexpected_outcome'
  learn_ledger.append({'id':id,'returned':r['returned'],'status':r['status'],'available':r['available'],'expected_returned':e['returned'],'expected_status':e['status'],'classification':classification})
 observed={}
 for name,ids in groups.items():observed[name+'_count']=len(ids);observed[name+'_ids']=ids
 observed['status_counts']=status_counts;observed['status_ledger']=status_ledger;observed['learn_outcome_ledger']=learn_ledger
 return {'format':'pulpo-r49-observed-accounting-v2','known':True,'planned':planned_accounting(expected,spec),'observed':observed,'unknown_operation_ids':[]}

def unknown_accounting(expected,spec):
 # Strict-invalid/missing/partial transport is not scored as zero activity. The
 # complete input failed validation, so observed counts are UNKNOWN (null), not
 # planned counts or fabricated fired/verified outcomes. No partial credit.
 return {'format':'pulpo-r49-observed-accounting-v2','known':False,'planned':planned_accounting(expected,spec),'observed':None,'unknown_operation_ids':[o['id'] for o in expected],'unknown_reason':'Strict-invalid input: no complete validated observation set; invocation/status/outcome counts are unknown, not zero.'}

def evaluate(raw_path):
 author_binding();fixture=load(D/'fixtures.json');oracle=load(D/'expectations.json');ref=load(D/'reference.json')
 expected=fixture['operations'];spec=oracle['operations'];relations=oracle['relations']
 raw=load(raw_path);exact_keys(raw,['format','environment','operations'],'raw')
 require(raw['format']=='pulpo-r48-raw-v2','raw format')
 env=raw['environment'];exact_keys(env,['round','fixture_sha256','runner_sha256','execution','runtime'],'environment')
 require(env['round']=='r49','environment round');require(env['fixture_sha256']==sha(D/'fixtures.json'),'fixture environment binding');require(env['runner_sha256']==sha(D/'Runner.swift'),'runner environment binding')
 require(env['runtime']==ref['runtime'],'Foundation runtime binding')
 ex=env['execution'];exact_keys(ex,['variant','binary_sha256','source_manifest_sha256','approval_sha256','compiler','platform'],'execution')
 require(ex['variant'] in ('comparison','candidate'),'execution variant')
 for k in ('binary_sha256','source_manifest_sha256','approval_sha256'):require(type(ex[k]) is str and re.fullmatch('[0-9a-f]{64}',ex[k]) is not None,'execution '+k)
 for k in ('compiler','platform'):require(type(ex[k]) is str and len(ex[k])>0,'execution '+k)
 rows=raw['operations'];require(type(rows) is list and len(rows)==len(expected),'complete ordered operation denominator')
 centers={};urls={};byid={};failed=[];unavailable=0;unfired=0;evidence_unavailable=0;transport_unavailable=0
 tol=oracle['tolerance']
 def close(x,y):return abs(x-y)<=tol['absolute']+tol['relative']*max(abs(x),abs(y))
 def state_equal(a,b):return close(a['weight'],b['weight']) and all(close(a['offsets'][i][k],b['offsets'][i][k]) for i in range(26) for k in ('x','y'))
 def state_zero(a):return close(a['weight'],0) and all(close(p[k],0) for p in a['offsets'] for k in ('x','y'))
 def fail(message):failed.append(message)
 for index,(o,r) in enumerate(zip(expected,rows)):
  exact_keys(r,['id','op','session','input','resolvedInput','returned','status','state','files','available','invoked','error'],'record '+str(index))
  require(type(r['id']) is str and r['id']==o['id'] and r['id'] not in byid,'ordered unique ID at '+str(index))
  byid[r['id']]=r;id=r['id'];op=o['op'];sid=o.get('session');e=spec[id]
  require(r['op']==op and same(r['session'],sid) and same(r['input'],o['input']),id+': exact op/session/input binding')
  require(type(r['available']) is bool and type(r['invoked']) is bool,id+': availability and invocation Booleans')
  if not r['available']:transport_unavailable+=1
  evidence_bad=bool(sid and r['status'] not in (None,'ok','invalid')) or bool(op in ('construct','reopen','reload') and r['status']!='ok')
  if evidence_bad:evidence_unavailable+=1
  if not r['available'] or evidence_bad:unavailable+=1
  if not r['invoked']:unfired+=1
  require(r['error'] is None or (type(r['error']) is str and len(r['error'])>0),id+': error field')
  require((r['available'] and r['error'] is None) or (not r['available'] and type(r['error']) is str),id+': explicit availability/error binding')
  if not r['available'] or not r['invoked']:fail(id+': unavailable' if not r['available'] else id+': unfired')
  if r['status'] is not None:require(type(r['status']) is str and r['status'] in ('ok','busy','capacity','invalid','io','uncertain','cleanup'),id+': status enum')
  if sid and r['available'] and r['invoked']:require(type(r['status']) is str,id+': missing available model status')
  require(type(r['files']) is list and len(r['files'])<=128,id+': bounded file inventory');total=0;paths=[]
  for f in r['files']:
   exact_keys(f,['path','bytes','sha256'],id+': file')
   path=f['path'];require(type(path) is str and path and not path.startswith('/') and all(c not in ('','.','..') for c in path.split('/')),id+': relative inventory path')
   require(type(f['bytes']) is int and 0<=f['bytes']<=16*1024*1024,id+': file bound');total+=f['bytes']
   require(type(f['sha256']) is str and re.fullmatch('[0-9a-f]{64}',f['sha256']) is not None,id+': file digest');paths.append(path)
  require(total<=32*1024*1024 and paths==sorted(set(paths)),id+': sorted unique bounded inventory')
  if sid and not e['persistent']:require(r['files']==[],id+': local inventory must be empty')
  if r['state'] is not None:
   st=r['state'];exact_keys(st,['weight','offsets','learning'],id+': state');number(st['weight'],id+': weight')
   require(type(st['learning']) is bool,id+': learning Boolean')
   require(type(st['offsets']) is list and len(st['offsets'])==26,id+': complete ordered a-z offsets')
   for p in st['offsets']:point(p,id+': offset')
   if st['weight']<0:fail(id+': negative weight')
   if any(abs(p[k])>.4+tol['absolute'] for p in st['offsets'] for k in ('x','y')):fail(id+': axis clamp')
  elif sid and r['available'] and r['invoked']:raise Invalid(id+': missing available projection')
  if not sid:require(r['state'] is None and r['status'] is None and r['session'] is None and r['files']==[],id+': stateless output shape')
  if r['returned'] is not None:
   if op=='center':point(r['returned'],id+': returned center')
   elif op=='normalize':require(type(r['returned']) is str,id+': normalize string')
   elif op in ('learn','save','reload'):require(type(r['returned']) is bool,id+': returned Boolean')
   else:raise Invalid(id+': unexpected return value')
  elif op in ('center','normalize','learn','save','reload') and r['available'] and r['invoked']:raise Invalid(id+': missing return value')
  resolved=r['resolvedInput']
  if resolved is not None:
   if op in ('construct','reopen'):
    exact_keys(resolved,['url'],id+': resolved URL')
    if e['persistent']:
     u=resolved['url'];require(type(u) is str and u.startswith('/') and u.endswith('/TouchModel.json') and not any(c in ('.','..','') for c in u.split('/')[1:]),id+': canonical persistent URL')
     if op=='construct':require(u not in urls.values(),id+': unique fresh persistent storage');urls[sid]=u
     else:require(sid in urls and u==urls[sid],id+': reopen same URL')
    else:require(resolved['url'] is None,id+': nil local URL')
   elif op=='learn':
    exact_keys(resolved,['text','target','taps'],id+': resolved learn')
    require(same(resolved['text'],o['input']['text']) and same(resolved['target'],o['input']['target']),id+': resolved literal binding')
    taps=resolved['taps'];given=o['input']['taps'];require(type(taps) is list and len(taps)==len(given),id+': resolved tap count')
    for j,(a,b) in enumerate(zip(given,taps)):
     if a is None:require(b is None,id+': resolved null tap');continue
     point(b,id+': resolved tap',True)
     if 'base' in a:
      require(a['base'] in centers,id+': observed geometry prerequisite');c=centers[a['base']]
      require(all(type(b[k]) in (int,float) and close(b[k],c[k]+a['d'+k]) for k in ('x','y')),id+': relative tap resolution')
     else:require(same(a,b),id+': direct tagged tap resolution')
   else:raise Invalid(id+': unexpected resolved input')
  elif op in ('construct','reopen','learn') and r['available'] and r['invoked']:raise Invalid(id+': missing resolved input')
  if not (r['available'] and r['invoked']):continue
  if op=='center':centers[chr(o['input']['byte'])]=r['returned']
  if sid:
   # A non-ok durable constructor is never usable evidence, even with zero projection.
   if op in ('construct','reopen','reload') and r['status']!='ok':fail(id+': unsuccessful observation evidence')
   if r['status']!=e['status']:fail(id+': last operation status mismatch')
   if e['learning'] is not None and r['state']['learning'] is not e['learning']:fail(id+': explicit learning policy mismatch')
   if e['zero'] and not state_zero(r['state']):fail(id+': new local/empty constructor state')
  ret=e['returned']
  if ret=='point':pass
  elif ret=='bool':
   if type(r['returned']) is not bool:fail(id+': expected reload Boolean')
  elif ret=='reference':
   if r['returned']!=next(x['key'] for x in ref['normalize'] if x['id']==id):fail(id+': exact Swift normalization')
  elif not same(r['returned'],ret):fail(id+': specified return mismatch')
 def usable(id):
  r=byid[id]
  return r['available'] and r['invoked'] and r['state'] is not None and r['status'] in ('ok','invalid') and not (r['op'] in ('construct','reopen','reload') and r['status']!='ok')
 relation_unavailable=0
 for i,r in enumerate(relations):
  ids=[r['record']] if 'record' in r else [r['left'],r['right']]
  if not all(usable(id) for id in ids):fail('relation '+str(i)+': unavailable operands');relation_unavailable+=1;continue
  a=byid[ids[0]];kind=r['kind']
  if kind=='equal':
   b=byid[ids[1]]
   if not state_equal(a['state'],b['state']):fail('relation '+str(i)+': full26 state mismatch')
   if r['files'] and a['files']!=b['files']:fail('relation '+str(i)+': settled inventory changed')
  elif kind=='changed':
   if state_equal(a['state'],byid[ids[1]]['state']):fail('relation '+str(i)+': accepted control vacuous')
  elif kind=='positive':
   if not (a['state']['weight']>tol['absolute'] and any(abs(p[k])>tol['absolute'] for p in a['state']['offsets'] for k in ('x','y'))):fail('relation '+str(i)+': positive accepted anchor absent')
  elif kind=='all_keys_nonzero':
   if not all(any(abs(p[k])>tol['absolute'] for k in ('x','y')) for p in a['state']['offsets']):fail('relation '+str(i)+': all26 accepted evidence absent')
  elif kind=='zero':
   if not state_zero(a['state']):fail('relation '+str(i)+': expected empty local reopen')
  else:raise Invalid('unknown frozen relation')
 report={'result':'pass' if not failed else 'failure','operations_denominator':len(expected),'checks_denominator':len(expected)+len(relations),'families_denominator':len(oracle['families']),'instances_denominator':len(oracle['sessions']),'relations_denominator':len(relations),'unavailable_operations':unavailable,'transport_unavailable_operations':transport_unavailable,'unavailable_evidence_operations':evidence_unavailable,'unfired_operations':unfired,'unavailable_relations':relation_unavailable,'accounting':observed_accounting(expected,spec,rows),'failure_count':len(failed),'diagnostic_message_count':len(failed),'failure_count_unit':'diagnostic_messages_not_failed_aggregates','failures':failed}
 return (0 if not failed else 1),report

def main():
 try:
  require(len(sys.argv)==2,'usage: evaluate.py raw.json')
  code,report=evaluate(sys.argv[1]);print(json.dumps(report,allow_nan=False,sort_keys=True));return code
 except (Invalid,KeyError,TypeError,IndexError,OverflowError,OSError) as e:
  # Even corrupt/incomplete transport does not shrink the frozen denominator.
  try:
   f=load(D/'fixtures.json');o=load(D/'expectations.json');den=len(f['operations']);checks=den+len(o['relations'])
   accounting=unknown_accounting(f['operations'],o['operations'])
  except Exception:
   den=None;checks=None
   accounting={'format':'pulpo-r49-observed-accounting-v2','known':False,'planned':None,'observed':None,'unknown_operation_ids':None,'unknown_reason':'Author declarations unavailable; all observed facts are unknown.'}
  print(json.dumps({'result':'strict-invalid','error':str(e),'operations_denominator':den,'checks_denominator':checks,'unavailable_operations':None,'unfired_operations':None,'accounting':accounting},allow_nan=False,sort_keys=True));return 2
if __name__=='__main__':sys.exit(main())
