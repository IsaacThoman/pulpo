#!/usr/bin/env python3
"""Author-only fabricated wire data for validator tests, never product evidence.
The simple estimator here is deliberately arbitrary; it is NOT a learning oracle.
Only symbolic accepted sample streams make canonical controls consistent.
"""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent
def read(n):return json.loads((D/n).read_text())
def dump(n,v):(D/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def main():
 f=read('fixtures.json');e=read('expectations.json');ref=read('reference.json');align={x['id']:x for x in ref['learn']};norm={x['id']:x['key'] for x in ref['normalize']};A='abcdefghijklmnopqrstuvwxyz'
 centers={k:{'x':i*.025,'y':(i%3)*.04} for i,k in enumerate(A)}
 sessions={};rows=[]
 def resolve(p):
  if p is None:return None
  if 'base' in p:return {k:centers[p['base']][k]+p['d'+k] for k in ('x','y')}
  return p.copy()
 def project(s):
  offsets=[]
  for c in A:
   pts=[p for k,p in s['stream'] if k==c]
   offsets.append({k:sum(p[k]-centers[c][k] for p in pts)/(2*len(pts)+1) if pts else 0 for k in ('x','y')})
  return {'weight':len(s['stream']),'offsets':offsets,'learning':s['learning']}
 for o in f['operations']:
  id=o['id'];op=o['op'];v=o['input'];sid=o.get('session');expect=e['operations'][id]
  r={'id':id,'op':op,'session':sid,'input':v,'resolvedInput':None,'returned':None,'status':None,'state':None,'files':[],'available':True,'invoked':True,'error':None}
  if op=='center':r['returned']=centers[chr(v['byte'])]
  elif op=='normalize':r['returned']=norm[id]
  elif op=='construct':
   sessions[sid]={'persistent':v['persistent'],'learning':False,'stream':[],'url':'/tmp/synthetic-author-only/'+sid+'/TouchModel.json' if v['persistent'] else None}
   r['resolvedInput']={'url':sessions[sid]['url']}
  elif op=='setLearning':sessions[sid]['learning']=v['value']
  elif op=='reopen':
   s=sessions[sid];s['learning']=False
   if not s['persistent']:s['stream']=[]
   r['resolvedInput']={'url':s['url']}
  elif op=='learn':
   taps=list(map(resolve,v['taps']));r['resolvedInput']={'text':v['text'],'target':v['target'],'taps':taps};r['returned']=expect['returned']
   if expect['returned']:
    a=align[id]
    for j,b in enumerate(a['targetBytes']):
     origin=a['origins'][j]
     if 97<=b<=122 and origin<len(taps) and taps[origin] is not None:sessions[sid]['stream'].append((chr(b),taps[origin]))
  elif op in ('reload','save'):r['returned']=False if op=='reload' else True
  if sid:
   s=sessions[sid];r['status']=expect['status'];r['state']=project(s)
   if s['persistent'] and s['stream']:
    payload=json.dumps(s['stream'],sort_keys=True).encode();r['files']=[{'path':'TouchModel.json','bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}]
  rows.append(r)
 env={'round':'r49','fixture_sha256':hashlib.sha256((D/'fixtures.json').read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256((D/'Runner.swift').read_bytes()).hexdigest(),'runtime':ref['runtime'],'execution':{'variant':'candidate','binary_sha256':'a'*64,'source_manifest_sha256':'b'*64,'approval_sha256':'c'*64,'compiler':'SYNTHETIC ONLY: no product compiler or execution','platform':'SYNTHETIC ONLY: no product environment'}}
 dump('synthetic-raw.json',{'format':'pulpo-r48-raw-v2','environment':env,'operations':rows})
 # Executor must replace every execution field with final frozen bindings.
 template=dict(env);template.pop('runtime');template['execution']={'variant':'REPLACE_comparison_OR_candidate','binary_sha256':'REPLACE_WITH_FROZEN_SHA256','source_manifest_sha256':'REPLACE_WITH_FROZEN_SHA256','approval_sha256':'REPLACE_WITH_FROZEN_SHA256','compiler':'REPLACE_WITH_FROZEN_COMPILER','platform':'REPLACE_WITH_FROZEN_PLATFORM'}
 dump('environment-template.json',template)
if __name__=='__main__':main()
