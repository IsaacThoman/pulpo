"""Read-only R44 retained-data/source inspection, not model/test execution."""
import collections,gzip,hashlib,json,math,subprocess
from pathlib import Path
P=Path('/Users/isaacthoman/.t3/worktrees/pulpo/t3-6f73d5b1/apps/keyboard-ios/audits/external-text-touch-r44')
ROOT=P.parents[3]
OUT=Path('/tmp/pulpo-r44-parent-review')
def require(ok,msg):
 if not ok: raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((P/n).read_bytes())
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
D=read('heldout-v3.json'); B=read('heldout-baseline.json'); C=read('heldout-candidate.json')
manifest=[(c['id'],c['language'],i,o['op']) for c in D['cases'] for i,o in enumerate(c['ops'])]
require(len(set(c['id']for c in D['cases']))==len(D['cases']),'duplicate IDs')
checks=[]; tables=[]
for rows in (B,C):
 require([(r['id'],r['language'],r['index'],r['op'])for r in rows]==manifest,'rows identity/order mismatch')
 table={(r['id'],r['index']):r for r in rows}; tables.append(table); scored=[]
 for case in D['cases']:
  require([e['index']for e in case['expect']]==list(range(len(case['ops']))),'missing checkpoint')
  for i,o in enumerate(case['ops']):
   r=table[case['id'],i]
   require(set(r['counts'])==set(case['watch']) and len(r['pairs'])==len(case['pairs']),'watch/pair attribution')
   require(type(r['weight'])in(int,float)and math.isfinite(r['weight'])and r['weight']>=0,'invalidweight')
   require(len(r['offsets'])==26 and all(len(x)==2 and all(type(v)in(int,float)and math.isfinite(v)for v in x)for x in r['offsets']),'invalid offsets')
  for e in case['expect']:
   row=table[case['id'],e['index']]
   for k,want in e.items():
    if k=='index':continue
    actual=row[k]
    if k=='counts':ok=all(actual.get(n)==v for n,v in want.items())
    elif k=='weight':ok=abs(actual-want)<=1e-9
    else:ok=actual==want
    scored.append({'id':case['id'],'index':e['index'],'key':k,'expected':want,'actual':actual,'passed':ok})
 checks.append(scored)
require(len(checks[0])==len(checks[1])==777,'check denominator')
losses=[c for b,c in zip(*checks) if b['passed'] and not c['passed']]
gains=[c for b,c in zip(*checks) if not b['passed'] and c['passed']]
preservation=[]; changes=[]
for b,c in zip(B,C):
 for k in ('text','cursor','selection','total','counts','pairs','learns'):
  if b[k]!=c[k]:preservation.append([b['id'],b['index'],k])
 if b['op']=='probe':
  for k in ('decoded','autocorrection','slots','cost'):
   if b[k]!=c[k]:preservation.append([b['id'],b['index'],k])
 diff=[k for k in b if b[k]!=c[k]]
 if diff:changes.append({'id':b['id'],'index':b['index'],'keys':diff})
lookup=[{(int(r['id'].split('-')[1]),r['index']):r for r in rows}for rows in(B,C)]
def T(v,n,i):r=lookup[v][n,i];return[r['weight'],r['offsets']]
def delta(v,n,a,b):return T(v,n,b)[0]-T(v,n,a)[0]
matches=[(41,0,1,1,0,1),(2,1,2,42,0,1),(2,1,2,43,1,2),(7,0,1,44,0,1),(8,0,1,45,0,1),(65,0,1,45,0,1),(9,0,1,46,0,1),(11,1,2,47,1,2),(23,2,3,48,2,3),(49,0,1,24,0,1),(25,0,1,50,0,1),(26,0,1,51,0,1),(31,2,3,52,2,3),(53,0,1,32,0,1),(33,0,1,54,0,1),(34,2,3,55,2,3),(67,0,1,68,0,1),(69,0,1,70,0,1),(2,8,9,43,8,9)]
match_results=[]
for n,a,b,s,x,y in matches:
 ok=all(T(1,n,a)==T(v,s,x)and T(1,n,b)==T(v,s,y)and delta(1,n,a,b)==delta(v,s,x,y)for v in(0,1))
 match_results.append({'external':[n,a,b],'space':[s,x,y],'exactTouchMatchBothReferences':ok,'increment':delta(1,n,a,b)})
pools={'en_US':[(1,0,1),(42,0,1),(44,0,1),(45,0,1),(46,0,1),(47,1,2),(48,0,1),(48,2,3)],'es':[(24,0,1),(51,0,1),(52,0,1),(52,2,3)],'en_es':[(32,0,1),(54,0,1),(55,0,1),(55,2,3)]}
positives={lang:[[delta(v,*item)for item in pool]for v in(0,1)]for lang,pool in pools.items()}
for lang,variants in positives.items():require(all(x>0 for a in variants for x in a),'vacuous Space pool '+lang)
A=read('artifact-manifest.json')
for n,h in A.items():require(sha((P/n).read_bytes())==h,'artifact hash '+n)
freeze=read('source-binary-freeze.json');seal=read('seal.json');candidate=seal['sourceCommit'];base=freeze['baseCommit']
for n,h in seal['files'].items():require(sha((P/n).read_bytes())==h,'seal '+n)
for n,h in freeze['files'].items():
 b=(ROOT/n).read_bytes() if '/audits/'in n else git('show',candidate+':'+n)
 require(sha(b)==h,'freeze '+n)
for n,h in freeze['binaries'].items():
 file='baseline.gz'if'baseline'in n else'candidate.gz'
 require(sha(gzip.decompress((P/'binaries'/file).read_bytes()))==h,'binary '+file)
engine='apps/keyboard-ios/PulpoKeyboardKit/Sources/KeyboardCore/Input/KeyboardEngine.swift'
require(git('show',base+':'+engine)==(P/'baseline-KeyboardEngine.swift.txt').read_bytes(),'baseline snapshot')
require(git('show',candidate+':'+engine)==(P/'candidate-KeyboardEngine.swift.txt').read_bytes(),'candidate snapshot')
require(not git('diff','--name-only',base,'83f22439630629860c7653ea3017b8b3fd953331'),'revert not exact')
net=git('diff','--name-only',base,'928b0d58').decode().splitlines()
require(len(net)==113 and all(n.startswith('apps/keyboard-ios/audits/external-text-touch-r44/')for n in net),'terminal non-audit diff')
require(git('diff',base,candidate)==(P/'implementation.patch').read_bytes(),'inactive patch')
Ab=read('adaptation-v2-baseline.json'); Ac=json.loads(gzip.decompress((P/'adaptation-v2-candidate.json.gz').read_bytes()))
require([(r['id'],r['index'],r['op'])for r in Ab]==[(r['id'],r['index'],r['op'])for r in Ac],'adaptation pair attribution')
probes=[]
for b,c in zip(Ab,Ac):
 if c['op']=='probe'and'external'in c['id'] and c['index']>100:
  probes.append({'id':c['id'],'index':c['index'],'intended':c['intended'],'decoded':c['decoded'],'baselineCost':b['cost'],'candidateCost':c['cost'],'baselineOffer':b['autocorrection'],'candidateOffer':c['autocorrection']})
require(len(probes)==9,'adaptation probe denominator')
case64=[r for r in C if r['id']=='r44v3-64-en-model-only-partially-tapless-word']
out={'scope':'retained Python data/source review only; no model, test, build or device execution','cases':len(D['cases']),'rowsPerVariant':len(B),'checkpointsPerVariant':len(manifest),'resourceCases':dict(collections.Counter(c['language']for c in D['cases'])),'resourceRows':dict(collections.Counter(r['language']for r in B)),'scores':[{'checks':len(x),'passed':sum(r['passed']for r in x)}for x in checks],'gains':gains,'losses':losses,'preservationDifferences':preservation,'changedRawRows':changes,'matchLines':match_results,'positiveSpaceIncrements':positives,'artifactHashesChecked':len(A),'sealHashesChecked':len(seal['files']),'freezeSourceHashesChecked':len(freeze['files']),'binaryArchiveHashesCheckedNotExecuted':2,'baseline':base,'candidate':candidate,'restoration':'83f22439630629860c7653ea3017b8b3fd953331','terminal':'928b0d58004bb762175f8ac97f975e45e2e04f28','terminalAuditOnlyPaths':len(net),'adaptationPostTrainingExternalProbes':probes,'case64RawCandidateRows':case64,'exactArtifactBindings':{n:sha((P/n).read_bytes())for n in('artifact-manifest.json','implementation.patch','source-binary-freeze.json','seal.json','heldout-v3.json','heldout-baseline.json','heldout-candidate.json','author-v3-response.md','contract-review.md','Runner.swift.txt','check.py','baseline-KeyboardEngine.swift.txt','candidate-KeyboardEngine.swift.txt')}}
print(json.dumps(out,ensure_ascii=False,indent=2))
