from pathlib import Path
import json
D=Path(__file__).resolve().parent
strict=lambda props,required=None:{'type':'object','additionalProperties':False,'required':list(props) if required is None else required,'properties':props}
num={'type':'number'};boolean={'type':'boolean'};string={'type':'string'};null={'type':'null'}
point=strict({'x':num,'y':num})
inputpoint=strict({'x':{'oneOf':[num,{'enum':['nan','posInf','negInf']}]},'y':{'oneOf':[num,{'enum':['nan','posInf','negInf']}]}})
relative=strict({'base':{'type':'string','pattern':'^[a-z]$'},'dx':num,'dy':num})
inputs={'center':strict({'byte':{'type':'integer','minimum':97,'maximum':122}}),'normalize':strict({'text':string}),'construct':strict({'persistent':boolean}),'setLearning':strict({'value':boolean}),'learn':strict({'text':string,'target':string,'taps':{'type':'array','items':{'oneOf':[null,inputpoint,relative]}}})}
for k in ('save','reload','observe','reopen'):inputs[k]=strict({})
actions=[]
for op,input in inputs.items():
 props={'id':{'type':'string','minLength':1},'op':{'const':op},'input':input}
 if op not in ('center','normalize'):props['session']={'type':'string','minLength':1}
 actions.append(strict(props))
fixture=strict({'format':{'const':'pulpo-r49-fixtures-v1'},'operations':{'type':'array','minItems':1,'items':{'oneOf':actions}}})
state=strict({'weight':{'type':'number'},'learning':boolean,'offsets':{'type':'array','minItems':26,'maxItems':26,'items':point}})
file=strict({'path':{'type':'string','minLength':1},'bytes':{'type':'integer','minimum':0,'maximum':16777216},'sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'}})
execution=strict({'variant':{'enum':['comparison','candidate']},'binary_sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'},'source_manifest_sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'},'approval_sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'},'compiler':{'type':'string','minLength':1},'platform':{'type':'string','minLength':1}})
environment=strict({'round':{'const':'r49'},'fixture_sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'},'runner_sha256':{'const':'8f50f13ef8fcddc51d3521e6311992ebae2778f5635957f381f6a392ff61e4a1'},'execution':execution,'runtime':{'const':'Version 27.0.1 (Build 26A434)'}})
record=strict({'id':{'type':'string','minLength':1},'op':{'enum':list(inputs)},'session':{'oneOf':[null,string]},'input':{'oneOf':[inputs[k] for k in ('center','normalize','construct','setLearning','learn','save')]},'resolvedInput':{'oneOf':[null,strict({'url':{'oneOf':[null,string]}}),strict({'text':string,'target':string,'taps':{'type':'array','items':{'oneOf':[null,inputpoint]}}})]},'returned':{'oneOf':[null,string,boolean,point]},'status':{'enum':[None,'ok','invalid','busy','capacity','io','uncertain','cleanup']},'state':{'oneOf':[null,state]},'files':{'type':'array','maxItems':128,'items':file},'available':boolean,'invoked':boolean,'error':{'oneOf':[null,{'type':'string','minLength':1}]}})
raw=strict({'format':{'const':'pulpo-r48-raw-v2'},'environment':environment,'operations':{'type':'array','items':record}})
for name,doc in [('schema.json',raw),('fixtures-schema.json',fixture)]:
 doc={'$schema':'https://json-schema.org/draft/2020-12/schema','$comment':'Finite strict JSON only. evaluate.py additionally enforces immutable input and ordered ID binding, geometry resolution, complete cardinality, evidence semantics and full-vector relations. JSON Schema alone is insufficient.',**doc}
 (D/name).write_text(json.dumps(doc,indent=2)+'\n')
