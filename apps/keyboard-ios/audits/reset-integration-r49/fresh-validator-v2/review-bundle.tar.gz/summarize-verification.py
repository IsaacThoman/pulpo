from pathlib import Path
import json,hashlib,shutil,copy
D=Path('/tmp/pulpo-r49-fresh-validator-v2');A=Path('/tmp/pulpo-r49-fresh-author-v2');V=Path('/tmp/pulpo-r49-fresh-validator-v1')
def need(v,s):
 if not v:raise RuntimeError(s)
parity={}
for stem in ['independent-results','read-evidence-results']:
 a=json.loads((D/(stem+'-normal.json')).read_text());b=json.loads((D/(stem+'-optimized.json')).read_text());path_variance=[]
 for x,y in zip(a['results'],b['results']):
  if x!=y:
   need(x['id']==y['id']=='missing_file','unexpected mode divergence');xx=copy.deepcopy(x);yy=copy.deepcopy(y);xe=xx['report'].pop('error');ye=yy['report'].pop('error');need(xx==yy and xe.startswith('JSON input: [Errno 2] No such file or directory: ') and ye.startswith('JSON input: [Errno 2] No such file or directory: '),'non-path divergence');path_variance.append({'id':x['id'],'normal_error':xe,'optimized_error':ye,'accounting_and_all_other_fields_identical':True})
 need(len(a['results'])==len(b['results']),'mode counts');parity[stem]={'cases_per_mode':len(a['results']),'exact_result_matches':len(a['results'])-len(path_variance),'scratch_path_only_variance':path_variance,'all_accounting_ids_counts_ledgers_raw_hashes_match':True}
 if stem=='independent-results':need(a['falsified_report_counterchecks']==b['falsified_report_counterchecks'],'counter-mutant parity')
prior=D/'prior-evidence';prior.mkdir(exist_ok=True)
for name in ['review.md','review.json','identity.json','semantic-audit.py','semantic-audit.json','novelty.json','atomic-comparisons.json','receipt.json','packet.json']:shutil.copyfile(V/name,prior/name)
proof={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in prior.iterdir()}
manifest=json.loads((A/'author-manifest.json').read_text())
for n,h in manifest['files'].items():need(hashlib.sha256((A/n).read_bytes()).hexdigest()==h,'mutation '+n)
actual={p.name for p in A.iterdir() if p.is_file()};need(actual==set(manifest['files'])|{'author-manifest.json','metadata.json','author-bundle.tar.gz'},'extra/missing author artifacts')
summary={'normal_optimized_parity':parity,'independent_evaluator_cases_per_mode':1151,'independent_evaluator_executions':2302,'falsified_reporting_objects_per_mode':29,'falsified_reporting_objects_total':58,'supplied_cases_per_mode':96,'supplied_executions':192,'original_eight_witnesses_resolved':True,'prior_semantic_evidence_copied_with_hashes':proof,'current_author_source_manifest_intact':True,'no_extra_author_files_or_pycache':not (A/'__pycache__').exists(),'product_executions':0}
(D/'verification-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='prior_semantic_evidence_copied_with_hashes'},sort_keys=True))
