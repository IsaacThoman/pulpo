"""Read immutable seam packet only; no product operations or artifact mutations."""
from pathlib import Path,PurePosixPath
import difflib,hashlib,json,tarfile
base=Path('/tmp/pulpo-r49-filesystem-seam-v1')
def sha(b):return hashlib.sha256(b).hexdigest()
def need(ok,message):
 if not ok:raise ValueError(message)
archive=base/'r49-filesystem-seam-v1.tar.gz';manifest=base/'SHA256SUMS.json'
need(sha(archive.read_bytes())=='81a7328260a64758ac287078e6b0d07cfb0f56d2226c43dd7615789e867d95cb','archive hash')
need(sha(manifest.read_bytes())=='06fc96207b3643eb721e760d5bf472b56c7b8f1e2a5931b5ccc3dfa69d19e4b5','manifest hash')
m=json.loads(manifest.read_text());files=m['files'];need(len({r['path'] for r in files})==len(files)==15,'manifest inventory')
expected={r['path'] for r in files}|{'SHA256SUMS.json'};observed={}
with tarfile.open(archive) as tar:
 for member in tar:
  p=PurePosixPath(member.name);need(not p.is_absolute() and '..' not in p.parts and member.isfile(),'safe regular member')
  need(len(p.parts)==2 and p.parts[0]=='r49-filesystem-seam-v1' and p.parts[1] not in observed,'safe unique path')
  observed[p.parts[1]]=tar.extractfile(member).read()
need(set(observed)==expected,'archive inventory')
for row in files:
 data=(base/row['path']).read_bytes();need(sha(data)==row['sha256'] and len(data)==row['bytes'] and data==observed[row['path']],'file binding '+row['path'])
need(manifest.read_bytes()==observed['SHA256SUMS.json'],'manifest archive identity')
old=(base/'Runner.r48-frozen.swift').read_text();new=(base/'Runner.swift').read_text();inventory=(base/'Inventory.swift').read_text();probes=(base/'Probes.swift').read_text()
need(sha(old.encode())=='2718e44462cf19625484ef2b82b40771475ef5c546c2cf034523fc7de6730255','old runner')
need(sha(new.encode())=='8f50f13ef8fcddc51d3521e6311992ebae2778f5635957f381f6a392ff61e4a1','new runner')
embedded=inventory.removeprefix('import Foundation\nimport CryptoKit\n\n')
need(embedded in new and new.count(embedded)==1,'exact embedded helper')
need([l for l in inventory.splitlines() if l.startswith('import ')]==['import Foundation','import CryptoKit'],'helper imports')
need([l for l in probes.splitlines() if l.startswith('import ')]==['import Foundation','import CryptoKit'],'probe imports')
need('InventoryCollector' in probes and 'func inventoryRegularFiles' not in probes and 'func retainedBlockedReason' not in probes,'same helper usage')
diff=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='R48-frozen/Runner.swift',tofile='R49-filesystem-seam-v1/Runner.swift'))
need(diff==(base/'Runner.diff').read_text(),'exact diff')
output=json.loads((base/'probe-stdout.json').read_text());need(output['probeCount']==len(output['probes'])==28 and output['pass'] is True and all(r['pass'] is True for r in output['probes']),'original probe count/flags')
need(len({r['id'] for r in output['probes']})==28,'probe IDs')
print(json.dumps({'verdict':'BINDINGS_PASS','archiveSHA256':sha(archive.read_bytes()),'manifestSHA256':sha(manifest.read_bytes()),'manifestFiles':15,'archiveRegularFiles':16,'helperSHA256':sha(inventory.encode()),'probesSHA256':sha(probes.encode()),'runnerSHA256':sha(new.encode()),'runnerDiffSHA256':sha(diff.encode()),'originalProbeStdoutSHA256':sha((base/'probe-stdout.json').read_bytes()),'originalProbeCount':28,'embeddedHelperExact':True,'probeUsesSameHelper':True,'newProductExecutions':0},indent=2))
