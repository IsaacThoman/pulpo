#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).resolve().parent
PROTECTED={'fixtures.json':'9f49a1fa017e07f989c19518329e1a48b16e1e76c9c2d7826f5a55c301212912','expectations.json':'dc63f643ea7dd6f7a61df60663c1fa78580bcb9adb4d1b0ca4a68fab2d4a0ed1','reference.json':'0431ce88a659611358b35d0672337137544149ab79709641c36b2dcb4a4343eb','Runner.swift':'8f50f13ef8fcddc51d3521e6311992ebae2778f5635957f381f6a392ff61e4a1'}
def main():
 old=json.loads((D/'v1-author-manifest.json').read_text())['files'];unchanged=[];changed=[]
 for name,oldsha in old.items():
  digest=hashlib.sha256((D/name).read_bytes()).hexdigest()
  (unchanged if digest==oldsha else changed).append(name)
 for name,h in PROTECTED.items():
  if hashlib.sha256((D/name).read_bytes()).hexdigest()!=h:raise RuntimeError('protected byte drift '+name)
 allowed={'evaluate.py','seal_manifest.py','README.md','adversarial-results.json'}
 if set(changed)!=allowed:raise RuntimeError('unexpected v1 artifact changes '+str(changed))
 new_eval=(D/'evaluate.py').read_text();old_eval=(D/'v1-evaluate.py.txt').read_text()
 # Exact original validation/scoring body must remain byte-identical. Reporting
 # helper additions, manifest version, final report fields and strict-invalid
 # report envelope are separately shown in the unified diff.
 first='def evaluate(raw_path):';last=" report={'result':"
 if new_eval.split(first)[1].split(last)[0]!=old_eval.split(first)[1].split(last)[0]:raise RuntimeError('behavior validation/scoring body changed')
 output={'format':'pulpo-r49-v2-preservation-proof','result':'pass','protected':PROTECTED,'unchanged_v1_artifacts':sorted(unchanged),'changed_v1_artifacts':sorted(changed),'behavioral_validation_and_scoring_body_byte_identical':True,'v1_archive_sha256':'bfa62181addfade8b2e0011c059b7608941cddf4c53e9876294071b412f15fe4','v1_review_verdict':'REJECT_PREEXECUTION_ACCOUNTING_CORRECTION_REQUIRED','product_executions':0}
 (D/'v2-preservation-proof.json').write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'result':'pass','protected_files':len(PROTECTED),'unchanged_v1_artifacts':len(unchanged),'changed_v1_artifacts':len(changed),'product_executions':0},sort_keys=True))
if __name__=='__main__':main()
