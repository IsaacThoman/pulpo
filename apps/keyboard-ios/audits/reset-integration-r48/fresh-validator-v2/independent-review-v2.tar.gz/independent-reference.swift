import Foundation

// Independent implementation of the public R48 specification only.
// No product import/calls, learning formula, storage, cases or results.
func publicKeyReference(_ input: String) -> String {
  let scalars: [Unicode.Scalar]
  if input.unicodeScalars.allSatisfy({ $0.value < 128 }) {
    scalars = input.unicodeScalars.compactMap { scalar in
      if scalar.value == 39 { return nil }
      let value = scalar.value
      return Unicode.Scalar((65...90).contains(value) ? value + 32 : value)
    }
  } else {
    let decomposed = input.lowercased().decomposedStringWithCompatibilityMapping
    scalars = decomposed.unicodeScalars.filter {
      $0.value != 39 && $0.value != 0x2019 && $0.properties.generalCategory != .nonspacingMark
    }
  }
  return String(String.UnicodeScalarView(scalars))
}

struct PublicReferenceAlignment {
  let characters: [String]
  let typedBytes: [UInt8]
  let origins: [Int]
  let targetBytes: [UInt8]
  var lengthMatches: Bool { targetBytes.count >= 2 && typedBytes.count == targetBytes.count }

  // Pure structural contribution selection. Nil denotes an absent point;
  // true/false denotes finite/nonfinite displacement at an available point.
  // Unknown extra entries are never indexed beyond original Characters.
  func contributingOrigins(finitePoints: [Bool?]) -> [Int]? {
    guard lengthMatches else { return nil }
    var result: [Int] = []
    for (i, byte) in targetBytes.enumerated() where (97...122).contains(byte) {
      let origin = origins[i]
      let finite = origin < finitePoints.count ? finitePoints[origin] : nil
      guard let finite else { continue }
      guard finite else { return nil }
      result.append(origin)
    }
    return result.isEmpty ? nil : result
  }
}

func publicAlignmentReference(text: String, target: String) -> PublicReferenceAlignment {
  let characters = text.map(String.init)
  var bytes: [UInt8] = []
  var origins: [Int] = []
  for (i, character) in characters.enumerated() {
    let part = Array(publicKeyReference(character).utf8)
    bytes += part
    origins += Array(repeating: i, count: part.count)
  }
  return PublicReferenceAlignment(characters: characters, typedBytes: bytes,
                                  origins: origins, targetBytes: Array(publicKeyReference(target).utf8))
}

let fixtureURL = URL(fileURLWithPath: CommandLine.arguments[1])
let f = try JSONSerialization.jsonObject(with: Data(contentsOf: fixtureURL)) as! [String: Any]
var refs: [[String: Any]] = []
for family in f["families"] as! [[String: Any]] {
 let fid = family["id"] as! String
 let norm = (f["operations"] as! [[String: Any]]).first { $0["id"] as! String == "normalize/" + fid }!
 let normalized = publicKeyReference((norm["input"] as! [String: Any])["text"] as! String)
 var arrays: [[String: Any]] = []
 for o in f["operations"] as! [[String: Any]] where (o["session"] as? String) == fid + "/local" && o["op"] as! String == "learn" && o["id"] as! String != fid + "/local/seed" {
  let i = o["input"] as! [String: Any]
  let a = publicAlignmentReference(text: i["text"] as! String, target: i["target"] as! String)
  let points: [Bool?] = (i["taps"] as! [Any]).map { p in
   if p is NSNull { return nil }; let d=p as! [String:Any]
   if d["base"] != nil { return true }
   return ["x","y"].allSatisfy { (d[$0] as? NSNumber)?.doubleValue.isFinite == true }
  }
  arrays.append(["characters":a.characters,"typedBytes":a.typedBytes.map(Int.init),"origins":a.origins,"targetBytes":a.targetBytes.map(Int.init),"contributingOrigins":a.contributingOrigins(finitePoints:points) as Any? ?? NSNull()])
 }
 refs.append(["id":fid,"normalized":normalized,"alignments":arrays])
}
let out=try JSONSerialization.data(withJSONObject:refs,options:[.sortedKeys,.prettyPrinted])
try out.write(to:URL(fileURLWithPath:CommandLine.arguments[2]))
