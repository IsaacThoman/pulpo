from pathlib import Path
import json,copy,subprocess,sys,hashlib
A=Path('/tmp/pulpo-r49-fresh-author-v1');D=Path('/tmp/pulpo-r49-fresh-validator-v1');P=D/'cli';P.mkdir(exist_ok=True);base=json.loads((A/'synthetic-raw.json').read_text());results=[]
cases={'pass':(base,0),'behavior-failure':(copy.deepcopy(base),1),'missing-action':(copy.deepcopy(base),2)}
cases['behavior-failure'][0]['operations'][40+2]['returned']=False
# Use an ordinary accepted model learn, found by public frozen oracle, rather than relying on row index.
e=json.loads((A/'expectations.json').read_text())
cases['behavior-failure']=(copy.deepcopy(base),1)
for r in cases['behavior-failure'][0]['operations']:
 if r['op']=='learn' and e['operations'][r['id']]['returned'] is True:r['returned']=False;break
cases['missing-action'][0]['operations'].pop()
for name,(value,expected) in cases.items():(P/(name+'.json')).write_text(json.dumps(value,separators=(',',':')))
s=json.dumps(base,separators=(',',':'))
texts={'nonfinite-nan':s.replace('"weight":0','"weight":NaN',1),'nonfinite-overflow':s.replace('"weight":0','"weight":1e9999',1),'duplicate-key':'{"format":"pulpo-r48-raw-v2",'+s[1:],'truncated':s[:-2]}
for name,v in texts.items():(P/(name+'.json')).write_text(v);cases[name]=(None,2)
for name,(_,expected) in cases.items():
 for optimized in [False,True]:
  path=P/(name+'.json');p=subprocess.run([sys.executable]+(['-O'] if optimized else [])+[str(A/'evaluate.py'),str(path)],text=True,capture_output=True)
  if p.returncode!=expected:raise RuntimeError(name+str(p.returncode)+p.stdout+p.stderr)
  r=json.loads(p.stdout)
  if r['operations_denominator']!=452 or r['checks_denominator']!=772:raise RuntimeError('denominator')
  results.append({'id':name,'optimized':optimized,'exit':p.returncode,'raw_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'stdout':p.stdout,'stderr':p.stderr})
(P/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'cases':len(cases),'executions':len(results),'exit_codes':[0,1,2],'normal_optimized_agree':True}))
