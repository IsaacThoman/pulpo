// Declaration-only author syntax aid. Never execute or link as a product.
import Foundation
public struct KeyPoint { public var x: Double; public var y: Double; public init(x: Double, y: Double) { fatalError("inert") } }
public struct TypedWord { public init(text: String, taps: [KeyPoint?]) { fatalError("inert") } }
public struct LetterGeometry { public static var qwerty: LetterGeometry { fatalError("inert") }; public func center(_ byte: UInt8) -> KeyPoint? { fatalError("inert") } }
public enum LearningPersistenceResult: String { case ok,busy,capacity,invalid,io,uncertain,cleanup }
public final class TouchModel {
 public init(url: URL?) { fatalError("inert") }
 public var weight: Double { fatalError("inert") }
 public var offsets: [KeyPoint] { fatalError("inert") }
 public var persistenceResult: LearningPersistenceResult { fatalError("inert") }
 public var isLearning: Bool { get { fatalError("inert") } set { fatalError("inert") } }
 public func learn(_ word: TypedWord, intended: String, geometry: LetterGeometry) -> Bool { fatalError("inert") }
 public func save(inBackground: Bool = false) -> Bool { fatalError("inert") }
 public func reloadIfChangedOnDisk() -> Bool { fatalError("inert") }
}
public enum TextNormalizer { public static func key(_ text: String) -> String { fatalError("inert") } }
