// owned inert marker comparison; never compiled
