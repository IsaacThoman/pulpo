Frozen source-blind benchmark author review v1. See SPEC.md, attestation.json,
metadata.json and SHA256SUMS.json. This bundle contains no product observations.

Preexecution checks:
  python3 evaluate.py --preflight
  python3 selfcheck.py
  python3 -O selfcheck.py

Runner.swift is product-execution material for the parent only after independent
review and final source/executor freeze. InertKeyboardCore.swift may be compiled
in an isolated temporary syntax-check directory only; never execute it or use
it to build the product runner. Compiler/typechecking and Foundation reference
checks have already been completed and archived in preexecution-checks.json.

Do not regenerate fixtures or edit this version after review handoff. Extract
an archive copy for tests that write reports. A correction must preserve v1 and
be delivered as a separate successor bundle before product execution.
