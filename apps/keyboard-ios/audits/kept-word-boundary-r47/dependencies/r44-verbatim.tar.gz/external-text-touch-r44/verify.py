#!/usr/bin/env python3
"""Verify retained hashes and strict complete raw-score computation; no inference execution."""
import argparse,gzip,hashlib,json,pathlib,subprocess,sys
p=pathlib.Path(__file__).resolve().parent
root=p.parents[3]
args=argparse.ArgumentParser();args.add_argument('--current-source',action='store_true');opt=args.parse_args()
def need(ok,msg):
 if not ok: raise SystemExit(msg)
def sha(b): return hashlib.sha256(b).hexdigest()
m=json.loads((p/'artifact-manifest.json').read_text())
for name,want in m.items(): need(sha((p/name).read_bytes())==want,'artifact mismatch '+name)
for name,entry in json.loads((p/'archive-index.json').read_text()).items():
 need(sha(gzip.decompress((p/entry['archive']).read_bytes()))==entry['originalSHA256'],'archived raw mismatch '+name)
f=json.loads((p/'source-binary-freeze.json').read_text())
for name,want in f['binaries'].items():
 archive=p/'binaries'/('baseline.gz' if 'baseline' in name else 'candidate.gz')
 need(sha(gzip.decompress(archive.read_bytes()))==want,'binary mismatch '+name)
need(sha((p/'candidate-KeyboardEngine.swift.txt').read_bytes())==f['files']['apps/keyboard-ios/PulpoKeyboardKit/Sources/KeyboardCore/Input/KeyboardEngine.swift'],'candidate snapshot mismatch')
if opt.current_source:
 for name,want in f['files'].items(): need(sha((root/name).read_bytes())==want,'current source mismatch '+name)
process=json.loads((p/'paired-process.json').read_text())
need(len(process['runs'])==2 and all(r['exit']==0 and r['outputExists'] for r in process['runs']),'paired process failed')
rejection=json.loads((p/'rejection.json').read_text())
need(rejection['restoredEngineByteExactWithParent'],'restoration not recorded')
for name,want in json.loads((p/'candidate-source-snapshots.json').read_text()).items():
 need(sha((root/want).read_bytes())==f['files'][name],'candidate snapshot mismatch '+name)
seal=json.loads((p/'seal.json').read_text())
for name,want in seal['files'].items(): need(sha((p/name).read_bytes())==want,'seal mismatch '+name)
r=subprocess.run([sys.executable,str(p/'check.py'),str(p/seal['input']),str(p/'heldout-baseline.json'),str(p/'heldout-candidate.json')],capture_output=True,text=True)
need(r.returncode==0,r.stderr)
need(json.loads(r.stdout)==json.loads((p/'paired-report.json').read_text()),'score recomputation mismatch')
independent=subprocess.run([sys.executable,str(p/'independent-check.py')],capture_output=True,text=True)
need(independent.returncode==0,independent.stderr)
need(json.loads(independent.stdout)==json.loads((p/'independent-check.json').read_text()),'independent evidence recomputation mismatch')
print('PASS: retained hashes, source/binary seal, all rows and independent score recomputation. Gate disposition remains as recorded in README.md.')
