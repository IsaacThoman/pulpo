let fixtureURL = URL(fileURLWithPath: CommandLine.arguments[1])
let f = try JSONSerialization.jsonObject(with: Data(contentsOf: fixtureURL)) as! [String: Any]
var refs: [[String: Any]] = []
for family in f["families"] as! [[String: Any]] {
 let fid = family["id"] as! String
 let norm = (f["operations"] as! [[String: Any]]).first { $0["id"] as! String == "normalize/" + fid }!
 let normalized = publicKeyReference((norm["input"] as! [String: Any])["text"] as! String)
 var arrays: [[String: Any]] = []
 for o in f["operations"] as! [[String: Any]] where (o["session"] as? String) == fid + "/local" && o["op"] as! String == "learn" && o["id"] as! String != fid + "/local/seed" {
  let i = o["input"] as! [String: Any]
  let a = publicAlignmentReference(text: i["text"] as! String, target: i["target"] as! String)
  let points: [Bool?] = (i["taps"] as! [Any]).map { p in
   if p is NSNull { return nil }; let d=p as! [String:Any]
   if d["base"] != nil { return true }
   return ["x","y"].allSatisfy { (d[$0] as? NSNumber)?.doubleValue.isFinite == true }
  }
  arrays.append(["characters":a.characters,"typedBytes":a.typedBytes.map(Int.init),"origins":a.origins,"targetBytes":a.targetBytes.map(Int.init),"contributingOrigins":a.contributingOrigins(finitePoints:points) as Any? ?? NSNull()])
 }
 refs.append(["id":fid,"normalized":normalized,"alignments":arrays])
}
let out=try JSONSerialization.data(withJSONObject:refs,options:[.sortedKeys,.prettyPrinted])
try out.write(to:URL(fileURLWithPath:CommandLine.arguments[2]))
