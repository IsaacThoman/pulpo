import copy,importlib.util,json,pathlib,sys
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).resolve().parent;B=P/'review-v2/author-review-v2';s=importlib.util.spec_from_file_location('e',B/'evaluate.py');E=importlib.util.module_from_spec(s);s.loader.exec_module(E)
fixtures=E.read(B/'fixtures.json');initial=next(o['id'] for o in fixtures['operations'] if o['id'].endswith('/setupLearning'));reopened=next(o['id'] for o in fixtures['operations'] if o['id'].endswith('/reopenedSetupLearning'));construct=next(o['id'] for o in fixtures['operations'] if o['op']=='construct');reopen=next(o['id'] for o in fixtures['operations'] if o['op']=='reopen')
mode='optimized' if not __debug__ else 'normal';root=P/('preflight-'+mode);root.mkdir(exist_ok=True);reports=[]
def at(f,id):return next(o for o in f['operations'] if o['id']==id)
def run(name,mut,needle):
 f=copy.deepcopy(fixtures);mut(f);d=root/name;d.mkdir(exist_ok=True)
 for n in ['reference-values.json','design.json']:(d/n).write_bytes((B/n).read_bytes())
 (d/'fixtures.json').write_text(json.dumps(f));(d/'operation-manifest.json').write_text(json.dumps([{k:o[k] for k in ['id','op','session','input']} for o in f['operations']]))
 E.ROOT=d
 try:E.preflight()
 except E.Invalid as e:
  if needle not in str(e):raise RuntimeError((name,str(e),needle))
  reports.append({'id':name,'rejected':True,'error':str(e)})
 else:raise RuntimeError('preflight accepted '+name)
run('missing-initial-setup',lambda f:f['operations'].__setitem__(slice(None),[o for o in f['operations'] if o['id']!=initial]),'missing immediate explicit policy setup')
run('missing-reopen-setup',lambda f:f['operations'].__setitem__(slice(None),[o for o in f['operations'] if o['id']!=reopened]),'missing immediate explicit policy setup')
run('unsupported-constructor-literal',lambda f:at(f,construct)['expect'].update(learning=True),'constructor policy is unspecified')
run('unsupported-reopen-literal',lambda f:at(f,reopen)['expect'].update(learning=True),'reopen policy is unspecified')
run('initial-setup-disabled',lambda f:at(f,initial)['input'].update(value=False),'explicit setup action binding')
run('reopen-setup-disabled',lambda f:at(f,reopened)['input'].update(value=False),'explicit setup action binding')
run('missing-explicit-policy-oracle',lambda f:at(f,initial)['expect'].pop('learning'),'explicit learning value oracle')
run('initial-setter-state-relation',lambda f:at(f,initial)['expect'].pop('projectionEq'),'toggle state/file relation')
run('reopen-setter-file-relation',lambda f:at(f,reopened)['expect'].pop('filesEq'),'toggle state/file relation')
result={'mode':mode,'pass':True,'count':len(reports),'cases':reports,'productRuns':0};(P/('preflight-regressions-'+mode+'.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result))
