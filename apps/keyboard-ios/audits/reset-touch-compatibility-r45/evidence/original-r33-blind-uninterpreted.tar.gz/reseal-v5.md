# R33 blind static reseal v5: ACCEPT_STATIC_RESEAL

18 cases; 388 actions; 361 typed oracles; 6 barriers; 64 actor processes; 18 unique operation shapes. Unsupported categories: 10. Product/real-worker/sealed-schedule executions: 0.

The v4 retry-history rejection is resolved. Exact v3/v4/v5 byte diffs and whole-module AST comparison establish only the reviewed retry-history, failed-action logging, constructor-read cleanup and confirmed-busy scheduler-yield changes. The 5000-attempt and 5-second limits, schema, API, expectations and oracles remain unchanged.

Static --novel validation: 2 current attempts, 0 failures, 0 novelty conflicts. Recorded history: 3 original author attempts + 1 v4 review attempt + 2 current attempts = 6; original preseal oracle corrections remain 2. No new payload, oracle or input edits.

Synthetic harness tests: final 32/32 pass, 0 failures. Two invocations, 64 checks executed. First invocation: 25 passed, 7 failed from two fixture mistakes (reload reply shape and a missing synthetic busy response). Both corrected only in the fake test fixtures; initial script/results retained. Historical v3/v4 loss was reproduced. No real worker or product was launched.

Feasibility and scalar/control oracle review is carried forward by exact hashes from the sealed manual review under unchanged public semantics. The existing independent 70-digit Decimal reference was rerun into a new private output: 64 touch checks pass; maximum absolute difference 3.031510119580154665704431643717625402402796039031419677E-16. No new independent scalar reference implementation is claimed.

Every original artifact and approved input retains its original hash; gzip remains lossless. This static reseal authorizes no product-success claim. Candidate, runner, independent source review and required gates must still be frozen before one reveal; no postreveal tuning.

## Exact hashes

Payload SHA-256: `0834b19e144e30b46506484d04e5d61748976e4e8699614525340bc1e06ccbae`

Original seal SHA-256: `b5114fd3d2b586ac3d1e0a8e2696e0ae20a5ccc02daba78f6fdd420992fc1c68`

- `contract-preflight-v3.md`: `a517f4b627b3575a99d0959240a0a6bd3a0dd2781c7d763c52214fe714799ccd` (25008 bytes)
- `schema-preflight-v3.json`: `2b7a34f6c482a6ac0ffe7f23c2d9964c72b6f31c34eed3f0b7aa59f75e4cb6ef` (5483 bytes)
- `public-api-v3.md`: `85289af4b0993e78250b0d223d28aa4568ca0488036dd0356f1818c8c701997e` (3548 bytes)
- `worker-v3.swift`: `420e7003a48cf7d5a5b63945830cbf03250a871e6c2661e6b57e37632fa9a6f7` (4913 bytes)
- `run-v3.py`: `a36d009cd3a7dea65dee1320a144019b3765c940c62d1fafa0f98cf57fd63c91` (5876 bytes)
- `validate-v3.py`: `218cb903730a3557f53b0a7d353be3e40354548a3eb7700d02ca780eecd05d64` (8179 bytes)
- `transaction-gate-v3.c`: `c16b02907a8ac665f071ac94b24b427b843f3b92ba45caf56ffb2fca30cf9b0d` (1955 bytes)
- `r29-exclusion-hashes.json`: `f8c67549c31e650cf283f01ade44922e73ad584aed52ab118c39142e2fc54a77` (9949 bytes)
- `adapter-capabilities-v3.md`: `f24e6e50f9fc803282cfe86a2a2474ec56ed94ca120584d06d501f613dc36b2d` (4966 bytes)
- `run-v4.py`: `26e965bab271156d8b744ebdf8ec5fe30ab3d17523c3de92f8d8b0c360517e85` (6186 bytes)
- `run-v5.py`: `09072bc189cfedf010caad9b401b00e6e6f6b8e06f0fe025ce432ef8c4af48dd` (6552 bytes)

Reseal JSON SHA-256: `a3e8c031b95f39ca8609b76bbe65a9630f2dc7c126189dd9e580eadc0b9ba35f`

JSON artifact: `/tmp/pulpo-r33-blind/reseal-v5.json`

Markdown artifact: `/tmp/pulpo-r33-blind/reseal-v5.md`
