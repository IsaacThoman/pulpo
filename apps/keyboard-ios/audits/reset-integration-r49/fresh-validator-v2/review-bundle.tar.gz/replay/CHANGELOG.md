# R49 author-v2 preexecution reporting correction

The original author-v1 archive remains unchanged:
`bfa62181addfade8b2e0011c059b7608941cddf4c53e9876294071b412f15fe4`.
Its independent review archive is
`1def3064fb115f2d25f4d305b68b0810062a4b9423db2eb51bb8a2f2cad8ecd7`.
The exact review, receipt and packet are retained as `v1-independent-*` files.
The review verdict is REJECT BEFORE EXECUTION for R49V1-ACCOUNT-01. This version
preserves that rejection and does not erase the prior reporting regression.

The complete v1 semantic/action/strict-transport review approved 452 actions and
320 relations. It found no false behavioral pass. It rejected observed accounting:
planned 31 invalid controls were reported without actual invocation/learn totals,
verified available acceptance/rejection outcomes or an unexpected-status ledger.
The exact changed implementation is in `v1-v2.diff`; the file hash inventory is
`v1-v2-files.json`. Added files are complete in this archive. The original v1
manifest, metadata and evaluator text are retained for direct comparison.

v2 removes the ambiguous `expected_invalid_rejections` report field. Planned counts
are explicit and distinct from observed counts. It records matching invocations,
actual learns, raw true returns/true-ok outcomes, available verified expected
acceptances and intended-invalid rejections, unavailable/unfired/unknown outcomes,
and invoked statuses with IDs even when unavailable. Unfired stale/null statuses
are never observed statuses. Strict-invalid/missing/partial raw input reports all
observed counts unknown with the complete frozen ID denominator. No partial
corrupt row is credited as fired or verified. Reporting definitions are in
`ACCOUNTING-V2.md` and output shape is in `report-schema.json`.

The retained `failure_count` is explicitly diagnostic-message count, with an
identical `diagnostic_message_count` and declared unit. No aggregate pass numerator
is derived from diagnostic count. All original verdicts, failure messages and
numeric/state/input/status checks remain unchanged.

All 68 original adversarial declarations and synthetic baseline input bytes remain
unchanged. Their result reports are regenerated solely for the new reporting.
v2 adds 28 accounting-specific synthetic witnesses, independent frozen complete
countertruth and normal/optimized comparisons. They include all eight review
witness classes plus wrong outcomes, stale unfired statuses and strict-invalid or
missing input. Every original adversary still receives its original exit code.
All new witness exits, counts, ID lists, status/outcome ledgers and unknown facts
match their frozen countertruth under both Python modes.

The first development accounting-test attempt correctly returned strict-invalid
because the author manifest still referenced the preceding adversarial report
bytes after report regeneration. The author resealed the preexecution development
manifest between artifact-generation stages and reran synthetic tests. This was
an author-build ordering error; no product reply, input/oracle change or behavioral
verdict adjustment occurred. The final immutable version has complete stable hashes.

Protected exact bytes are:

- fixtures.json: `9f49a1fa017e07f989c19518329e1a48b16e1e76c9c2d7826f5a55c301212912`
- expectations.json: `dc63f643ea7dd6f7a61df60663c1fa78580bcb9adb4d1b0ca4a68fab2d4a0ed1`
- reference.json: `0431ce88a659611358b35d0672337137544149ab79709641c36b2dcb4a4343eb`
- Runner.swift: `8f50f13ef8fcddc51d3521e6311992ebae2778f5635957f381f6a392ff61e4a1`

The 15 families, 45 instances, 452 actions, all operation IDs/inputs/order, 320
literal/relational expectations, public semantics, learning policies and accepted
samples remain unchanged. No source, dictionary, product API/binary/build/native
or device access occurred. The only new input was the expressly authorized v1
independent report/receipt/packet, containing synthetic observations only. No
post-reveal tuning occurred. New independent v2 review and final parent freeze
must precede the one paired product execution. This reporting correction adds no
new native/product prerequisite and makes no population or UX accuracy claim.
