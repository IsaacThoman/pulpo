#!/usr/bin/env python3
"""Verify frozen action/oracle bookkeeping and symbolic sample-stream relations.
Only public Foundation reference results and author-owned declarations are read.
"""
from pathlib import Path
import json,sys
D=Path(__file__).resolve().parent
def need(v,s):
 if not v:raise RuntimeError(s)
def read(n):return json.loads((D/n).read_text())
def main():
 f=read('fixtures.json');e=read('expectations.json');r=read('reference.json');refs={x['id']:x for x in r['learn']}
 need(len(refs)==len(r['learn']),'reference unique IDs')
 ids=set();sessions={};centers=set();snap={};settled={};accepted=0;invalid=0
 for o in f['operations']:
  id=o['id'];op=o['op'];v=o['input'];sid=o.get('session');expect=e['operations'][id]
  need(id not in ids,'unique action ID');ids.add(id)
  need(set(o)==({'id','op','input','session'} if sid else {'id','op','input'}),'action keys')
  if op=='center':need(set(v)=={'byte'} and type(v['byte']) is int and 97<=v['byte']<=122,'center binding');centers.add(chr(v['byte']));continue
  if op=='normalize':need(set(v)=={'text'} and type(v['text']) is str,'normalize binding');continue
  if op=='construct':
   need(sid not in sessions and set(v)=={'persistent'} and type(v['persistent']) is bool,'session construction')
   sessions[sid]={'persistent':v['persistent'],'learning':None,'stream':[]};settled[sid]=True
  else:need(sid in sessions,'existing session')
  s=sessions[sid]
  if op=='setLearning':need(set(v)=={'value'} and type(v['value']) is bool,'learning policy');s['learning']=v['value']
  elif op=='reopen':
   need(settled[sid],'reopen requires confirmed prior settlement');s['learning']=None
   if not s['persistent']:s['stream']=[]
  elif op=='learn':
   need(set(v)=={'text','target','taps'} and type(v['text']) is str and type(v['target']) is str and type(v['taps']) is list,'learn shape')
   for p in v['taps']:
    if p is None:continue
    need(type(p) is dict,'tap object')
    if 'base' in p:need(set(p)=={'base','dx','dy'} and p['base'] in centers and all(type(p[k]) in (float,int) for k in ('dx','dy')),'relative tap')
    else:need(set(p)=={'x','y'} and all(type(p[k]) in (int,float) or p[k] in ('nan','posInf','negInf') for k in ('x','y')),'direct tagged tap')
   a=refs[id];count=len(a['contributingOrigins']);ok=a['eligible'] and s['learning'] is True and (not s['persistent'] or count<=40)
   need(type(expect['returned']) is bool and expect['returned']==ok,'Foundation/public admission '+id)
   need(expect['status']==('ok' if ok else 'invalid'),'intentional status '+id)
   if ok:
    accepted+=1
    for i,b in enumerate(a['targetBytes']):
     if 97<=b<=122 and a['origins'][i]<len(v['taps']) and v['taps'][a['origins'][i]] is not None:
      s['stream'].append([b,v['taps'][a['origins'][i]]])
    settled[sid]=False
   else:invalid+=1;need(settled[sid],'rejection conservation requires settled prior teaching')
  elif op=='save':settled[sid]=True
  need(expect['learning']==s['learning'],'declared explicit policy '+id)
  snap[id]=list(s['stream'])
 for x in e['relations']:
  k=x['kind']
  if k=='equal':need(snap[x['left']]==snap[x['right']],'independent canonical stream equality')
  elif k=='changed':need(snap[x['left']]!=snap[x['right']],'nonvacuous accepted transition')
  elif k=='positive':need(len(snap[x['record']])>0,'accepted anchor')
  elif k=='zero':need(snap[x['record']]==[],'new nil-URL model')
  elif k=='all_keys_nonzero':need({b for b,p in snap[x['record']]}==set(range(97,123)),'all26 contributions')
  else:need(False,'unknown relation')
 need(set(e['operations'])==ids,'complete expected IDs')
 need(len(e['families'])>=12 and len(sessions)>=16,'minimum scope')
 result={'result':'pass','families':len(e['families']),'instances':len(sessions),'operations':len(f['operations']),'relations':len(e['relations']),'checks':len(f['operations'])+len(e['relations']),'learn_calls':accepted+invalid,'accepted_calls':accepted,'expected_invalid_calls':invalid,'normalize_calls':len(r['normalize']),'center_calls':26,'Foundation_runtime':r['runtime']}
 (D/'author-validation.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
