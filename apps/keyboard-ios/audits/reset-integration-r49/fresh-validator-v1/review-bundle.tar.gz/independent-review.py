from pathlib import Path
import sys,json,hashlib,collections,importlib.util,copy,gzip,tempfile
A=Path('/tmp/pulpo-r49-fresh-author-v1');D=Path('/tmp/pulpo-r49-fresh-validator-v1')
def need(v,msg):
 if not v:raise RuntimeError(msg)
def load(n):return json.loads((A/n).read_text())
f=load('fixtures.json');oracle=load('expectations.json');baseline=load('synthetic-raw.json');ops=f['operations'];index={o['id']:i for i,o in enumerate(ops)}
spec=importlib.util.spec_from_file_location('frozen_evaluate',A/'evaluate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mode='optimized' if sys.flags.optimize else 'normal'
counts=collections.Counter();action_ids=[];relation_ids=[]
def trace(frame,event,arg):
 if frame.f_code.co_filename==str(A/'evaluate.py'):
  if event=='call':counts['calls.'+frame.f_code.co_name]+=1
  if event=='line' and frame.f_code.co_name=='evaluate':
   line=frame.f_lineno
   if line==91:action_ids.append(frame.f_locals.get('o',{}).get('id'))
   if line==193:relation_ids.append(frame.f_locals.get('i'))
 return trace
# Line discovery avoids changing evaluator bytes or relying on hard-coded instrumentation.
lines=(A/'evaluate.py').read_text().splitlines()
operation_line=next(i+1 for i,x in enumerate(lines) if x.strip().startswith("exact_keys(r,['id'"))
relation_line=next(i+1 for i,x in enumerate(lines) if x.strip().startswith("ids=[r['record']]"))
def trace(frame,event,arg):
 if frame.f_code.co_filename==str(A/'evaluate.py'):
  if event=='call':counts['calls.'+frame.f_code.co_name]+=1
  if event=='line' and frame.f_code.co_name=='evaluate':
   if frame.f_lineno==operation_line:action_ids.append(frame.f_locals['o']['id'])
   if frame.f_lineno==relation_line:relation_ids.append(frame.f_locals['i'])
 return trace
sys.settrace(trace);code,report=m.evaluate(A/'synthetic-raw.json');sys.settrace(None)
need(code==0,'baseline');need(action_ids==[o['id'] for o in ops],'complete operation trace');need(relation_ids==list(range(len(oracle['relations']))),'complete relation trace')
(D/('trace-'+mode+'.json')).write_text(json.dumps({'synthetic_only':True,'code':code,'report':report,'operation_ids':action_ids,'relation_indices':relation_ids,'call_counts':counts,'operation_entry_line':operation_line,'relation_entry_line':relation_line},indent=2)+'\n')
# Novelty uses revealed programs only, never prior product outputs.
oldpath=Path('/tmp/pulpo-r48-paired-final-v2/author/author-review-v2/fixtures.json');old=json.loads(oldpath.read_text())
def program_map(rows):
 d=collections.defaultdict(list)
 for o in rows:
  if o.get('session') is not None:d[o['session']].append({'op':o['op'],'input':o['input']})
 return d
def stable(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'))
prior=program_map(old['operations']);fresh=program_map(ops);prior_by=collections.defaultdict(list)
for sid,p in prior.items():prior_by[stable(p)].append(sid)
dups=[{'fresh_case_id':sid,'revealed_case_ids':prior_by[stable(p)]} for sid,p in fresh.items() if stable(p) in prior_by]
old_controls=collections.defaultdict(list)
for o in old['operations']:
 if o.get('session') is None:old_controls[stable({'op':o['op'],'input':o['input']})].append(o['id'])
exposed=[{'fresh_case_id':o['id'],'revealed_case_ids':old_controls[stable({'op':o['op'],'input':o['input']})]} for o in ops if o.get('session') is None and stable({'op':o['op'],'input':o['input']}) in old_controls]
(D/'novelty.json').write_text(json.dumps({'old_fixture_sha256':hashlib.sha256(oldpath.read_bytes()).hexdigest(),'fresh_sessions':len(fresh),'revealed_sessions':len(prior),'exact_duplicate_sessions':len(dups),'duplicates':dups,'exposed_controls':exposed,'exposed_geometry_controls':sum(x['fresh_case_id'].startswith('center.') for x in exposed),'exposed_normalization_controls':sum(x['fresh_case_id'].startswith('normalize.') for x in exposed),'qualification':'Exact nonduplication is not new intent-family or population coverage evidence.'},indent=2)+'\n')
results=[];archive=gzip.open(D/('independent-inputs-'+mode+'.jsonl.gz'),'wt',encoding='utf8')
with tempfile.TemporaryDirectory(dir=D) as tmp:
 path=Path(tmp)/'raw.json'
 def run(name,value,want,target=None):
  data=json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False);path.write_text(data)
  try:code,rep=m.evaluate(path)
  except m.Invalid as e:code=2;rep={'result':'strict-invalid','error':str(e),'operations_denominator':len(ops),'checks_denominator':len(ops)+len(oracle['relations'])}
  need(code==want,name+' wrong code '+str(code));need(rep['operations_denominator']==452 and rep['checks_denominator']==772,name+' denominator')
  if target is not None:need(any(x.startswith('relation '+str(target)+':') for x in rep['failures']),name+' unenforced relation')
  sha=hashlib.sha256(data.encode()).hexdigest();archive.write(json.dumps({'id':name,'raw_sha256':sha,'raw':value},ensure_ascii=False,separators=(',',':'))+'\n')
  results.append({'id':name,'exit':code,'raw_sha256':sha,'report':rep})
  return rep
 for i,r in enumerate(oracle['relations']):
  v=copy.deepcopy(baseline);rows=v['operations'];a=rows[index[r.get('record',r.get('left'))]]
  if r['kind']=='equal':a['state']['weight']+=.123
  elif r['kind']=='changed':a['state']=copy.deepcopy(rows[index[r['right']]]['state'])
  elif r['kind']=='positive':a['state']['weight']=0
  elif r['kind']=='all_keys_nonzero':a['state']['offsets'][0]={'x':0,'y':0}
  elif r['kind']=='zero':a['state']['weight']=1
  run('target_relation_'+str(i),v,1,i)
 for j in range(53):
  v=copy.deepcopy(baseline);s=v['operations'][index['target_geometry.persistent.final']]['state']
  if j==0:s['weight']+=.1
  else:s['offsets'][(j-1)//2][('x','y')[(j-1)%2]]+=.01
  run('full_state_component_'+str(j),v,1)
 for i in range(len(ops)):
  v=copy.deepcopy(baseline);del v['operations'][i];run('missing_action_'+str(i),v,2)
 # Independent malformed and behavioral witnesses.
 cases=[]
 def add(name,fn,code):
  v=copy.deepcopy(baseline);fn(v);cases.append((name,v,code))
 def row(v,id):return v['operations'][index[id]]
 add('extra_action',lambda v:v['operations'].append(copy.deepcopy(v['operations'][0])),2)
 add('duplicate_id',lambda v:v['operations'][1].update(id=v['operations'][0]['id']),2)
 add('incorrect_literal',lambda v:row(v,'target_geometry.local.seed')['input'].update(text='incorrect'),2)
 add('boolean_weight',lambda v:row(v,'target_geometry.local.seed')['state'].update(weight=True),2)
 add('wrong_dimensions',lambda v:row(v,'target_geometry.local.seed')['state'].update(offsets=[]),2)
 add('unsupported_status',lambda v:row(v,'target_geometry.local.seed').update(status='unsupported'),2)
 add('false_acceptance',lambda v:row(v,'target_geometry.local.seed').update(returned=False),1)
 add('false_rejection',lambda v:row(v,'transactional_invalid.local.invalid0').update(returned=True,status='ok'),1)
 add('nonfinite_observation_tag',lambda v:row(v,'target_geometry.local.seed')['state'].update(weight='nan'),2)
 def allzero(v):
  for r in v['operations']:
   if r['state'] is not None:r['state'].update(weight=0,offsets=[{'x':0,'y':0} for _ in range(26)])
 add('all_constant_zero',allzero,1)
 def unavailable_invalid(v):row(v,'transactional_invalid.local.invalid0').update(available=False,error='independent synthetic inventory unavailable')
 add('unavailable_intentional_invalid',unavailable_invalid,1)
 def unfired_invalid(v):row(v,'transactional_invalid.local.invalid0').update(available=False,invoked=False,error='independent blocked',returned=None,status=None,state=None,resolvedInput=None,files=[])
 add('unfired_intentional_invalid',unfired_invalid,1)
 for status in ['busy','capacity','io','uncertain','cleanup']:
  add('unavailable_observed_'+status,lambda v,s=status:row(v,'target_geometry.local.seed').update(available=False,error='independent synthetic inventory failure',status=s),1)
 def unavailable_constructor(v):
  r=row(v,'target_geometry.persistent.construct');r.update(available=False,error='independent inventory failure');r['state'].update(weight=0,offsets=[{'x':0,'y':0} for _ in range(26)])
 add('unavailable_ok_zero_constructor',unavailable_constructor,1)
 for name,v,code in cases:run(name,v,code)
archive.close()
(D/('independent-results-'+mode+'.json')).write_text(json.dumps({'synthetic_only':True,'mode':mode,'cases':len(results),'results':results},indent=2)+'\n')
print(json.dumps({'mode':mode,'independent_cases':len(results),'trace_operations':len(action_ids),'trace_relations':len(relation_ids),'exact_duplicate_sessions':len(dups),'exposed_controls':len(exposed),'trace_call_counts':counts},sort_keys=True))
