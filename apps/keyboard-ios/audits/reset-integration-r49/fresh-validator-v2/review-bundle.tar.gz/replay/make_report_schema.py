from pathlib import Path
import json
D=Path(__file__).resolve().parent
strict=lambda props:{'type':'object','additionalProperties':False,'required':list(props),'properties':props}
count={'type':'integer','minimum':0};ids={'type':'array','items':{'type':'string'},'uniqueItems':True};status={'enum':['ok','invalid','busy','capacity','io','uncertain','cleanup']};boolean={'type':'boolean'};nullable_status={'enum':[None,'ok','invalid','busy','capacity','io','uncertain','cleanup']}
planned=strict({'operations':{'const':452},'learn_calls':{'const':80},'expected_accepted_learn_calls':{'const':49},'intended_invalid_learn_calls':{'const':31}})
observed={}
for name in ('actual_invocation','actual_learn_call','observed_true_learn_return','observed_true_ok_learn_outcome','verified_expected_accepted_learn','verified_intended_invalid_rejection','unexpected_learn_outcome','unavailable_operation','unfired_operation','unknown_learn_outcome','unknown_invoked_model_status','unexpected_observed_status','unexpected_storage_status'):
 observed[name+'_count']=count;observed[name+'_ids']=ids
observed['status_counts']=strict({k:count for k in status['enum']})
observed['status_ledger']={'type':'array','items':strict({'id':{'type':'string'},'status':status,'available':boolean,'expected_status':status,'unexpected':boolean})}
observed['learn_outcome_ledger']={'type':'array','items':strict({'id':{'type':'string'},'returned':{'type':['boolean','null']},'status':nullable_status,'available':boolean,'expected_returned':boolean,'expected_status':{'enum':['ok','invalid']},'classification':{'enum':['verified_expected_acceptance','verified_intended_invalid_rejection','unavailable_outcome','unexpected_outcome']}})}
known=strict({'format':{'const':'pulpo-r49-observed-accounting-v2'},'known':{'const':True},'planned':planned,'observed':strict(observed),'unknown_operation_ids':{'const':[]}})
unknown=strict({'format':{'const':'pulpo-r49-observed-accounting-v2'},'known':{'const':False},'planned':{'oneOf':[{'type':'null'},planned]},'observed':{'type':'null'},'unknown_operation_ids':{'oneOf':[{'type':'null'},ids]},'unknown_reason':{'type':'string','minLength':1}})
common={'result':{'enum':['pass','failure']},'operations_denominator':{'const':452},'checks_denominator':{'const':772},'families_denominator':{'const':15},'instances_denominator':{'const':45},'relations_denominator':{'const':320}}
for k in ('unavailable_operations','transport_unavailable_operations','unavailable_evidence_operations','unfired_operations','unavailable_relations','failure_count','diagnostic_message_count'):common[k]=count
common.update({'failure_count_unit':{'const':'diagnostic_messages_not_failed_aggregates'},'failures':{'type':'array','items':{'type':'string'}},'accounting':known})
invalid=strict({'result':{'const':'strict-invalid'},'error':{'type':'string'},'operations_denominator':{'oneOf':[{'type':'null'},{'const':452}]},'checks_denominator':{'oneOf':[{'type':'null'},{'const':772}]},'unavailable_operations':{'type':'null'},'unfired_operations':{'type':'null'},'accounting':unknown})
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$comment':'v2 reporting only. Counts/ID/ledger consistency is enforced against independent frozen synthetic countertruth by test_accounting.py. No aggregate pass numerator is derived from diagnostics. Strict-invalid raw reports all observed counts unknown.', 'oneOf':[strict(common),invalid]}
(D/'report-schema.json').write_text(json.dumps(schema,indent=2)+'\n')
