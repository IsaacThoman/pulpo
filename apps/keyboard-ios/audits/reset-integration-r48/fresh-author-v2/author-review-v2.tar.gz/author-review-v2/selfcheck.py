#!/usr/bin/env python3
"""Synthetic transport/oracle checks only: no product, no learned model formula."""
import copy, hashlib, json, pathlib, tempfile
import evaluate as E
P=pathlib.Path(__file__).resolve().parent
F=E.preflight();out=[];centers={};states={};files={};urls={}
for o in F['operations']:
    op=o['op'];sid=o['session'];i=o['input'];e=o['expect']
    r=dict(id=o['id'],op=op,session=sid,input=i,resolvedInput=None,returned=None,status=None,state=None,files=[],available=True,invoked=True,error=None)
    if op=='center':
        c=chr(i['byte']);centers[c]={'x':(i['byte']-97)%10/10,'y':.2};r['returned']=centers[c]
    elif op=='normalize':r['returned']=e['value']
    else:
        if op=='construct':
            states[sid]={'weight':0,'offsets':[{'x':0.,'y':0.} for _ in range(26)],'learning':False};files[sid]=[]
            urls[sid]='/synthetic-only/'+sid.replace('/','-')+'/TouchModel.json' if i['persistent'] else None;r['resolvedInput']={'url':urls[sid]}
        if op=='learn':
            taps=[]
            for p in i['taps']:
                if p is None:taps.append(None)
                elif 'base' in p:taps.append({k:centers[p['base']][k]+p['d'+k] for k in ['x','y']})
                else:taps.append(p)
            r['resolvedInput']={'text':i['text'],'target':i['target'],'taps':taps}
            if e['returned']:
                states[sid]['weight']+=1;states[sid]['offsets']=[{'x':.07,'y':-.05} for _ in range(26)]
        if op=='setLearning':states[sid]['learning']=i['value']
        if op=='save' and sid.endswith('/persistent'):files[sid]=[{'path':'TouchModel.json','bytes':10,'sha256':hashlib.sha256(b'synthetic!').hexdigest()}]
        if op=='reopen':states[sid]['learning']=False;r['resolvedInput']={'url':urls[sid]}
        r.update(returned=e['returned'],status=e['status'],state=copy.deepcopy(states[sid]),files=copy.deepcopy(files[sid]))
    out.append(r)
base={'format':'pulpo-r48-raw-v2','environment':{'compiler':'SYNTHETIC ONLY swiftlang-6.4.0.34.1','runtime':'SYNTHETIC ONLY macOS 27.0.1 26A434','architecture':'arm64','productSourceSHA256':'0'*64,'runnerSHA256':E.hashfile(P/'Runner.swift'),'fixturesSHA256':E.hashfile(P/'fixtures.json'),'versionLabel':'synthetic-validator-control-only'},'operations':out}
results=[]
def run(name,raw,expected=True,needle=None):
    q=P/'synthetic-current.json';q.write_text(json.dumps(raw,allow_nan=False))
    result=None
    try:result=E.evaluate(q);passed=result['pass'];failed=result['failedCheckIDs'];error=None
    except E.Invalid as ex:passed=False;failed=[];error=str(ex)
    E.need(passed==expected,'probe '+name+' unexpected result')
    if needle is not None:E.need(any(needle in x for x in failed),'probe '+name+' missed intended relation')
    results.append({'id':name,'expectedPass':expected,'observedPass':passed,'validationError':error,'failedChecks':len(failed)})
    return result
def probe(name,fn,needle=None):
    r=copy.deepcopy(base);fn(r);return run(name,r,False,needle)
def rec(raw,id):return next(r for r in raw['operations'] if r['id']==id)
run('synthetic-valid-control',base)
probe('unknown-field',lambda r:r.update(unknown=True))
probe('missing-record',lambda r:r['operations'].pop())
probe('duplicate-ID',lambda r:r['operations'][1].update(id=r['operations'][0]['id']))
probe('swap-order',lambda r:r['operations'].reverse())
probe('wrong-action',lambda r:r['operations'][0].update(op='normalize'))
probe('input-binding',lambda r:rec(r,'normalize/accent_marks')['input'].update(text='corrupt'))
probe('return-bool-coercion',lambda r:rec(r,'accent_marks/local/seed').update(returned=1))
probe('25-offsets',lambda r:rec(r,'accent_marks/local/seed')['state']['offsets'].pop())
probe('missing-coordinate',lambda r:rec(r,'accent_marks/local/seed')['state']['offsets'][0].pop('y'))
probe('unknown-coordinate',lambda r:rec(r,'accent_marks/local/seed')['state']['offsets'][0].update(z=0))
probe('nonfinite-state-tag',lambda r:rec(r,'accent_marks/local/seed')['state'].update(weight='nan'))
probe('resolved-tag-mismatch',lambda r:rec(r,'late_nonfinite/local/step0')['resolvedInput']['taps'][-1].update(x='negInf'))
probe('missing-resolved-input',lambda r:rec(r,'accent_marks/local/seed').update(resolvedInput=None))
probe('unavailable-is-not-invalid',lambda r:rec(r,'late_nonfinite/persistent/step0').update(available=False,error='synthetic unavailable'),'/available')
probe('uninvoked-is-not-invalid',lambda r:rec(r,'late_nonfinite/persistent/step0').update(available=False,invoked=False,error='synthetic blocked'),'/available')
probe('unavailable-malformed-state',lambda r:rec(r,'late_nonfinite/persistent/step0').update(available=False,error='synthetic unavailable',state={'junk':False}))
probe('reload-false-ok-status',lambda r:rec(r,'accent_marks/persistent/reopenedReload').update(status='invalid'),'/status')
probe('constructor-busy-zeros',lambda r:rec(r,'accent_marks/persistent/construct').update(status='busy'),'/status')
probe('invalid-teaches',lambda r:rec(r,'late_nonfinite/persistent/step0')['state'].update(weight=9),'/projectionEq')
probe('invalid-file-content-change',lambda r:rec(r,'late_nonfinite/persistent/step0')['files'][0].update(sha256='f'*64),'/filesEq')
probe('save-state-change',lambda r:rec(r,'accent_marks/persistent/step0/save')['state'].update(weight=19),'/projectionEq')
probe('reopen-all26-coordinate',lambda r:rec(r,'accent_marks/persistent/reopen')['state']['offsets'][25].update(y=.3),'/projectionEq')
probe('accepted-no-teaching',lambda r:rec(r,'accent_marks/local/step0')['state'].update(weight=1),'/projectionDiffersFrom')
probe('persistent-empty-durable-inventory',lambda r:rec(r,'accent_marks/persistent/settle').update(files=[]),'/nonemptyFiles')
probe('full-state-cross-mode',lambda r:rec(r,'accent_marks/persistent/step0')['state']['offsets'][24].update(x=.31),'relation/accent_marks/equivalent-step0')
probe('weight-cross-mode',lambda r:rec(r,'accent_marks/persistent/step0')['state'].update(weight=7),'relation/accent_marks/equivalent-step0')
probe('bounds',lambda r:rec(r,'accent_marks/local/step0')['state']['offsets'][0].update(x=.401),'/state-shape-finite-bounds')
probe('unknown-file-field',lambda r:rec(r,'accent_marks/persistent/settle')['files'][0].update(mtime=0))
probe('duplicate-file',lambda r:rec(r,'accent_marks/persistent/settle')['files'].append(copy.deepcopy(rec(r,'accent_marks/persistent/settle')['files'][0])))
probe('wrong-reopen-url',lambda r:rec(r,'accent_marks/persistent/reopen')['resolvedInput'].update(url='/synthetic-only/other/TouchModel.json'))
# Version-2 regressions: policy defaults are observed only, and actual invocation
# facts remain separate from available verified evidence and retained statuses.
r=copy.deepcopy(base)
for row in r['operations']:
    if row['op'] in ['construct','reopen']:row['state']['learning']=True
run('unspecified-initial-reopen-policy-true',r)
r=copy.deepcopy(base)
for index,row in enumerate(r['operations']):
    if row['op'] in ['construct','reopen']:row['state']['learning']=bool(index%2)
run('unspecified-initial-reopen-policy-mixed',r)
probe('explicit-initial-policy-setter-required',lambda r:rec(r,'accent_marks/local/setupLearning')['state'].update(learning=False),'/learning')
probe('explicit-reopen-policy-setter-required',lambda r:rec(r,'accent_marks/persistent/reopenedSetupLearning')['state'].update(learning=False),'/learning')
result=probe('unavailable-invoked-invalid-credit',lambda r:rec(r,'late_nonfinite/persistent/step0').update(available=False,error='synthetic inventory failure'),'/available')
E.need(result['actualAccounting']['observedExpectedInvalidRejections']==12 and result['actualAccounting']['actualLearnInvocations']==76 and result['actualAccounting']['executedActions']==375,'unavailable invalid must not earn verified rejection credit or erase invocation')
result=probe('unavailable-invoked-accepted-credit',lambda r:rec(r,'accent_marks/persistent/step0').update(available=False,error='synthetic inventory failure'),'/available')
E.need(result['actualAccounting']['observedAcceptedLearnCalls']==62 and result['actualAccounting']['actualLearnInvocations']==76,'unavailable accepted must not earn verified acceptance credit')
result=probe('unavailable-retained-busy-status',lambda r:rec(r,'late_nonfinite/persistent/step0').update(available=False,status='busy',error='synthetic inventory failure'),'/available')
E.need(result['unexpectedStatusCallIDs']==['late_nonfinite/persistent/step0'] and result['actualAccounting']['unexpectedStatuses']==1 and result['actualAccounting']['unavailableActions']==1 and result['actualAccounting']['observedExpectedInvalidRejections']==12,'unavailable invoked busy must preserve overlapping status/availability facts')
result=probe('unavailable-retained-io-status',lambda r:rec(r,'accent_marks/persistent/step0').update(available=False,status='io',error='synthetic inventory failure'),'/available')
E.need(result['unexpectedStatusCallIDs']==['accent_marks/persistent/step0'] and result['actualAccounting']['unexpectedStatuses']==1 and result['actualAccounting']['observedAcceptedLearnCalls']==62,'unavailable invoked io must preserve unexpected status without acceptance credit')
result=probe('unfired-derived-busy-status',lambda r:rec(r,'late_nonfinite/persistent/step0').update(available=False,invoked=False,status='busy',returned=None,state=None,resolvedInput=None,files=[],error='synthetic blocked'),'/available')
E.need(result['unexpectedStatusCallIDs']==[] and result['actualAccounting']['unexpectedStatuses']==0 and result['actualAccounting']['actualLearnInvocations']==75 and result['actualAccounting']['executedActions']==374 and result['actualAccounting']['observedExpectedInvalidRejections']==12,'unfired derived row cannot count as an observed actual unexpected status')
result=probe('unavailable-no-observed-status',lambda r:rec(r,'late_nonfinite/persistent/step0').update(available=False,status=None,error='synthetic unavailable observation'),'/available')
E.need(result['unexpectedStatusCallIDs']==[] and result['actualAccounting']['observedExpectedInvalidRejections']==12 and result['actualAccounting']['actualLearnInvocations']==76,'missing status has no actual unexpected-status or rejection credit')
# Parser-level invalid tokens and duplicate keys cannot be emitted through allow_nan=False.
for name,text in [('nonfinite-json-token','{"a":NaN}'),('overflow-number','{"a":1e999}'),('duplicate-json-key','{"a":1,"a":2}')]:
    q=P/'synthetic-current.json';q.write_text(text)
    try:E.read(q)
    except E.Invalid:results.append({'id':name,'expectedPass':False,'observedPass':False,'validationError':'parser rejected','failedChecks':0})
    else:raise E.Invalid('parser probe '+name+' unexpectedly passed')
(P/'synthetic-current.json').unlink()
(P/('selfcheck-optimized.json' if not __debug__ else 'selfcheck-normal.json')).write_text(json.dumps({'source':'synthetic only; no product observations','probes':results,'count':len(results),'pass':True},indent=2)+'\n')
print(json.dumps({'syntheticOnly':True,'probeCount':len(results),'pass':True,'optimized':not __debug__}))
