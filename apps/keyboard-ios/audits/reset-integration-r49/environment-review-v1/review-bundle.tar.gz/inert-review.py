from pathlib import Path
import hashlib,json,tarfile,io,copy,types,sys,contextlib,subprocess
D=Path('/tmp/pulpo-r49-environment-review-v1').resolve();A=Path('/tmp/pulpo-r49-fresh-author-v2');V=Path('/tmp/pulpo-r49-fresh-validator-v2');mode='optimized' if sys.flags.optimize else 'normal';P=D/mode;P.mkdir();audit=P/'owned-audit';audit.mkdir();driver=D/'driver-after.py.txt';ns={'__file__':str(driver),'__name__':'inert_driver'};exec(compile(driver.read_bytes(),str(driver),'exec'),ns)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,s):
 if not v:raise RuntimeError(s)
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def archive(path,files):
 with tarfile.open(path,'w:gz') as t:
  for name,data in files.items():
   x=tarfile.TarInfo(name);x.size=len(data);t.addfile(x,io.BytesIO(data))
# Copy the approved AUTHOR bundle only. Never open real product source archives.
(audit/'author.tar.gz').write_bytes((A/'author-bundle.tar.gz').read_bytes());(audit/'receipt.json').write_bytes((V/'receipt.json').read_bytes());cfg=json.loads((D/'paired-config-v3.json').read_text());cfg['author']['archive']='author.tar.gz';cfg['authorReview']['path']='receipt.json';cfg['versions']=[]
for variant in ['comparison','candidate']:
 files={'apps/keyboard-ios/PulpoKeyboardKit/Sources/KeyboardCore/Inert.swift':('// owned inert marker '+variant+'; never compiled\n').encode()};p=audit/(variant+'.tar.gz');archive(p,files);cfg['versions'].append({'name':variant,'archive':p.name,'archiveSHA256':sha(p),'files':{k:hashlib.sha256(v).hexdigest() for k,v in files.items()},'commit':'INERT_ONLY'})
config=audit/'config.json';write(config,cfg);events=[]
def fake_version(argv,**kw):
 need(argv==['swift','--version'],'unexpected tool query');events.append({'kind':'compiler-version','argv':argv});return 'INERT COMPILER: no Swift execution\n'
def fake_build(argv,**kw):
 need(argv[:2]==['swift','build'],'unexpected process');client=Path(argv[argv.index('--package-path')+1]);need(client.is_relative_to(P) if hasattr(client,'is_relative_to') else str(client).startswith(str(P)+'/'),'owned client');binary=client/'.build/release/BoundaryRunner';binary.parent.mkdir(parents=True);binary.write_bytes(('INERT DUMMY BINARY '+client.parent.name+'; NEVER EXECUTED\n').encode());events.append({'kind':'inert-build','argv':argv,'binary':str(binary),'binarySHA256':sha(binary)});return types.SimpleNamespace(returncode=0)
ns['subprocess']=types.SimpleNamespace(check_output=fake_version,run=fake_build,STDOUT=subprocess.STDOUT)
work=P/'prepared-owned';out=io.StringIO()
with contextlib.redirect_stdout(out):ns['prepare'](config,work,audit)
ledger=json.loads((work/'prepared.json').read_text());need(len(ledger['records'])==2,'two records');need(ledger['configSHA256']==sha(work/'config.json') and ledger['driverSHA256']==sha(driver),'ledger driver/config');need(ledger['authorRoot']=='author','flat author root .');need(len(events)==3,'only fake compiler+two inert builds')
raw=json.loads((A/'synthetic-raw.json').read_text());evalresults=[];envs={}
for r in ledger['records']:
 variant=r['name'];envpath=work/r['environment'];env=json.loads(envpath.read_text());binary=work/r['binary'];sm=work/r['sourceManifest'];actual=cfg['versions'][['comparison','candidate'].index(variant)]['files'];canonical=json.dumps(actual,sort_keys=True,separators=(',',':')).encode();need(sm.read_bytes()==canonical,'canonical source-manifest bytes')
 need(r['binarySHA256']==sha(binary) and r['environmentSHA256']==sha(envpath) and r['sourceInventorySHA256']==sha(sm) and r['authorReviewSHA256']==sha(audit/'receipt.json'),'ledger hashes')
 need(set(env)=={'round','fixture_sha256','runner_sha256','execution'} and env['round']=='r49','top environment');need(set(env['execution'])=={'variant','binary_sha256','source_manifest_sha256','approval_sha256','compiler','platform'},'nested keys');e=env['execution'];need(e['variant']==variant and e['binary_sha256']==sha(binary) and e['source_manifest_sha256']==sha(sm) and e['approval_sha256']==sha(audit/'receipt.json'),'exact nested hashes');need(env['fixture_sha256']==ledger['fixturesSHA256']==sha(A/'fixtures.json') and env['runner_sha256']==ledger['runnerSHA256']==sha(A/'Runner.swift'),'runner fixture hashes');need(e['compiler']==ledger['compiler']=='INERT COMPILER: no Swift execution' and bool(e['platform']),'compiler/platform')
 envs[variant]=env
 for legacy in [False,True]:
  value=copy.deepcopy(raw)
  if legacy:value['environment']={'compiler':ledger['compiler'],'architecture':'INERT_ONLY','productSourceSHA256':sha(sm),'runnerSHA256':sha(A/'Runner.swift'),'fixturesSHA256':sha(A/'fixtures.json'),'versionLabel':variant}
  else:value['environment']=copy.deepcopy(env)
  value['environment']['runtime']=raw['environment']['runtime'];path=P/(variant+('-legacy' if legacy else '-adapted')+'-synthetic.json');write(path,value);proc=subprocess.run([sys.executable]+(['-O'] if sys.flags.optimize else [])+[str(A/'evaluate.py'),str(path)],text=True,capture_output=True);need(proc.returncode==(2 if legacy else 0),'frozen evaluator transport compatibility');rep=json.loads(proc.stdout);need(rep['operations_denominator']==452 and rep['checks_denominator']==772,'evaluator fixed denominators');evalresults.append({'variant':variant,'legacy':legacy,'exit':proc.returncode,'raw_sha256':sha(path),'report':rep,'stderr':proc.stderr})
# Inconsistent approval claims/labels must reject before work or compiler side effects.
guards=[]
def challenge(name,mutate,receipt_mutate=None):
 v=copy.deepcopy(cfg);receipt=json.loads((audit/'receipt.json').read_text())
 if receipt_mutate:
  receipt_mutate(receipt);rp=audit/(name+'-receipt.json');write(rp,receipt);v['authorReview']={'path':rp.name,'sha256':sha(rp)}
 mutate(v);cp=audit/(name+'-config.json');write(cp,v);w=P/(name+'-work');before=len(events);err=None
 try:
  with contextlib.redirect_stdout(io.StringIO()):ns['prepare'](cp,w,audit)
 except (ValueError,KeyError) as e:err=str(e)
 need(err is not None and not w.exists() and len(events)==before,name+' failed prework guard');guards.append({'id':name,'error':err,'work_created':False,'compiler_calls':0,'build_calls':0})
challenge('receipt_sha',lambda v:v['authorReview'].update(sha256='0'*64))
challenge('receipt_verdict',lambda v:None,lambda r:r.update(verdict='REJECT'))
for field in ['author_archive_sha256','author_manifest_sha256','evaluator_sha256']:
 challenge('receipt_'+field,lambda v:None,lambda r,k=field:r.update({k:'0'*64}))
challenge('config_archive_binding',lambda v:v['author'].update(archiveSHA256='0'*64))
challenge('config_manifest_binding',lambda v:v['author']['files'].update({'author-manifest.json':'0'*64}))
challenge('config_evaluator_binding',lambda v:v['author']['files'].update({'evaluate.py':'0'*64}))
challenge('missing_review',lambda v:v.pop('authorReview'))
challenge('legacy_labels',lambda v:[x.update(name=n) for x,n in zip(v['versions'],['original-a9e','integrated-82165'])])
challenge('missing_variant',lambda v:v['versions'].pop())
challenge('duplicate_variant',lambda v:v['versions'][1].update(name='comparison'))
challenge('unknown_variant',lambda v:v['versions'][1].update(name='unknown'))
challenge('extra_variant',lambda v:v['versions'].append(copy.deepcopy(v['versions'][0])))
challenge('missing_variant_name',lambda v:v['versions'][1].pop('name'))
write(P/'result.json',{'mode':mode,'stage_stdout':out.getvalue(),'inert_process_events':events,'ledger':ledger,'environments':envs,'frozen_evaluator_results':evalresults,'prework_guards':guards,'real_compiles':0,'product_executions':0,'actual_product_archives_read':0,'root_flat_dot_verified':True,'source_manifest_bytes_verified':True})
print(json.dumps({'mode':mode,'prepared_variants':2,'flat_root_verified':True,'ledger_environment_hashes_verified':True,'frozen_evaluator_adapted_passes':2,'legacy_strict_rejections':2,'prework_guards':len(guards),'real_compiles':0,'product_executions':0},sort_keys=True))
