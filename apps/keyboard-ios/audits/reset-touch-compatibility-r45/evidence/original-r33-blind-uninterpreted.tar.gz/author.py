import json, math
from pathlib import Path
P=Path('/tmp/pulpo-r33-blind')
cases=[]
def case(desc):
 c={'id':f'R33-B{len(cases)+1:02d}','description':desc,'actions':[]}; cases.append(c); return c['actions']
def add(a,actor,op,expected=None,**kw):
 v=dict(op=op,actor=actor,**kw)
 if expected is not None: v['expected']=expected
 a.append(v)
def new(a,n,memory=False): add(a,n,'new',{'dictionary':'ok','touch':'ok'},**({'memory':True} if memory else {}))
def mutate(a,n,op='learn',result='ok',**kw): add(a,n,op,{'accepted':result=='ok','result':result},**kw)
def learn(a,n,w,h=None,p=False): mutate(a,n,word=w,**({'after':h} if h else {}),**({'pinned':True} if p else {}))
def touch(a,n,w,x,y): mutate(a,n,'touch',word=w,dx=x,dy=y)
def save(a,n,store='both',result='ok'): add(a,n,'save',dict(completed=result=='ok',**{s:result for s in (['dictionary','touch'] if store=='both' else [store])}),store=store)
def clear(a,n,store='both',result='ok'): add(a,n,'clear',{'completed':result=='ok','result':result},store=store)
def reload(a,n,store='both'): add(a,n,'reload',{s:{'result':'ok'} for s in (['dictionary','touch'] if store=='both' else [store])},store=store)
def check(a,n,f,e,**kw): add(a,n,'check',e,field=f,**kw)
def count(a,n,w,e): check(a,n,'count',e,word=w)
def pair(a,n,h,w,e): check(a,n,'pair',e,word=w,after=h)
def arm(a,n,g): add(a,n,'arm',{'armed':True},gate=g)
def ctl(a,n,op): add(a,n,op)
def send(a,n,op,**kw): add(a,n,'send',action=dict(op=op,**kw))
def receive_save(a,n,store='both'): add(a,n,'receive',dict(completed=True,**{s:'ok' for s in (['dictionary','touch'] if store=='both' else [store])}))
def bg(a,n,store='both'): add(a,n,'background',{'enqueued':True},store=store)
def zeros(a,n,w): count(a,n,w,0); check(a,n,'touchWeight',0.0)
# Independent aggregate model, solely the frozen supplement equation.
class Touch:
 def __init__(self): self.s={chr(i):[0.,0.,0.] for i in range(97,123)}
 def offset(self,k):
  t=[sum(v[j] for v in self.s.values()) for j in range(3)]; v=self.s[k]
  return tuple(max(-.4,min(.4,(v[j]+12*t[j]/(t[2]+24))/(v[2]+12))) for j in (0,1))
 def word(self,w,x,y):
  refs={k:self.offset(k) for k in set(w)}
  for k in w:
   rx,ry=refs[k]; d=math.hypot(x-rx,y-ry); q=min(1.,.45/d) if d else 1.
   sx,sy=rx+(x-rx)*q,ry+(y-ry)*q; v=self.s[k]
   if v[2]+1>300:
    scale=299/v[2]; v[:]=[z*scale for z in v]
   v[0]+=sx; v[1]+=sy; v[2]+=1
 def checks(self,a,n,letters):
  check(a,n,'touchWeight',sum(v[2] for v in self.s.values()))
  for k in letters:
   x,y=self.offset(k); check(a,n,'offsetX',x,word=k); check(a,n,'offsetY',y,word=k)
# 1
A=case('Distinct process merge with exact spellings, lowercase histories, and existing pin count preservation.')
new(A,'reed'); new(A,'ibis'); learn(A,'reed','wayfarer','YONDER'); learn(A,'reed','wayfarer','YONDER'); learn(A,'ibis','azucena','Yonder'); mutate(A,'reed','pin',word='wayfarer'); save(A,'ibis','dictionary'); save(A,'reed','dictionary'); new(A,'lens'); count(A,'lens','wayfarer',2); count(A,'lens','azucena',1); pair(A,'lens','yonder','wayfarer',2); pair(A,'lens','yonder','azucena',1); check(A,'lens','history',3,after='yonder'); check(A,'lens','total',3); check(A,'lens','known',True,word='wayfarer'); check(A,'lens','known',False,word='azucena')
# 2
A=case('Normalized case accent apostrophe forget revokes pending equivalents, removes pair targets, retains history use, then permits relearn and missing pin.')
new(A,'sprig'); new(A,'moth'); learn(A,'sprig','Églantine','Atrio'); learn(A,'sprig','eglantine','Atrio'); learn(A,'sprig','brezal','Églantine'); save(A,'sprig'); learn(A,'moth','Eglan’tine','Atrio'); mutate(A,'sprig','forget',word="EGLAN'TINE"); save(A,'moth'); new(A,'glass'); count(A,'glass','Églantine',0); count(A,'glass','eglantine',0); count(A,'glass','Eglan’tine',0); count(A,'glass','brezal',1); pair(A,'glass','atrio','Églantine',0); pair(A,'glass','églantine','brezal',1); check(A,'glass','blocked',True,word='églantine'); reload(A,'moth'); learn(A,'moth','Églantine','Atrio'); mutate(A,'moth','pin',word='Eglan’tine'); save(A,'moth'); reload(A,'glass'); count(A,'glass','Églantine',1); count(A,'glass','Eglan’tine',1); check(A,'glass','known',True,word='Eglan’tine'); check(A,'glass','known',False,word='Églantine'); check(A,'glass','blocked',False,word='eglantine'); pair(A,'glass','atrio','Églantine',1); check(A,'glass','total',3)
# 3
A=case('Combined reset revokes both pending stores; the same surviving owner admits new dictionary and touch learning afterward.')
new(A,'old'); new(A,'eraser'); learn(A,'old','alambique','umbria'); touch(A,'old','raffia',.12,-.08); clear(A,'eraser'); save(A,'old'); new(A,'zero'); zeros(A,'zero','alambique'); learn(A,'old','starling','Alba'); touch(A,'old','raffia',-.07,.04); save(A,'old'); new(A,'later'); count(A,'later','alambique',0); count(A,'later','starling',1); pair(A,'later','alba','starling',1); t=Touch(); t.word('raffia',-.07,.04); t.checks(A,'later','r')
# 4
A=case('Dictionary-only reset revokes pending dictionary while preserving independently pending touch at a sibling save boundary.')
new(A,'owner'); new(A,'knife'); learn(A,'owner','verdigris','Dintel'); touch(A,'owner','vellum',.16,.06); clear(A,'knife','dictionary'); save(A,'owner','touch'); new(A,'view'); count(A,'view','verdigris',0); pair(A,'view','dintel','verdigris',0); t=Touch(); t.word('vellum',.16,.06); t.checks(A,'view','v'); mutate(A,'owner','pin',word='saúco'); save(A,'owner'); reload(A,'view'); count(A,'view','saúco',1); check(A,'view','known',True,word='saúco')
# 5
A=case('Touch-only reset preserves dictionary pending operations and durable blocked preference; later touch starts empty.')
new(A,'one'); new(A,'two'); mutate(A,'one','forget',word='escarcha'); learn(A,'one','bracken','Portico'); touch(A,'one','saffron',-.14,.05); clear(A,'two','touch'); save(A,'one','dictionary'); new(A,'three'); count(A,'three','bracken',1); pair(A,'three','portico','bracken',1); check(A,'three','blocked',True,word='ESCARCHA'); check(A,'three','touchWeight',0.0); touch(A,'one','saffron',.05,-.09); save(A,'one'); reload(A,'three'); t=Touch(); t.word('saffron',.05,-.09); t.checks(A,'three','s')
# 6
A=case('Nil-URL actors are isolated; transient known words survive local and persistent combined clear without becoming durable.')
new(A,'local',True); new(A,'other',True); new(A,'disk'); add(A,'local','transient',{'accepted':True},words=['ravelstone','luciérnaga']); learn(A,'local','gossamer','Juncia'); touch(A,'local','tussock',.08,.11); save(A,'local'); count(A,'other','gossamer',0); check(A,'other','touchWeight',0.0); count(A,'disk','gossamer',0); clear(A,'local'); count(A,'local','gossamer',0); check(A,'local','touchWeight',0.0); check(A,'local','known',True,word='luciérnaga'); add(A,'disk','transient',{'accepted':True},words=['ravelstone']); learn(A,'disk','hinojal'); clear(A,'disk'); check(A,'disk','known',True,word='ravelstone'); save(A,'disk'); new(A,'reader'); check(A,'reader','known',False,word='ravelstone'); check(A,'reader','total',0)
# 7
A=case('Own asynchronous requests coalesce; explicit completed saves establish both-store persistence and repeat-save idempotence.')
new(A,'swift'); learn(A,'swift','moonwort','Zaguán'); touch(A,'swift','thimble',.09,-.13); bg(A,'swift'); bg(A,'swift','dictionary'); bg(A,'swift','touch'); save(A,'swift'); check(A,'swift','dirty',False); learn(A,'swift','moonwort','Zaguán'); touch(A,'swift','thimble',-.1,.07); bg(A,'swift'); save(A,'swift'); save(A,'swift'); new(A,'still'); count(A,'still','moonwort',2); pair(A,'still','zaguán','moonwort',2); t=Touch(); t.word('thimble',.09,-.13); t.word('thimble',-.1,.07); t.checks(A,'still','t')
# 8
A=case('Acknowledged stop before global acquisition allows a completed clear, then old writer reconciles both revoked stores without resurrection.')
new(A,'scribe'); new(A,'broom'); learn(A,'scribe','candelilla','Opalino'); touch(A,'scribe','briar',.18,-.06); arm(A,'scribe','beforeTransaction'); send(A,'scribe','save',store='both'); ctl(A,'scribe','waitGate'); ctl(A,'scribe','stop'); clear(A,'broom'); new(A,'clean'); zeros(A,'clean','candelilla'); ctl(A,'scribe','resume'); ctl(A,'scribe','release'); receive_save(A,'scribe'); new(A,'proof'); zeros(A,'proof','candelilla'); pair(A,'proof','opalino','candelilla',0); check(A,'scribe','dirty',False)
# 9
A=case('Stopped inside a real transaction holds the global lock: combined clear reports busy; after completion a clear removes both stores.')
new(A,'wren'); new(A,'ash'); learn(A,'wren','tamarisk','Arrecife'); touch(A,'wren','cress',.1,.14); arm(A,'wren','beforeCommit'); send(A,'wren','save',store='both'); ctl(A,'wren','waitGate'); ctl(A,'wren','stop'); clear(A,'ash',result='busy'); ctl(A,'wren','resume'); ctl(A,'wren','release'); receive_save(A,'wren'); new(A,'seen'); count(A,'seen','tamarisk',1); check(A,'seen','touchWeight',5.0); clear(A,'ash'); new(A,'blank'); zeros(A,'blank','tamarisk')
# 10
A=case('Killed precommit transaction rolls back; a slotless process resets after lock release, and subsequent admitted learning survives.')
new(A,'ember'); new(A,'rain'); learn(A,'ember','periwinkle','Umbral'); touch(A,'ember','flax',-.11,.09); arm(A,'ember','beforeCommit'); send(A,'ember','save',store='dictionary'); ctl(A,'ember','waitGate'); ctl(A,'ember','stop'); clear(A,'rain',result='busy'); ctl(A,'ember','kill'); clear(A,'rain'); new(A,'seed'); zeros(A,'seed','periwinkle'); learn(A,'seed','arrayán','Vistal'); touch(A,'seed','flax',.06,-.04); save(A,'seed'); new(A,'leaf'); count(A,'leaf','arrayán',1); count(A,'leaf','periwinkle',0); t=Touch(); t.word('flax',.06,-.04); t.checks(A,'leaf','f')
# 11
A=case('Kill after real commit before local acknowledgement retains one durable dictionary pair and one complete touch group.')
new(A,'bronze'); learn(A,'bronze','madrépora','Pórtico'); save(A,'bronze','dictionary'); new(A,'copper'); touch(A,'copper','quill',.17,.03); arm(A,'copper','afterCommitBeforeAck'); send(A,'copper','save',store='touch'); ctl(A,'copper','waitGate'); ctl(A,'copper','stop'); ctl(A,'copper','kill'); new(A,'silver'); count(A,'silver','madrépora',1); pair(A,'silver','pórtico','madrépora',1); t=Touch(); t.word('quill',.17,.03); t.checks(A,'silver','q'); save(A,'silver'); new(A,'tin'); count(A,'tin','madrépora',1); check(A,'tin','touchWeight',5.0)
# 12
A=case('Delayed acknowledgement holds locks after commit; busy reset, resume, and explicit save retry cannot duplicate payload.')
new(A,'cedar'); new(A,'elm'); learn(A,'cedar','nightjar','Juncal'); touch(A,'cedar','burdock',-.08,-.12); arm(A,'cedar','afterCommitBeforeAck'); send(A,'cedar','save',store='both'); ctl(A,'cedar','waitGate'); ctl(A,'cedar','stop'); clear(A,'elm','touch',result='busy'); ctl(A,'cedar','resume'); ctl(A,'cedar','release'); receive_save(A,'cedar'); save(A,'cedar'); reload(A,'elm'); count(A,'elm','nightjar',1); pair(A,'elm','juncal','nightjar',1); t=Touch(); t.word('burdock',-.08,-.12); t.checks(A,'elm','b'); check(A,'cedar','dirty',False)
# 13
A=case('One precommit save error leaves eligible pending payload intact and no fresh durable increments; retry commits both exactly once.')
new(A,'ochre'); learn(A,'ochre','espadana','Mirador'); touch(A,'ochre','sedge',.13,-.17); arm(A,'ochre','failCommit'); save(A,'ochre','dictionary','io'); check(A,'ochre','dirty',True); count(A,'ochre','espadana',1); new(A,'chalk'); zeros(A,'chalk','espadana'); save(A,'ochre','touch'); save(A,'ochre'); reload(A,'chalk'); count(A,'chalk','espadana',1); pair(A,'chalk','mirador','espadana',1); t=Touch(); t.word('sedge',.13,-.17); t.checks(A,'chalk','s'); save(A,'ochre'); check(A,'ochre','dirty',False)
# 14
A=case('A real successful payload COMMIT reported once as IOERR reconciles to success without duplicate dictionary or touch learning.')
new(A,'loom'); learn(A,'loom','bellwether','Solana'); touch(A,'loom','hemlock',.19,.11); arm(A,'loom','reportCommitError'); save(A,'loom','dictionary'); save(A,'loom'); new(A,'weft'); count(A,'weft','bellwether',1); pair(A,'weft','solana','bellwether',1); t=Touch(); t.word('hemlock',.19,.11); t.checks(A,'weft','h'); check(A,'loom','dirty',False)
# 15
A=case('Healthy immediate reconciliation of error-after-real-COMMIT admissions accepts one dictionary token and one separately owned touch token.')
new(A,'kite'); new(A,'tern'); arm(A,'kite','reportCommitError'); learn(A,'kite','aliso','Celaje'); arm(A,'tern','reportCommitError'); touch(A,'tern','merlin',-.16,.08); count(A,'kite','aliso',1); save(A,'tern'); save(A,'kite'); save(A,'tern'); new(A,'gull'); count(A,'gull','aliso',1); pair(A,'gull','celaje','aliso',1); t=Touch(); t.word('merlin',-.16,.08); t.checks(A,'gull','m')
# 16
A=case('Admission insert faults teach nothing; later explicit admissions use fresh identities; intentional byte and touch-length invalid inputs reject atomically.')
new(A,'clay'); new(A,'silt'); arm(A,'clay','failAdmission'); mutate(A,'clay',result='io',word='ambergris',after='Hondonada'); count(A,'clay','ambergris',0); check(A,'clay','dirty',False); arm(A,'silt','failAdmission'); mutate(A,'silt','touch',result='io',word='mallow',dx=.1,dy=-.1); check(A,'silt','touchWeight',0.0); mutate(A,'clay',result='invalid',word='ornamental'+'\u0301'*140); mutate(A,'silt','touch',result='invalid',word='z'*41,dx=.1,dy=.1); learn(A,'clay','ambergris','Hondonada'); touch(A,'silt','mallow',.1,-.1); save(A,'clay'); save(A,'silt'); new(A,'sand'); count(A,'sand','ambergris',1); pair(A,'sand','hondonada','ambergris',1); check(A,'sand','total',1); t=Touch(); t.word('mallow',.1,-.1); t.checks(A,'sand','m')
# 17
A=case('Eight lifetime owners bound admission; a ninth process still reads and resets both, cannot reclaim an acknowledged stopped owner before global acquisition, and learns only after killing that owner releases its slot.')
for i,w in enumerate(['oryxfern','nacarado','brumario','kelpstone','carrascal','mossbank','zarzalino','driftreed']):
 n=f'holder{i}'; new(A,n); learn(A,n,w)
arm(A,'holder0','beforeTransaction'); send(A,'holder0','save',store='dictionary'); ctl(A,'holder0','waitGate'); ctl(A,'holder0','stop'); new(A,'ninth'); mutate(A,'ninth',result='capacity',word='silverweed'); clear(A,'ninth'); mutate(A,'ninth',result='capacity',word='silverweed'); new(A,'witness'); check(A,'witness','total',0); check(A,'witness','touchWeight',0.0); ctl(A,'holder0','kill'); learn(A,'ninth','silverweed','Alcor'); save(A,'ninth')
for i in range(1,8): save(A,f'holder{i}')
new(A,'final'); count(A,'final','silverweed',1); check(A,'final','total',1); pair(A,'final','alcor','silverweed',1); check(A,'final','touchWeight',0.0)
# 18
A=case('Independent grouped nonlinear touch oracle covers radial clamp, fixed repeated-letter references, per-key decay beyond 300, and durable merge with a second process.')
new(A,'delta'); t=Touch()
for x,y in [(.8,.6),(-.9,.2),(.25,-.8),(.7,-.6),(-.6,-.7),(.35,.1),(.9,.9),(-.7,.5)]:
 touch(A,'delta','z'*40,x,y); t.word('z'*40,x,y)
t.checks(A,'delta','za'); save(A,'delta'); new(A,'sigma'); touch(A,'sigma','jazzy',-.65,-.55); t.word('jazzy',-.65,-.55); save(A,'sigma','touch'); reload(A,'delta'); t.checks(A,'delta','zaj'); new(A,'omega'); t.checks(A,'omega','zj')
P.joinpath('heldout.json').write_bytes((json.dumps(cases,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'draftCases':len(cases),'draftActions':sum(len(c['actions']) for c in cases)}))
