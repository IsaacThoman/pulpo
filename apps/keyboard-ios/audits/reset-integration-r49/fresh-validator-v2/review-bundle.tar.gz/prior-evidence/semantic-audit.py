from pathlib import Path
import json,collections,hashlib,math
A=Path('/tmp/pulpo-r49-fresh-author-v1');D=Path('/tmp/pulpo-r49-fresh-validator-v1')
def need(v,msg):
 if not v:raise RuntimeError(msg)
def read(n):return json.loads((A/n).read_text())
f=read('fixtures.json');e=read('expectations.json');ref=read('reference.json');refs={x['id']:x for x in ref['learn']};ops=f['operations'];snaps={};sessions={};states={};settled={};learns=[];actions=[];relations=[]
need(len({o['id'] for o in ops})==len(ops),'unique');need(set(e['operations'])=={o['id'] for o in ops},'complete oracle keys')
need(read('reference-requests.json')=={'normalize':[{'id':o['id'],'text':o['input']['text']} for o in ops if o['op']=='normalize'],'learn':[{'id':o['id'],**o['input']} for o in ops if o['op']=='learn']},'exact reference input binding')
centers=set();laststatus={};nulls=0
for o in ops:
 id=o['id'];op=o['op'];v=o['input'];sid=o.get('session');x=e['operations'][id]
 if op=='center':
  centers.add(chr(v['byte']));need(x=={'returned':'point','status':None,'learning':None,'zero':False},'center oracle')
 elif op=='normalize':need(x=={'returned':'reference','status':None,'learning':None,'zero':False},'normalize oracle')
 else:
  if op=='construct':
   need(sid not in sessions,'fresh instance');sessions[sid]={'persistent':v['persistent'],'policy':None,'words':[]};settled[sid]=True;laststatus[sid]='ok'
  s=sessions[sid];persistent=s['persistent'];wantret=None
  if op=='setLearning':s['policy']=v['value']
  elif op=='reopen':
   need(settled[sid],'settled before reopen');s['policy']=None;laststatus[sid]='ok'
   if not persistent:s['words']=[]
  elif op=='learn':
   need(s['policy'] is not None,'policy explicit before every learn');a=refs[id]
   need(len(a['typedBytes'])==len(a['origins']),'alignment');samples=[];bad=False
   if len(a['targetBytes'])>=2 and len(a['typedBytes'])==len(a['targetBytes']):
    for i,b in enumerate(a['targetBytes']):
     origin=a['origins'][i]
     if 97<=b<=122 and origin<len(v['taps']) and v['taps'][origin] is not None:
      p=v['taps'][origin]
      if any(type(z) is str for k,z in p.items() if k in ('x','y')):bad=True
      samples.append((b,p))
   accepted=bool(s['policy'] and samples and not bad and (not persistent or len(samples)<=40))
   need(x['returned'] is accepted,'admission')
   need(a['contributingOrigins']==[a['origins'][i] for i,b in enumerate(a['targetBytes']) if 97<=b<=122 and a['origins'][i]<len(v['taps']) and v['taps'][a['origins'][i]] is not None] if a['lengthMatches'] else a['contributingOrigins']==[],'actual contributors')
   wantret=accepted;laststatus[sid]='ok' if accepted else 'invalid'
   if accepted:s['words']=s['words']+[samples];settled[sid]=False
   else:need(settled[sid],'every rejected call starts settled')
   learns.append({'id':id,'accepted':accepted,'actual_contributing_samples':len(samples),'persistent':persistent,'contributing_nonfinite':bad})
  elif op=='save':settled[sid]=True;wantret=True;laststatus[sid]='ok'
  elif op=='reload':wantret='bool' if persistent else False;laststatus[sid]='ok'
  elif op not in ('observe','construct'):need(False,'unknown op')
  need(x['status']==laststatus[sid],'last-operation status');need(x['returned']==wantret and type(x['returned']) is type(wantret),'return oracle');need(x['learning'] is s['policy'],'no constructor default')
  need(x['persistent'] is persistent,'mode oracle');need(x['zero']==(op=='construct' or (op=='reopen' and not persistent)),'zero oracle')
  snaps[id]=json.loads(json.dumps(s['words']))
 actions.append({'id':id,'op':op,'literal_oracle_valid':True})
for i,r in enumerate(e['relations']):
 kind=r['kind'];ids=[r['record']] if 'record' in r else [r['left'],r['right']];a=snaps[ids[0]]
 if kind=='equal':
  need(a==snaps[ids[1]],'grouped per-word ordered samples equal')
  if r['files']:
   # Files invariance is only local no-I/O or intentional-frontguard/observe.
   aop=next(o for o in ops if o['id']==r['left']);bop=next(o for o in ops if o['id']==r['right'])
   need(aop.get('session')==bop.get('session'),'inventory same instance');need(bop['op'] in ('learn','observe'),'settled inventory scope')
 elif kind=='changed':need(a!=snaps[ids[1]] and bool(snaps[ids[1]]),'nonempty accepted transition')
 elif kind=='positive':need(bool(a),'accepted final anchor')
 elif kind=='all_keys_nonzero':need({b for word in a for b,p in word}==set(range(97,123)),'all26')
 elif kind=='zero':need(a==[],'local reopen')
 else:need(False,'relation kind')
 relations.append({'index':i,'kind':kind,'operands':ids,'grouped_word_semantics_valid':True})
# All complete symbolic representations stay private to this review packet.
result={'result':'pass','actions':actions,'learns':learns,'relations':relations,'counts':{'actions':len(actions),'relations':len(relations),'aggregate_checks':len(actions)+len(relations),'families':len(e['families']),'instances':len(sessions),'learn_calls':len(learns),'accepted':sum(x['accepted'] for x in learns),'invalid':sum(not x['accepted'] for x in learns),'construct_reopen_default_oracles':sum(x['learning'] is not None for o in ops if o['op'] in ('construct','reopen') for x in [e['operations'][o['id']]]),'relations_by_kind':dict(collections.Counter(x['kind'] for x in relations))},'qualification':'Same complete per-word sample groups are compared; no product update formula or API execution.'}
(D/'semantic-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['counts'],sort_keys=True))
