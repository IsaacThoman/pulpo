import Foundation
import CryptoKit

enum ProbeError: Error { case failed(String) }
func require(_ condition: Bool, _ message: String) throws { if !condition { throw ProbeError.failed(message) } }
func jsonEqual(_ a: Any, _ b: Any) throws -> Bool {
  try JSONSerialization.data(withJSONObject: a, options: [.sortedKeys]) == JSONSerialization.data(withJSONObject: b, options: [.sortedKeys])
}
@main struct Probes {
  static func main() throws {
    let fm = FileManager.default
    var ownedRoots: [URL] = []
    defer { for root in ownedRoots { try? fm.removeItem(at: root) } }
    var reports: [[String: Any]] = []
    func fresh(_ parent: URL = FileManager.default.temporaryDirectory) throws -> URL {
      let root = parent.appendingPathComponent("pulpo-r49-filesystem-probe-" + UUID().uuidString, isDirectory: true)
      try fm.createDirectory(at: root, withIntermediateDirectories: false)
      ownedRoots.append(root)
      return root
    }
    func report(_ id: String, _ detail: [String: Any] = [:]) { reports.append(detail.merging(["id": id, "pass": true], uniquingKeysWith: { _, b in b })) }
    func rejected(_ id: String, reason: String, reads: () -> Int, _ body: () throws -> Void) throws {
      do { try body(); throw ProbeError.failed(id + " unexpectedly accepted") }
      catch InventoryError.invalid(let actual) {
        try require(actual == reason, id + " wrong rejection: " + actual)
        try require(reads() == 0, id + " content was read before rejection")
        report(id, ["reason": actual, "contentReadAttempts": reads()])
      }
    }
    let root = try fresh()
    try require(try inventoryRegularFiles(nil).isEmpty, "nil inventory")
    report("nil-directory")
    try require(try inventoryRegularFiles(root).isEmpty, "empty root")
    report("empty-root")
    let nested = root.appendingPathComponent("nested", isDirectory: true)
    try fm.createDirectory(at: nested, withIntermediateDirectories: false)
    try Data("beta".utf8).write(to: nested.appendingPathComponent("z.txt"))
    try Data("alpha".utf8).write(to: root.appendingPathComponent("a.txt"))
    try Data().write(to: root.appendingPathComponent(".hidden"))
    let expected: [[String: Any]] = [
      ["path": ".hidden", "bytes": 0, "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"],
      ["path": "a.txt", "bytes": 5, "sha256": "8ed3f6ad685b959ead7022518e1af76cd816f8e8ec7ccdda1ed4018e8f2223f8"],
      ["path": "nested/z.txt", "bytes": 4, "sha256": "f44e64e75f3948e9f73f8dfa94721c4ce8cbb4f265c4790c702b2d41cfbf2753"]]
    var events: [(String, String)] = []
    let actual = try inventoryRegularFiles(root, diagnostic: { events.append(($0, $1)) })
    try require(try jsonEqual(actual, expected), "literal content inventory")
    for row in expected {
      let path = row["path"] as! String
      let stages = events.filter { $0.1 == path }.map { $0.0 }
      try require(stages == ["contained", "beforeRead", "afterRead"], "content ordering: " + path)
    }
    report("ordinary-leaves-hidden-nested-literal-hashes", ["entries": actual.count, "contentReadAttempts": events.filter { $0.0 == "beforeRead" }.count])
    try require(try jsonEqual(inventoryRegularFiles(root), expected), "repeat deterministic observation")
    report("deterministic-second-independent-observation")
    let canonicalRoot = inventoryCanonicalURL(root)
    try require(try jsonEqual(inventoryRegularFiles(canonicalRoot), expected), "canonical temp alias")
    let rawAttrs = try fm.attributesOfItem(atPath: root.path)
    let canonicalAttrs = try fm.attributesOfItem(atPath: canonicalRoot.path)
    try require((rawAttrs[.systemFileNumber] as? NSNumber) == (canonicalAttrs[.systemFileNumber] as? NSNumber) && (rawAttrs[.systemNumber] as? NSNumber) == (canonicalAttrs[.systemNumber] as? NSNumber), "temporary alias inode")
    report("actual-temporary-directory-canonical-alias", ["root": root.path, "canonicalRoot": canonicalRoot.path, "sameInode": true])
    let aliasRoot: URL?
    if canonicalRoot.path.hasPrefix("/private/var/") { aliasRoot = URL(fileURLWithPath: String(canonicalRoot.path.dropFirst("/private".count)), isDirectory: true) }
    else if canonicalRoot.path.hasPrefix("/var/") { aliasRoot = URL(fileURLWithPath: "/private" + canonicalRoot.path, isDirectory: true) }
    else { aliasRoot = nil }
    if let aliasRoot {
      try require(try jsonEqual(inventoryRegularFiles(aliasRoot), expected), "explicit var alias")
      var fromCanonical = try InventoryCollector(root: canonicalRoot)
      try fromCanonical.visit(aliasRoot.appendingPathComponent("a.txt"))
      try require(try jsonEqual(fromCanonical.sortedRows, [expected[1]]), "canonical root with aliased entry")
      report("canonical-root-aliased-entry-direct")
      var fromAlias = try InventoryCollector(root: aliasRoot)
      try fromAlias.visit(canonicalRoot.appendingPathComponent("a.txt"))
      try require(try jsonEqual(fromAlias.sortedRows, [expected[1]]), "aliased root with canonical entry")
      report("aliased-root-canonical-entry-direct")
      report("var-private-var-explicit-alias", ["root": aliasRoot.path, "canonicalRoot": canonicalRoot.path])
    } else { reports.append(["id": "var-private-var-explicit-alias", "pass": NSNull(), "skip": "actual temporary root does not use this system alias"]) }

    var isDirectory: ObjCBool = false
    if fm.fileExists(atPath: "/tmp", isDirectory: &isDirectory), isDirectory.boolValue,
       fm.fileExists(atPath: "/private/tmp", isDirectory: &isDirectory), isDirectory.boolValue,
       inventoryCanonicalURL(URL(fileURLWithPath: "/tmp")).path == inventoryCanonicalURL(URL(fileURLWithPath: "/private/tmp")).path {
      let tmpRoot = try fresh(URL(fileURLWithPath: "/tmp", isDirectory: true))
      try Data("alpha".utf8).write(to: tmpRoot.appendingPathComponent("a.txt"))
      let privateRoot = URL(fileURLWithPath: "/private/tmp", isDirectory: true).appendingPathComponent(tmpRoot.lastPathComponent, isDirectory: true)
      try require(try jsonEqual(inventoryRegularFiles(tmpRoot), inventoryRegularFiles(privateRoot)), "tmp/private-tmp alias")
      var crossTemporary = try InventoryCollector(root: tmpRoot)
      try crossTemporary.visit(privateRoot.appendingPathComponent("a.txt"))
      try require(crossTemporary.sortedRows.count == 1 && crossTemporary.sortedRows[0]["path"] as? String == "a.txt", "tmp root private-tmp entry")
      report("tmp-root-private-tmp-entry-direct")
      report("tmp-private-tmp-own-fresh-root", ["root": tmpRoot.path, "canonicalRoot": privateRoot.path])
    } else { reports.append(["id": "tmp-private-tmp-own-fresh-root", "pass": NSNull(), "skip": "system aliases unavailable"]) }

    let adversary = try fresh()
    let inside = adversary.appendingPathComponent("inside", isDirectory: true)
    let sibling = adversary.appendingPathComponent("inside-sibling", isDirectory: true)
    try fm.createDirectory(at: inside, withIntermediateDirectories: false)
    try fm.createDirectory(at: sibling, withIntermediateDirectories: false)
    let exteriorFile = sibling.appendingPathComponent("outside.txt")
    try Data("alpha".utf8).write(to: exteriorFile)
    let ordinary = inside.appendingPathComponent("ordinary.txt")
    try Data("beta".utf8).write(to: ordinary)
    var readAttempts = 0
    let diagnostic: (String, String) -> Void = { stage, _ in if stage == "beforeRead" { readAttempts += 1 } }
    try rejected("sibling-prefix-containment-before-read", reason: "inventory canonical escape", reads: { readAttempts }) {
      var collector = try InventoryCollector(root: inside, diagnostic: diagnostic); try collector.visit(exteriorFile)
    }
    try rejected("root-itself-is-not-descendant", reason: "inventory canonical escape", reads: { readAttempts }) {
      var collector = try InventoryCollector(root: inside, diagnostic: diagnostic); try collector.visit(inside)
    }
    try rejected("dotdot-traversal-before-read", reason: "inventory entry traversal", reads: { readAttempts }) {
      var collector = try InventoryCollector(root: inside, diagnostic: diagnostic)
      try collector.visit(URL(fileURLWithPath: inside.path + "/../inside-sibling/outside.txt"))
    }
    let outsideLeafLink = inside.appendingPathComponent("outside-link.txt")
    try fm.createSymbolicLink(at: outsideLeafLink, withDestinationURL: exteriorFile)
    try rejected("leaf-link-outside-before-read", reason: "inventory canonical escape", reads: { readAttempts }) {
      var collector = try InventoryCollector(root: inside, diagnostic: diagnostic); try collector.visit(outsideLeafLink)
    }
    try fm.removeItem(at: outsideLeafLink)
    let insideLeafLink = inside.appendingPathComponent("inside-link.txt")
    try fm.createSymbolicLink(at: insideLeafLink, withDestinationURL: ordinary)
    try rejected("leaf-link-inside-before-read", reason: "inventory entry link", reads: { readAttempts }) {
      var collector = try InventoryCollector(root: inside, diagnostic: diagnostic); try collector.visit(insideLeafLink)
    }
    try fm.removeItem(at: insideLeafLink)
    let outsideDirLink = inside.appendingPathComponent("outside-dir", isDirectory: true)
    try fm.createSymbolicLink(at: outsideDirLink, withDestinationURL: sibling)
    try rejected("interior-link-outside-before-read", reason: "inventory canonical escape", reads: { readAttempts }) {
      var collector = try InventoryCollector(root: inside, diagnostic: diagnostic); try collector.visit(outsideDirLink.appendingPathComponent("outside.txt"))
    }
    try fm.removeItem(at: outsideDirLink)
    let inner = inside.appendingPathComponent("inner", isDirectory: true)
    try fm.createDirectory(at: inner, withIntermediateDirectories: false)
    try Data("alpha".utf8).write(to: inner.appendingPathComponent("a.txt"))
    let insideDirLink = inside.appendingPathComponent("inside-dir", isDirectory: true)
    try fm.createSymbolicLink(at: insideDirLink, withDestinationURL: inner)
    try rejected("interior-link-inside-before-read", reason: "inventory entry link", reads: { readAttempts }) {
      var collector = try InventoryCollector(root: inside, diagnostic: diagnostic); try collector.visit(insideDirLink.appendingPathComponent("a.txt"))
    }
    try fm.removeItem(at: insideDirLink)
    let rootLink = adversary.appendingPathComponent("root-link", isDirectory: true)
    try fm.createSymbolicLink(at: rootLink, withDestinationURL: inside)
    try rejected("leaf-root-symlink", reason: "inventory root link", reads: { readAttempts }) { _ = try inventoryRegularFiles(rootLink, diagnostic: diagnostic) }
    // Real enumerator sees the link itself and must reject before any file read.
    let linkOnly = try fresh()
    try fm.createSymbolicLink(at: linkOnly.appendingPathComponent("a-link"), withDestinationURL: exteriorFile)
    try rejected("real-enumerator-symlink-rejection", reason: "inventory canonical escape", reads: { readAttempts }) { _ = try inventoryRegularFiles(linkOnly, diagnostic: diagnostic) }
    let finderAlias = inside.appendingPathComponent("finder-alias")
    let bookmark = try ordinary.bookmarkData(options: [.suitableForBookmarkFile], includingResourceValuesForKeys: nil, relativeTo: nil)
    try URL.writeBookmarkData(bookmark, to: finderAlias)
    try require(try finderAlias.resourceValues(forKeys: [.isAliasFileKey]).isAliasFile == true, "Finder alias fixture metadata")
    try rejected("finder-alias-before-content-read", reason: "inventory entry link", reads: { readAttempts }) {
      var collector = try InventoryCollector(root: inside, diagnostic: diagnostic); try collector.visit(finderAlias)
    }
    try fm.removeItem(at: finderAlias)
    var duplicate = try InventoryCollector(root: inside)
    try duplicate.visit(ordinary)
    try rejected("duplicate-before-second-content-read", reason: "inventory duplicate", reads: { readAttempts }) { try duplicate.visit(ordinary) }

    let fileLimit = 16 * 1024 * 1024
    let exactLeaf = try fresh()
    try Data(repeating: 0x51, count: fileLimit).write(to: exactLeaf.appendingPathComponent("limit.bin"))
    let exactRows = try inventoryRegularFiles(exactLeaf)
    try require(exactRows.count == 1 && exactRows[0]["bytes"] as? Int == fileLimit, "exact file byte limit")
    report("exact-sixteen-MiB-file-accepted", ["bytes": fileLimit])
    let overLeaf = try fresh()
    try Data(repeating: 0x52, count: fileLimit + 1).write(to: overLeaf.appendingPathComponent("over.bin"))
    try rejected("over-file-byte-bound-before-read", reason: "inventory pre-read bound", reads: { readAttempts }) { _ = try inventoryRegularFiles(overLeaf, diagnostic: diagnostic) }
    let totalRoot = try fresh()
    let first = totalRoot.appendingPathComponent("a.bin"), second = totalRoot.appendingPathComponent("b.bin"), third = totalRoot.appendingPathComponent("c.bin")
    try Data(repeating: 0x61, count: fileLimit).write(to: first)
    try Data(repeating: 0x62, count: fileLimit).write(to: second)
    let totalRows = try inventoryRegularFiles(totalRoot)
    try require(totalRows.count == 2 && totalRows.reduce(0, { $0 + ($1["bytes"] as! Int) }) == 32 * 1024 * 1024, "exact total byte limit")
    report("exact-thirty-two-MiB-total-accepted", ["bytes": 32 * 1024 * 1024])
    try Data([0x63]).write(to: third)
    var totalCollector = try InventoryCollector(root: totalRoot, diagnostic: diagnostic)
    try totalCollector.visit(first); try totalCollector.visit(second); readAttempts = 0
    try rejected("over-total-byte-bound-before-extra-read", reason: "inventory pre-read bound", reads: { readAttempts }) { try totalCollector.visit(third) }
    let countRoot = try fresh()
    for i in 0..<128 { try Data().write(to: countRoot.appendingPathComponent(String(format: "%03d", i))) }
    let countRows = try inventoryRegularFiles(countRoot)
    try require(countRows.count == 128, "exact file count")
    report("exact-128-files-accepted", ["files": countRows.count])
    var countCollector = try InventoryCollector(root: countRoot, diagnostic: diagnostic)
    for i in 0..<128 { try countCollector.visit(countRoot.appendingPathComponent(String(format: "%03d", i))) }
    let extra = countRoot.appendingPathComponent("128")
    try Data().write(to: extra); readAttempts = 0
    try rejected("129th-file-bound-before-read", reason: "inventory pre-read bound", reads: { readAttempts }) { try countCollector.visit(extra) }
    var original: String? = "inventory canonical escape"
    var blockedRows: [[String: Any]] = []
    for i in 0..<1000 {
      original = retainedBlockedReason(original, "session unavailable: " + original!)
      blockedRows.append(["id": "blocked-" + String(i), "available": false, "invoked": false, "error": original!])
    }
    try require(blockedRows.count == 1000 && Set(blockedRows.map { $0["id"] as! String }).count == 1000 && blockedRows.allSatisfy { ($0["error"] as? String) == "inventory canonical escape" && $0["available"] as? Bool == false && $0["invoked"] as? Bool == false }, "first blocked cause retention")
    try require(retainedBlockedReason(nil, "first") == "first" && retainedBlockedReason("first", "later") == "first", "first cause helper")
    report("first-blocked-reason-1000-explicit-unavailable-rows", ["rows": blockedRows.count, "maximumErrorBytes": blockedRows.map { ($0["error"] as! String).utf8.count }.max()!])
    let output: [String: Any] = ["format": "pulpo-r49-filesystem-probes-v1", "scope": "Foundation/CryptoKit real filesystem mechanics only; no product or benchmark acceptance evidence", "runtime": ProcessInfo.processInfo.operatingSystemVersionString, "pass": true, "probes": reports, "probeCount": reports.count, "productExecutions": 0, "rootsWereFreshAndOwned": true, "cleanup": "defer removes only probe-owned roots"]
    let data = try JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys])
    print(String(decoding: data, as: UTF8.self))
  }
}
