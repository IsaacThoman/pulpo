from pathlib import Path
D=Path(__file__).resolve().parent
p=D/'evaluate.py';s=p.read_text();s=s.replace("manifest['format']=='pulpo-r49-author-manifest-v1'","manifest['format']=='pulpo-r49-author-manifest-v2'")
insert='''def planned_accounting(expected,spec):
 return {'operations':len(expected),'learn_calls':sum(o['op']=='learn' for o in expected),'expected_accepted_learn_calls':sum(o['op']=='learn' and spec[o['id']]['returned'] is True for o in expected),'intended_invalid_learn_calls':sum(o['op']=='learn' and spec[o['id']]['returned'] is False and spec[o['id']]['status']=='invalid' for o in expected)}

def observed_accounting(expected,spec,rows):
 # Called only after ALL strict record/binding validation. Outcome verification
 # requires available, invoked, correctly typed matching expected return/status.
 # Invoked status claims are retained BEFORE availability filtering; an unfired
 # row's stale/null status is never an observed operation status.
 groups={k:[] for k in ('actual_invocation','actual_learn_call','observed_true_learn_return','observed_true_ok_learn_outcome','verified_expected_accepted_learn','verified_intended_invalid_rejection','unexpected_learn_outcome','unavailable_operation','unfired_operation','unknown_learn_outcome','unknown_invoked_model_status','unexpected_observed_status','unexpected_storage_status')}
 status_ledger=[];learn_ledger=[];status_counts={k:0 for k in ('ok','invalid','busy','capacity','io','uncertain','cleanup')}
 for o,r in zip(expected,rows):
  id=o['id'];e=spec[id]
  if not r['available']:groups['unavailable_operation'].append(id)
  if not r['invoked']:groups['unfired_operation'].append(id)
  if o['op']=='learn' and not (r['available'] and r['invoked']):groups['unknown_learn_outcome'].append(id)
  if not r['invoked']:continue
  groups['actual_invocation'].append(id)
  if o.get('session'):
   status=r['status']
   if status is None:groups['unknown_invoked_model_status'].append(id)
   else:
    unexpected=status!=e['status'];status_counts[status]+=1
    status_ledger.append({'id':id,'status':status,'available':r['available'],'expected_status':e['status'],'unexpected':unexpected})
    if unexpected:groups['unexpected_observed_status'].append(id)
    if status not in ('ok','invalid'):groups['unexpected_storage_status'].append(id)
  if o['op']!='learn':continue
  groups['actual_learn_call'].append(id)
  if r['returned'] is True:groups['observed_true_learn_return'].append(id)
  if r['returned'] is True and r['status']=='ok':groups['observed_true_ok_learn_outcome'].append(id)
  verified_accept=r['available'] and e['returned'] is True and r['returned'] is True and r['status']=='ok'
  verified_invalid=r['available'] and e['returned'] is False and e['status']=='invalid' and r['returned'] is False and r['status']=='invalid'
  if verified_accept:groups['verified_expected_accepted_learn'].append(id)
  if verified_invalid:groups['verified_intended_invalid_rejection'].append(id)
  unexpected_outcome=r['returned'] is not None and (not same(r['returned'],e['returned']) or (r['status'] is not None and r['status']!=e['status']))
  if unexpected_outcome:groups['unexpected_learn_outcome'].append(id)
  classification='verified_expected_acceptance' if verified_accept else 'verified_intended_invalid_rejection' if verified_invalid else 'unavailable_outcome' if not r['available'] else 'unexpected_outcome'
  learn_ledger.append({'id':id,'returned':r['returned'],'status':r['status'],'available':r['available'],'expected_returned':e['returned'],'expected_status':e['status'],'classification':classification})
 observed={}
 for name,ids in groups.items():observed[name+'_count']=len(ids);observed[name+'_ids']=ids
 observed['status_counts']=status_counts;observed['status_ledger']=status_ledger;observed['learn_outcome_ledger']=learn_ledger
 return {'format':'pulpo-r49-observed-accounting-v2','known':True,'planned':planned_accounting(expected,spec),'observed':observed,'unknown_operation_ids':[]}

def unknown_accounting(expected,spec):
 # Strict-invalid/missing/partial transport is not scored as zero activity. The
 # complete input failed validation, so observed counts are UNKNOWN (null), not
 # planned counts or fabricated fired/verified outcomes. No partial credit.
 return {'format':'pulpo-r49-observed-accounting-v2','known':False,'planned':planned_accounting(expected,spec),'observed':None,'unknown_operation_ids':[o['id'] for o in expected],'unknown_reason':'Strict-invalid input: no complete validated observation set; invocation/status/outcome counts are unknown, not zero.'}

'''
s=s.replace('def evaluate(raw_path):',insert+'def evaluate(raw_path):')
old="'expected_invalid_rejections':sum(e['status']=='invalid' and o['op']=='learn' for o in expected for e in [spec[o['id']]]),"
if old not in s:raise RuntimeError('legacy reporting field not found')
s=s.replace(old,"'accounting':observed_accounting(expected,spec,rows),")
s=s.replace("except Exception:den=None;checks=None", "except Exception:den=None;checks=None;f=None;o=None\n  accounting=unknown_accounting(f['operations'],o['operations']) if f is not None and o is not None else {'format':'pulpo-r49-observed-accounting-v2','known':False,'planned':None,'observed':None,'unknown_operation_ids':None,'unknown_reason':'Author declarations unavailable; all observed facts are unknown.'}")
s=s.replace("'unavailable_operations':None,'unfired_operations':None}","'unavailable_operations':None,'unfired_operations':None,'accounting':accounting}")
p.write_text(s)
p=D/'seal_manifest.py';s=p.read_text().replace('pulpo-r49-author-manifest-v1','pulpo-r49-author-manifest-v2');p.write_text(s)
