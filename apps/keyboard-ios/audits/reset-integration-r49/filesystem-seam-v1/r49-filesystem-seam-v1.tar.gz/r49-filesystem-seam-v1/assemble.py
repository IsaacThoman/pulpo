#!/usr/bin/env python3
"""Verify/assemble only the authorized inventory and first-blocked-reason edits."""
import difflib,hashlib,json,pathlib,sys
P=pathlib.Path(__file__).resolve().parent
old=(P/'Runner.r48-frozen.swift').read_text()
if hashlib.sha256(old.encode()).hexdigest()!='2718e44462cf19625484ef2b82b40771475ef5c546c2cf034523fc7de6730255':raise RuntimeError('frozen source mismatch')
seam=(P/'Inventory.swift').read_text()
if [l for l in seam.splitlines() if l.startswith('import ')]!=['import Foundation','import CryptoKit']:raise RuntimeError('inventory import boundary')
start=old.index('func files(');end=old.index('final class Session',start)
embedded=seam.replace('import Foundation\nimport CryptoKit\n\n','',1)+'\nfunc files(_ dir: URL?) throws -> [[String: Any]] { try inventoryRegularFiles(dir) }\n'
s=old[:start]+embedded+old[end:]
s=s.replace('if let blocked = s.blocked { try fail("session unavailable: " + blocked) }', 'if let blocked = s.blocked {\n            record["available"] = false; record["error"] = blocked\n            records.append(record)\n            continue\n          }')
s=s.replace('s.blocked = "operation status " + status', 's.blocked = retainedBlockedReason(s.blocked, "operation status " + status)')
s=s.replace('s.blocked = "unconfirmed settlement or observation"', 's.blocked = retainedBlockedReason(s.blocked, "unconfirmed settlement or observation")')
s=s.replace('record["available"] = false; record["error"] = String(describing: error)\n        if let sid, let s = sessions[sid] { s.blocked = String(describing: error) }', 'let reason: String\n        if let sid, let s = sessions[sid] {\n          reason = retainedBlockedReason(s.blocked, String(describing: error)); s.blocked = reason\n        } else { reason = String(describing: error) }\n        record["available"] = false; record["error"] = reason')
diff=''.join(difflib.unified_diff(old.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='R48-frozen/Runner.swift',tofile='R49-filesystem-seam-v1/Runner.swift'))
if sys.argv[1:]==['--write']:
 (P/'Runner.swift').write_text(s);(P/'Runner.diff').write_text(diff)
elif sys.argv[1:]:raise RuntimeError('usage assemble.py [--write]')
if (P/'Runner.swift').read_text()!=s or (P/'Runner.diff').read_text()!=diff:raise RuntimeError('unauthorized runner/diff drift')
print(json.dumps({'scopeVerification':'pass','frozenRunnerSHA256':hashlib.sha256(old.encode()).hexdigest(),'proposedRunnerSHA256':hashlib.sha256(s.encode()).hexdigest(),'productExecution':False}))
