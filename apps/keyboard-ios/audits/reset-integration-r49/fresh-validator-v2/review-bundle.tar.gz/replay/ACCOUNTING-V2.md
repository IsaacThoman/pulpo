# Reporting semantics, v2 preexecution correction

R49 author-v1 was rejected before execution for R49V1-ACCOUNT-01. It reported the
planned 31 intentional-invalid calls under `expected_invalid_rejections` without
separate actual calls, verified outcomes or an observed unexpected-status ledger.
The review did not allege a false behavioral pass. All original actions, literal
oracles, relations and verdict logic remain unchanged. The immutable v1 archive
and its rejection are retained, not rescued or relabeled as approved.

`accounting.format` is `pulpo-r49-observed-accounting-v2`. `planned` contains the
fixed 452 actions, 80 learn calls, 49 planned accepted learns and 31 planned
intentional-invalid learns. These are plans, never observed outcomes. The
ambiguous v1 report field is removed. No inputs or oracle expectations change.

For a completely schema-valid, ID/input-bound raw result, `known` is true.
`observed` contains the following count/ID pairs and the two exact ledgers:

- `actual_invocation`: the matching record explicitly reports `invoked: true`,
  irrespective of subsequent output availability. This is the harness's recorded
  invocation fact; it is not a claim of successful completion or durable teaching.
- `actual_learn_call`: invoked records for the learn action only.
- `observed_true_learn_return`: invoked learn reports literal Boolean true,
  including unavailable results or unexpected statuses. This is an unverified
  return claim and does not establish acceptance/teaching success.
- `observed_true_ok_learn_outcome`: invoked learn reports true/ok. Availability
  is intentionally not required for this raw outcome observation; verification
  is separately counted below. An unavailable true/ok observation is not a pass.
- `verified_expected_accepted_learn`: a planned accepted learn actually invoked,
  with available complete schema-valid evidence and true/ok.
- `verified_intended_invalid_rejection`: a planned false/invalid learn actually
  invoked, with available complete schema-valid evidence and false/invalid.
  An unavailable false/invalid row gets zero verified rejection credit. A
  false/invalid outcome at a planned accepted learn gets zero intentional-control
  rejection credit. A true/ok outcome at a planned rejection gets zero verified
  expected-acceptance credit.
- `unexpected_learn_outcome`: invoked learn carries a returned value or observed
  status differing from its planned outcome. This is retained even if unavailable.
- `unavailable_operation`: raw `available` is false. This is transport/projection
  availability, distinct from the retained existing top-level unavailable-evidence
  union which also includes non-ok durable observations/storage statuses.
- `unfired_operation`: raw `invoked` is false. It never contributes to actual
  invocation, learn calls, observed statuses or verified outcomes.
- `unknown_learn_outcome`: planned learn is unavailable or unfired. This does not
  erase a real invocation or an observed status/return claim from the ledgers.
- `unknown_invoked_model_status`: an invoked model record has no reported status
  while unavailable. Null is unknown; it is never counted as an observed status.
- `unexpected_observed_status`: an invoked model record reports a nonnull valid
  status differing from the expected last-operation diagnostic at that action.
- `unexpected_storage_status`: invoked model record reports busy, capacity, io,
  uncertain or cleanup. These are always retained regardless of availability.

`status_ledger` includes every invoked model record with a nonnull valid status,
its ID, status, availability, expected status and unexpected classification.
`status_counts` is derived from these rows. A getter/observer may repeat the last
operation's invalid diagnostic; this is a status observation, not another rejected
learn. The complete synthetic plan therefore has 354 ok and 58 invalid status
observations, distinct from its 31 verified intended-invalid learns. An unfired
record with a stale invalid/busy status contributes no status observation.
`learn_outcome_ledger` retains every invoked learn's returned value, observed
status, availability, expected outcome and verification classification.

All outcome counters are about observed API outcomes. They do not imply that
associated state conservation, policy, clamp, full-vector or durability relations
passed. Those original behavioral checks and failure exits remain in force.
Neither an unexpected status nor unavailable outcome receives success credit.

## Strict-invalid, missing and partial raw data

Exit 2 means there is no complete validated observation set. `known` is false,
`observed` is null and every frozen action ID is listed under
`unknown_operation_ids`. The complete 452/772 denominator and planned counts remain
reported. Invocation/status/outcome counts are unknown, **not zero**, and no
partially parsed or misbound row receives fired/verified credit. This conservative
policy applies uniformly to a missing row/file, malformed JSON, duplicate keys,
nonfinite numbers, unknown fields/statuses and broken ID/input/record binding.
When author declarations themselves are unavailable, planned counts and unknown
ID lists are also null, rather than invented. The raw error is retained.

A well-formed unavailable/blocked row is different: its valid invocation flag and
nonnull invoked status remain observable facts, while its unavailable outcome
gets no verified credit. Such records return exit 1 and retain denominators.

## Diagnostics and aggregates

The denominator is 452 action aggregates plus 320 enforced relation aggregates,
772 total. `failure_count` is retained for compatibility and is explicitly
identified by `failure_count_unit: diagnostic_messages_not_failed_aggregates`.
`diagnostic_message_count` equals the number of strings in `failures`. One
aggregate can emit several diagnostic messages. No passed-check numerator or
aggregate score is emitted, and subtracting diagnostic count from 772 is invalid.
The unchanged 15,283 tolerance-comparison synthetic passing trace cited by the
independent v1 reviewer is an implementation trace, not independent samples.

## Synthetic verification

All original 68 v1 adversaries and their expected exit codes remain byte-identical.
Their v2 reports are regenerated because reporting changed. The extra 28 declared
accounting witnesses cover the complete plan, unavailable and unfired intended
rejections, unavailable accepted calls, available/unavailable instances of all
five unexpected storage statuses, stale unfired status, wrong acceptance/rejection,
unknown unavailable outcomes, missing records/fields/files and corrupt raw data.
`accounting-countertruth.json` freezes complete count/ID/status/outcome ledgers from
an independent literal synthetic-inventory script. Baseline totals are also pinned
to the independent review's 452/80/49/31 and 354/58 facts. `test_accounting.py`
compares the entire observed object, unknown accounting, planned counts, exits,
denominators and diagnostic units under ordinary and optimized Python. Both modes
must agree exactly. None of these data are product outputs or learning oracles.
