import Foundation
import CryptoKit

// Harness filesystem mechanics only. No model, payload decoding, retry or mutation.
enum InventoryError: Error { case invalid(String) }
func inventoryFail(_ reason: String) throws -> Never { throw InventoryError.invalid(reason) }
func inventoryCanonicalURL(_ url: URL) -> URL {
  url.standardizedFileURL.resolvingSymlinksInPath().standardizedFileURL
}
func inventoryDescends(_ path: [String], from root: [String]) -> Bool {
  path.count > root.count && Array(path.prefix(root.count)) == root
}
// Preserve the first cause; later blocked rows must not wrap it recursively.
func retainedBlockedReason(_ previous: String?, _ proposed: String) -> String { previous ?? proposed }

struct InventoryCollector {
  let root: URL
  let diagnostic: ((String, String) -> Void)?
  private(set) var rows: [[String: Any]] = []
  private(set) var total = 0
  private var seen: Set<String> = []
  static let resourceKeys: Set<URLResourceKey> = [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey, .isAliasFileKey, .fileSizeKey]

  init(root input: URL, diagnostic: ((String, String) -> Void)? = nil) throws {
    guard input.isFileURL else { try inventoryFail("inventory nonfile root") }
    let lexical = input.standardizedFileURL
    let original = try lexical.resourceValues(forKeys: Self.resourceKeys)
    guard original.isSymbolicLink != true, original.isAliasFile != true else { try inventoryFail("inventory root link") }
    let canonical = inventoryCanonicalURL(lexical)
    let values = try canonical.resourceValues(forKeys: Self.resourceKeys)
    guard values.isDirectory == true, values.isSymbolicLink != true, values.isAliasFile != true else { try inventoryFail("inventory root directory") }
    self.root = canonical
    self.diagnostic = diagnostic
  }

  mutating func visit(_ input: URL) throws {
    guard input.isFileURL, !input.pathComponents.contains("."), !input.pathComponents.contains("..") else { try inventoryFail("inventory entry traversal") }
    let lexical = input.standardizedFileURL
    let canonical = inventoryCanonicalURL(lexical)
    let rootComponents = root.pathComponents
    guard inventoryDescends(canonical.pathComponents, from: rootComponents) else { try inventoryFail("inventory canonical escape") }
    let relativeComponents = canonical.pathComponents.dropFirst(rootComponents.count)
    let relative = relativeComponents.joined(separator: "/")
    // Derive the root in the entry's spelling; system aliases can add components.
    let lexicalComponents = lexical.pathComponents
    guard lexicalComponents.count > relativeComponents.count else { try inventoryFail("inventory lexical escape") }
    let lexicalRoot = URL(fileURLWithPath: NSString.path(withComponents: Array(lexicalComponents.dropLast(relativeComponents.count))), isDirectory: true)
    guard inventoryCanonicalURL(lexicalRoot).pathComponents == rootComponents else { try inventoryFail("inventory lexical escape") }
    let lexicalRootValues = try lexicalRoot.resourceValues(forKeys: Self.resourceKeys)
    guard lexicalRootValues.isSymbolicLink != true, lexicalRootValues.isAliasFile != true else { try inventoryFail("inventory entry link") }
    guard lexicalRootValues.isDirectory == true else { try inventoryFail("inventory intermediate non-directory") }
    guard !relative.isEmpty, !seen.contains(relative) else { try inventoryFail("inventory duplicate") }

    // Check every descendant component in the original spelling, before content.
    // Root aliases such as /var vs /private/var were canonicalized separately.
    var cursor = lexicalRoot
    let descendants = lexical.pathComponents.dropFirst(lexicalRoot.pathComponents.count)
    var values: URLResourceValues?
    for (index, component) in descendants.enumerated() {
      cursor.appendPathComponent(component)
      let current = try cursor.resourceValues(forKeys: Self.resourceKeys)
      guard current.isSymbolicLink != true, current.isAliasFile != true else { try inventoryFail("inventory entry link") }
      if index + 1 < descendants.count && current.isDirectory != true { try inventoryFail("inventory intermediate non-directory") }
      values = current
    }
    guard let values else { try inventoryFail("inventory missing entry metadata") }
    seen.insert(relative)
    diagnostic?("contained", relative)
    if values.isDirectory == true { return }
    guard values.isRegularFile == true else { try inventoryFail("inventory nonregular entry") }
    guard let size = values.fileSize, size >= 0, size <= 16 * 1024 * 1024,
          total + size <= 32 * 1024 * 1024, rows.count < 128 else { try inventoryFail("inventory pre-read bound") }
    diagnostic?("beforeRead", relative)
    let data = try Data(contentsOf: canonical)
    diagnostic?("afterRead", relative)
    total += data.count
    guard data.count <= 16 * 1024 * 1024, total <= 32 * 1024 * 1024, rows.count < 128 else { try inventoryFail("inventory bound") }
    rows.append(["path": relative, "bytes": data.count,
                 "sha256": SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()])
  }

  var sortedRows: [[String: Any]] { rows.sorted { ($0["path"] as! String) < ($1["path"] as! String) } }
}

func inventoryRegularFiles(_ directory: URL?, diagnostic: ((String, String) -> Void)? = nil) throws -> [[String: Any]] {
  guard let directory else { return [] }
  var collector = try InventoryCollector(root: directory, diagnostic: diagnostic)
  var enumerationError: Error?
  guard let enumerator = FileManager.default.enumerator(at: collector.root,
    includingPropertiesForKeys: Array(InventoryCollector.resourceKeys), options: [],
    errorHandler: { _, error in enumerationError = error; return false }) else { try inventoryFail("inventory enumeration") }
  for case let entry as URL in enumerator { try collector.visit(entry) }
  if let enumerationError { throw enumerationError }
  return collector.sortedRows
}
