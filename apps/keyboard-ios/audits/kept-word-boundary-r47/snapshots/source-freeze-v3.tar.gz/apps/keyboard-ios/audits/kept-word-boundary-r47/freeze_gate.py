"""Strict final-reveal bindings. Development calls explicitly omit this gate."""
import hashlib,json,pathlib
AUDIT='apps/keyboard-ios/audits/kept-word-boundary-r47/'
CORE='apps/keyboard-ios/PulpoKeyboardKit/Sources/KeyboardCore/'
TESTS=['apps/keyboard-ios/PulpoKeyboardKit/Tests/KeyboardCoreTests/ExternalTextTouchR47Tests.swift','apps/keyboard-ios/PulpoKeyboardKit/Tests/KeyboardCoreTests/Support.swift','apps/keyboard-ios/AppTests/ExternalTextTouchR47Tests.swift']
FIXED=['CONTRACT.md','PROTOCOL.md','SOURCE-CONTROLS.md','Runner.swift.txt','baseline-KeyboardEngine.swift.txt','build.py','check.py','run-pair.py','test-check.py','test-admission.py','freeze_gate.py','validate-source-controls.py','pre-edit-freeze.json','baseline-final-build-receipt.json','candidate-final-build-receipt.json','source-controls-final.json','ordinary-final-summary.json','native-admission.json']
EVIDENCE={'sourceReview','evaluatorReview','oracleReview','authorNotes'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v):return type(v) is str and len(v)==64 and all(c in '0123456789abcdef' for c in v)
def safe(root,name):
 need(type(name) is str and name and not pathlib.Path(name).is_absolute() and '..' not in pathlib.Path(name).parts,'relative freeze path')
 target=(root/name).resolve();target.relative_to(root.resolve());return target
def required(root):
 core={str(p.relative_to(root)) for p in (root/CORE).rglob('*.swift')}
 need(bool(core),'missing Core source set')
 return core|set(TESTS)|{AUDIT+name for name in FIXED}
def verify(freeze,input_path,executables,resources,root):
 need(type(freeze) is dict and set(freeze)=={'version','inputSHA256','files','executables','resources','evidence'},'complete final freeze schema')
 need(type(freeze['version']) is int and freeze['version']==1,'freeze version')
 need(digest(freeze['inputSHA256']) and freeze['inputSHA256']==sha(input_path),'sealed input mismatch')
 files=freeze['files'];evidence=freeze['evidence']
 need(type(files) is dict and type(evidence) is dict and set(evidence)==EVIDENCE,'freeze files/evidence schema')
 need(required(root)|set(evidence.values()) <=set(files),'omitted mandatory source/executor/evaluator/evidence binding')
 for name,value in files.items():need(digest(value) and sha(safe(root,name))==value,'frozen file mismatch: '+name)
 need(type(freeze['executables']) is dict and set(freeze['executables'])=={'baseline','candidate'} and freeze['executables']==executables and all(digest(x) for x in executables.values()),'frozen executable mismatch')
 need(type(freeze['resources']) is dict and set(freeze['resources'])=={'en_US.pkdict','es.pkdict','en_es.pkdict'} and freeze['resources']==resources and all(digest(x) for x in resources.values()),'frozen resource mismatch')
 for name in evidence.values():need(name.startswith(AUDIT),'review evidence outside audit')
 core={str(p.relative_to(root)):sha(p) for p in (root/CORE).rglob('*.swift')}
 pre=json.loads((root/(AUDIT+'pre-edit-freeze.json')).read_text())['sources']
 need(set(core)=={x for x in pre if x.startswith(CORE)},'changed compiled Core source set')
 engine=CORE+'Input/KeyboardEngine.swift'
 need(all(value==pre[name] for name,value in core.items() if name!=engine),'unauthorized shared production change')
 for variant in ('baseline','candidate'):
  receipt=json.loads((root/(AUDIT+variant+'-final-build-receipt.json')).read_text())
  expected={**core,'Runner.swift':sha(root/(AUDIT+'Runner.swift.txt'))}
  if variant=='baseline':expected[engine]=sha(root/(AUDIT+'baseline-KeyboardEngine.swift.txt'))
  need(receipt['exit']==0 and type(receipt['exit']) is int and receipt['binarySHA256']==executables[variant] and receipt['sourceHashes']==expected,'compiled source/binary receipt mismatch: '+variant)
 for name in ('source-controls-final.json','ordinary-final-summary.json','native-admission.json'):
  receipt=json.loads((root/(AUDIT+name)).read_text())
  need(receipt['status']=='PASS','unavailable admission '+name)
  observed=receipt['sources']
  need(all(observed.get(path)==value for path,value in core.items()),'admission source mismatch '+name)
