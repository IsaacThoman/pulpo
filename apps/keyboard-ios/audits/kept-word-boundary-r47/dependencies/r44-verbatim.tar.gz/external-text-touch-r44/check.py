#!/usr/bin/env python3
"""Independent scoring over raw rows. Never trust runner status or discard failures."""
import json, math, pathlib, sys
OPS={"type":{"text","taps","dx","dy"},"space":set(),"external":{"text","spacing"},"delete":set(),"host":{"text","cursor","selection","hidden","newDocument"},"field":{"keyboard","contentType","secure"},"settings":{"learns","autocorrect","touchLearning"},"callback":set(),"reset":set(),"probe":{"intended","dx","dy"}}
CHECKS={"text","cursor","selection","total","weight","counts","pairs","learns","decoded","autocorrection","weightMin","weightMax","costMax","costLessThanIndex"}
def need(ok,msg):
 if not ok: raise ValueError(msg)
def read(path):
 def unique(items):
  d={}
  for k,v in items: need(k not in d,"duplicate JSON key "+k); d[k]=v
  return d
 return json.loads(pathlib.Path(path).read_text(),object_pairs_hook=unique,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def preflight(data):
 need(data["version"]==1,"version")
 seen=set()
 for c in data["cases"]:
  need(c["id"] not in seen,"duplicate case"); seen.add(c["id"])
  need(c["language"] in ["en_US","es","en_es"],"resource")
  need(len(c["watch"])==len(set(c["watch"])),"duplicate watch")
  for i,o in enumerate(c["ops"]):
   need(o["op"] in OPS,"op"); need(set(o)<={"op"}|OPS[o["op"]],"unknown op field")
   if o["op"] in ("type","external"): need(isinstance(o.get("text"),str),"required text")
   if o["op"]=="probe": need(o.get("intended","").isascii() and o["intended"].isalpha() and o["intended"].islower(),"probe letters")
  indices=set()
  for e in c["expect"]:
   need(type(e["index"]) is int and 0<=e["index"]<len(c["ops"]),"checkpoint")
   need(e["index"] not in indices,"duplicate checkpoint"); indices.add(e["index"])
   need(set(e)<={"index"}|CHECKS,"unknown check")
   if "costLessThanIndex" in e: need(0<=e["costLessThanIndex"]<e["index"],"cost index")
 return data

def score(data,rows):
 expected=[(c["id"],c["language"],i,o["op"]) for c in data["cases"] for i,o in enumerate(c["ops"])]
 actual=[(r["id"],r["language"],r["index"],r["op"]) for r in rows]
 need(actual==expected,"missing, reordered, duplicated or extra rows")
 by={(r["id"],r["index"]):r for r in rows}
 checks=[]
 for c in data["cases"]:
  for e in c["expect"]:
   r=by[c["id"],e["index"]]
   for key,want in e.items():
    if key=="index": continue
    actual=r.get(key)
    if key=="counts": ok=all(r["counts"].get(k)==v for k,v in want.items()); actual=r["counts"]
    elif key=="weightMin": actual=r["weight"];ok=actual>=want
    elif key=="weightMax": actual=r["weight"];ok=actual<=want
    elif key=="costMax": actual=r["cost"];ok=actual<=want
    elif key=="costLessThanIndex": actual=r["cost"];want=by[c["id"],want]["cost"];ok=actual<want
    elif key=="weight": ok=math.isclose(actual,want,rel_tol=0,abs_tol=1e-9)
    else: ok=actual==want
    checks.append(dict(id=c["id"],index=e["index"],key=key,want=want,actual=actual,passed=ok))
 return checks

def main():
 data=preflight(read(sys.argv[1]))
 if len(sys.argv)==2: print(json.dumps({"preflight":"PASS","cases":len(data["cases"]),"ops":sum(len(c["ops"]) for c in data["cases"])}));return
 reports=[score(data,read(x)) for x in sys.argv[2:4]]
 result={"reports":[{"checks":len(x),"passed":sum(c["passed"] for c in x),"failed":[c for c in x if not c["passed"]]} for x in reports]}
 if len(reports)==2:
  result["gains"]=[b for a,b in zip(*reports) if not a["passed"] and b["passed"]]
  result["losses"]=[b for a,b in zip(*reports) if a["passed"] and not b["passed"]]
  old,new=map(read,sys.argv[2:4]); invariant=[]
  for a,b in zip(old,new):
   for key in ["text","cursor","selection","total","counts","pairs","learns"]:
    if a[key]!=b[key]: invariant.append(dict(id=a["id"],index=a["index"],key=key,old=a[key],new=b[key]))
  result["preservation_differences"]=invariant
  result["probe_outcomes"]=[{"id":a["id"],"index":a["index"],"intended":a["intended"],"decoded":a["decoded"],"oldCost":a["cost"],"newCost":b["cost"],"oldCorrection":a["autocorrection"],"newCorrection":b["autocorrection"]} for a,b in zip(old,new) if a["op"]=="probe"]
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=="__main__": main()
