import Foundation
@main struct ReferenceMain {
 static func main() throws {
  let args=CommandLine.arguments
  let obj=try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:args[1]))) as! [String:Any]
  var norms:[[String:Any]]=[];var learning:[[String:Any]]=[]
  for row in obj["normalize"] as! [[String:Any]] {
   norms.append(["id":row["id"]!,"key":publicKeyReference(row["text"] as! String)])
  }
  for row in obj["learn"] as! [[String:Any]] {
   let a=publicAlignmentReference(text:row["text"] as! String,target:row["target"] as! String)
   let taps=row["taps"] as! [Any]
   let finite:[Bool?]=taps.map { value in
    if value is NSNull{return nil};let p=value as! [String:Any]
    if p["base"] != nil{return true}
    return !(p["x"] is String) && !(p["y"] is String)
   }
   var selected:[Int]=[];var allFinite=true
   if a.lengthMatches {
    for (i,b) in a.targetBytes.enumerated() where (97...122).contains(b) {
     let origin=a.origins[i]
     if origin < finite.count,let f=finite[origin] {selected.append(origin);if !f {allFinite=false}}
    }
   }
   learning.append(["id":row["id"]!,"characters":a.characters,"typedBytes":a.typedBytes,"targetBytes":a.targetBytes,"origins":a.origins,"lengthMatches":a.lengthMatches,"contributingOrigins":selected,"finiteContributions":allFinite,"eligible":a.contributingOrigins(finitePoints:finite) != nil])
  }
  let output:[String:Any]=["format":"pulpo-r49-foundation-reference-v1","runtime":ProcessInfo.processInfo.operatingSystemVersionString,"normalize":norms,"learn":learning]
  let data=try JSONSerialization.data(withJSONObject:output,options:[.prettyPrinted,.sortedKeys])
  try data.write(to:URL(fileURLWithPath:args[2]))
 }
}
