#!/usr/bin/env python3
"""Replay declared synthetic corruptions under ordinary and optimized Python.
No executable runner or product API is invoked. Generated raw files are temporary.
"""
from pathlib import Path
import copy,hashlib,json,subprocess,sys,tempfile
D=Path(__file__).resolve().parent

def need(v,s):
 if not v:raise RuntimeError(s)
def apply(value,p):
 path=p['path'];target=value
 for k in path[:-1]:target=target[k]
 key=path[-1]
 if p['action']=='set':target[key]=copy.deepcopy(p['value'])
 elif p['action']=='delete':del target[key]
 elif p['action']=='append':target[key].append(copy.deepcopy(p['value']))
 else:raise RuntimeError('unknown declared patch')
def main():
 baseline=json.loads((D/'synthetic-raw.json').read_text());cases=json.loads((D/'adversarial-cases.json').read_text());den=len(baseline['operations']);oracle=json.loads((D/'expectations.json').read_text());checks=den+len(oracle['relations']);results=[]
 with tempfile.TemporaryDirectory(prefix='.synthetic-check-',dir=D) as tmp:
  for c in cases:
   v=copy.deepcopy(baseline)
   for patch in c['patches']:apply(v,patch)
   s=json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)
   mode=c['text_mutation']
   if mode=='duplicate_top_format':s='{"format":"pulpo-r48-raw-v2",'+s[1:]
   elif mode=='nan_token':s=s.replace('"weight":0','"weight":NaN',1)
   elif mode=='infinity_token':s=s.replace('"weight":0','"weight":Infinity',1)
   elif mode=='overflow_number':s=s.replace('"weight":0','"weight":1e9999',1)
   elif mode=='surrogate_string':s=s.replace('"round":"r49"','"round":"\\ud800"',1)
   elif mode=='truncate':s=s[:-3]
   elif mode is not None:raise RuntimeError('unknown text mutation')
   path=Path(tmp)/(c['id']+'.json');path.write_text(s,encoding='utf-8');digest=hashlib.sha256(path.read_bytes()).hexdigest()
   for optimized in (False,True):
    cmd=[sys.executable]+(['-O'] if optimized else [])+[str(D/'evaluate.py'),str(path)]
    run=subprocess.run(cmd,check=False,capture_output=True,text=True)
    need(run.returncode==c['expected_exit'],c['id']+': exit mismatch '+str(run.returncode)+' '+run.stdout+' '+run.stderr)
    report=json.loads(run.stdout);need(report['operations_denominator']==den and report['checks_denominator']==checks,c['id']+': denominator shrank')
    if c['id']=='unavailable_unfired_retains_denominator':need(report['unavailable_operations']==1 and report['unfired_operations']==1,c['id']+': missing unavailable accounting')
    if c['id'] in ('constructor_io_zero_unavailable_evidence','constructor_invalid_not_read_success','reopen_io_not_durable_zero','reload_false_busy_is_unavailable'):need(report['unavailable_evidence_operations']>=1,c['id']+': failed read incorrectly available')
    if c['expected_exit']==0:need(report['failure_count']==0,c['id']+': invalid pass')
    results.append({'id':c['id'],'optimized':optimized,'expected_exit':c['expected_exit'],'actual_exit':run.returncode,'raw_sha256':digest,'report':report})
 result={'result':'pass','synthetic_only':True,'cases':len(cases),'executions':len(results),'normal_executions':len(cases),'optimized_executions':len(cases),'results':results}
 (D/'adversarial-results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'result':'pass','cases':len(cases),'executions':len(results),'synthetic_only':True},sort_keys=True))
if __name__=='__main__':main()
