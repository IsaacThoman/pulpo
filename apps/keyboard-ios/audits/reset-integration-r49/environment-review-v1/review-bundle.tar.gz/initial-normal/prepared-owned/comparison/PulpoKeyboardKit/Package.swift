// swift-tools-version: 6.2
import PackageDescription
let package = Package(name: "PulpoKeyboardKit", platforms: [.macOS(.v15)], products: [.library(name: "KeyboardCore", targets: ["KeyboardCore"])], targets: [.target(name: "KeyboardCore")])
