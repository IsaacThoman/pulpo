from pathlib import Path
import sys,json,collections,importlib.util
A=Path('/tmp/pulpo-r49-fresh-author-v2');D=Path('/tmp/pulpo-r49-fresh-validator-v2');sp=importlib.util.spec_from_file_location('ev',A/'evaluate.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
lines=(A/'evaluate.py').read_text().splitlines();operation_line=next(i+1 for i,x in enumerate(lines) if x.strip().startswith("exact_keys(r,['id'"));relation_line=next(i+1 for i,x in enumerate(lines) if x.strip().startswith("ids=[r['record']]"));counts=collections.Counter();actions=[];relations=[]
def tr(f,event,arg):
 if f.f_code.co_filename==str(A/'evaluate.py'):
  if event=='call':
   if f.f_code.co_name in ('require','state_equal','state_zero','close','observed_accounting'):counts['calls.'+f.f_code.co_name]+=1
   if f.f_code.co_name=='close':
    caller=f.f_back;name=caller.f_code.co_name
    if name=='<genexpr>':name=caller.f_back.f_code.co_name+'.generator'
    counts['tolerance.'+name]+=1
  if event=='line' and f.f_code.co_name=='evaluate':
   if f.f_lineno==operation_line:actions.append(f.f_locals['o']['id'])
   if f.f_lineno==relation_line:relations.append(f.f_locals['i'])
 return tr
sys.settrace(tr);code,report=m.evaluate(A/'synthetic-raw.json');sys.settrace(None)
if code!=0 or len(actions)!=452 or len(set(actions))!=452 or relations!=list(range(320)):raise RuntimeError('trace')
if counts['calls.close']!=15283:raise RuntimeError('atomic count drift')
(D/'trace.json').write_text(json.dumps({'synthetic_only':True,'actions':actions,'relation_indices':relations,'aggregate_checks':772,'counts':counts,'report':report,'qualification':'Tolerance predicates are actual executed numeric comparisons, not independent benchmark examples. failure_count is diagnostic count, not failed aggregate count.'},indent=2)+'\n');print(json.dumps(dict(counts),sort_keys=True))
