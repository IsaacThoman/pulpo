from pathlib import Path
import sys,json,collections,importlib.util
A=Path('/tmp/pulpo-r49-fresh-author-v1');D=Path('/tmp/pulpo-r49-fresh-validator-v1');spec=importlib.util.spec_from_file_location('ev',A/'evaluate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);counts=collections.Counter()
lines=(A/'evaluate.py').read_text().splitlines()
def tr(f,event,arg):
 if f.f_code.co_filename==str(A/'evaluate.py'):
  if event=='call' and f.f_code.co_name=='close':
   caller=f.f_back;name=caller.f_code.co_name
   if name=='<genexpr>':name=caller.f_back.f_code.co_name+'.generator'
   counts['tolerance.'+name]+=1
  if event=='return' and f.f_code.co_name=='<genexpr>' and type(arg) is bool:
   s=lines[f.f_code.co_firstlineno-1]
   if 'axis clamp' in s:counts['predicate.axis_clamp_components']+=1
   if 'positive accepted anchor' in s:counts['predicate.positive_offset_components']+=1
   if 'all26 accepted evidence' in s:counts['predicate.all_keys_nonzero_generators']+=1
 return tr
sys.settrace(tr);code,r=m.evaluate(A/'synthetic-raw.json');sys.settrace(None)
need=code==0
if not need:raise RuntimeError('baseline')
(D/'atomic-comparisons.json').write_text(json.dumps({'synthetic_baseline_only':True,'counts':counts,'aggregate_checks':772,'qualification':'These counts enumerate executed numeric tolerance predicates, axis-clamp component predicates and nonzero generator yields on the complete synthetic passing path. They are not independent cases, and short-circuit paths execute different predicate counts. Schema require() calls and string/type/hash comparisons are separately reported in trace files, not inflated into benchmark checks.'},indent=2)+'\n');print(json.dumps(counts,sort_keys=True))
