# Frozen observation and oracle rules

The binding is public-domain-v3 SHA256
`986bbb9faefefd211c8f954c5d0fcd66ad1cd42e10008e69a354a7bc964dbef9`,
Foundation-only reference SHA256
`860e4098efcf1d38825458c4791c5398a7e37c626ba23dc91392e7f60629516b`,
author protocol SHA256
`4f774c5d419d9f95f243cb0791db58b6cc6ce52a10c5c9c2b9129fae65159c42`,
and generic runner SHA256
`8f50f13ef8fcddc51d3521e6311992ebae2778f5635957f381f6a392ff61e4a1`.
Only those approved public files and author-created artifacts informed this work.

Normalization expectations are computed once by the approved exact Swift
reference on the bound runtime and frozen in `reference.json`. The Unicode path
uses complete Swift String.lowercased, then Foundation compatibility decomposition,
then the specified scalar exclusions. The ASCII path excludes only ASCII
apostrophe and lowercases ASCII A-Z. This includes controls, preserved nonletters,
Greek casing, compatibility expansions, nonspacing marks, spacing/enclosing marks
and format scalars. No Python Unicode normalization or full case folding is used.
Some compatibility outputs intentionally retain uppercase letters, so a second
normalization can differ. Whole-target normalization and per-original-Character
typed expansion remain separate operations. UTF8 expansion duplicates taps per
byte; missing taps are nil and extra taps are ignored.

`verify_author.py` independently uses the frozen structural reference to select
actual contributing target bytes and original tap origins. It validates every
learn acceptance, including explicit policy, target minimum/length match,
nonempty sample selection, contributing finite points and the persistent
40-actual-sample limit. Relative taps use observed public qwerty centers; exact
geometry coordinates are not invented as an oracle. Resolved taps are verified
against the returned centers and the frozen literal displacement. Explicit
nonfinite input strings are legal only in declared direct input point coordinates;
nonfinite observations, weights or offsets are strict-invalid data. Tagged points
at ignored byte/origin positions do not poison otherwise valid calls.

Every new instance starts with empty weight and all26 zero offsets after successful
construction. No constructor/reopen learning default is assumed. Policy is set
explicitly before all learns, including after reopening. The policy family also
turns learning off after reopening, verifies rejection, then turns it on; a local
nil-URL reopen is an empty new model and its seed is explicitly restored. A
persistent reopen requires status ok before it supplies durable evidence.

Accepted controls have finite nonzero displacement and must change state. Final
anchors require positive weight and a nonzero offset. The full-alphabet family
requires nonzero evidence for every key. Every available projection must contain
finite weight and all26 ordered a-z two-dimensional offsets, with componentwise
bounds ±0.4; no Euclidean ±0.4 bound is asserted.

No product update formula or precise learned-offset magnitude is fabricated.
Cross-mode and canonical equalities compare weight and all52 offset components
using absolute 1e-9 plus relative 1e-9 tolerance; policy is checked separately on
every explicitly governed observation. Equality compares equivalent ordered
accepted sample streams. Canonical controls independently express expanded,
sparse, removed-character, ignored-byte and ignored-extra-point sample streams
as direct ordinary alignments. Equal spellings are not required for learning.

A target with more than40 bytes but two actual samples must be admitted by both
modes. A 40-actual-sample call must be admitted persistently. A following
41-actual-sample call is rejected persistently and accepted locally. Its persistent
state is compared to the local accepted-prefix checkpoint, not the local
post-41 state. The local uncapped sequence has a separate canonical control.

Every no-mutation rejection comparison starts after a confirmed synchronous save.
The tested invariant is weight/all26 offsets and bounded regular-file inventory
plus regular-file content hashes, never metadata timestamps or all filesystem
side effects. Save can commit accepted work and is not itself an unconditional
file-invariance assertion. No busy/io/uncertain/capacity/cleanup outcome receives
an unchanged-files oracle. Unexpected storage statuses fail and block successful
evidence. No model mutation is replayed.

The status field is the last operation result, distinct from stable read validity.
Rejected learn false/invalid is an intentional specified outcome. Its retained
projection remains usable for settled no-mutation comparisons and a following
observe keeps that diagnostic invalid status. Constructor/reopen/reload non-ok
cannot certify durable state, even if zeros are exposed. Persistent reload accepts
either Boolean with ok; nil-URL reload specifically expects false/ok. Sync save
requires true/ok. Unavailable/unfired rows remain in every coverage denominator.

Author-only fabricated raw rows and corruptions verify evaluator sensitivity and
strict parsing. They do not certify product results or model numerical behavior.
Every frozen relation is enforced, not just named, and symbolic sample-stream
prevalidation confirms it is nonvacuous and consistent with the public domain.
