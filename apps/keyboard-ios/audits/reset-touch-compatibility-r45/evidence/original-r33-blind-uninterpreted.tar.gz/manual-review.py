# Separate pre-seal static review aid. No Core, runner execution, or product access.
import json, hashlib
from decimal import Decimal, getcontext
from pathlib import Path
getcontext().prec=70
P=Path('/tmp/pulpo-r33-blind'); cases=json.loads(P.joinpath('heldout.json').read_bytes())
D=lambda n:Decimal(str(n))
class Reference:
 def __init__(self): self.keys=[[D(0),D(0),D(0)] for _ in range(26)]
 def offset(self,k):
  v=self.keys[ord(k)-97]; mass=sum(q[2] for q in self.keys)+D(24)
  return [max(D('-.4'),min(D('.4'),(v[j]+D(12)*sum(q[j] for q in self.keys)/mass)/(v[2]+D(12)))) for j in range(2)]
 def advance(self,word,x,y):
  x,y=D(x),D(y); reference=[self.offset(chr(i+97)) for i in range(26)]
  for letter in word:
   idx=ord(letter)-97; rx,ry=reference[idx]; distance=((x-rx)**2+(y-ry)**2).sqrt()
   factor=D(1) if distance<=D('.45') else D('.45')/distance
   contribution=[rx+(x-rx)*factor,ry+(y-ry)*factor]
   q=self.keys[idx]
   if q[2]>=D(300):
    factor=D(299)/q[2]
    for j in range(3): q[j]*=factor
   for j in range(2): q[j]+=contribution[j]
   q[2]+=1
 def snapshot(self,letters):
  v=[('touchWeight',None,sum(q[2] for q in self.keys))]
  for k in letters:
   x,y=self.offset(k); v.extend([('offsetX',k,x),('offsetY',k,y)])
  return v
def model(groups,letters):
 r=Reference()
 for w,x,y in groups:r.advance(w,x,y)
 return r.snapshot(letters)
def zero():return [('touchWeight',None,D(0))]
expected={
 1:[],2:[],3:zero()+model([('raffia',-.07,.04)],'r'),
 4:model([('vellum',.16,.06)],'v'),5:zero()+model([('saffron',.05,-.09)],'s'),
 6:zero()+zero(),7:model([('thimble',.09,-.13),('thimble',-.1,.07)],'t'),
 8:zero()+zero(),9:[('touchWeight',None,D(5))]+zero(),
 10:zero()+model([('flax',.06,-.04)],'f'),
 11:model([('quill',.17,.03)],'q')+[('touchWeight',None,D(5))],
 12:model([('burdock',-.08,-.12)],'b'),13:zero()+model([('sedge',.13,-.17)],'s'),
 14:model([('hemlock',.19,.11)],'h'),15:model([('merlin',-.16,.08)],'m'),
 16:zero()+model([('mallow',.1,-.1)],'m'),17:zero()+zero()}
r=Reference()
for x,y in [(.8,.6),(-.9,.2),(.25,-.8),(.7,-.6),(-.6,-.7),(.35,.1),(.9,.9),(-.7,.5)]: r.advance('z'*40,x,y)
expected[18]=r.snapshot('za'); r.advance('jazzy',-.65,-.55); expected[18]+=r.snapshot('zaj')+r.snapshot('zj')
notes=[
'Both writers have registered distinct tokens. Saving in reverse process order merges two exact first-target counts and one second-target count. History lowercases identically; existing pin leaves its count unchanged. Total three; only the twice learned/pinned target is known.',
'All three normalized equivalent forms share the forget key. Durable equivalent words and target pairs disappear; the unrelated target whose history names an equivalent word remains. Foreign pending equivalent token is revoked, not saved. Later two distinct exact forms are admitted; missing-form pin creates one pinned count. Total three includes the unrelated survivor. Blocking is removed on later application.',
'Reset precedes both old pending commits; their epochs revoke both old stores. Successful fresh constructors precede all zero checks. New explicit admissions use the same retained owner in current epochs, giving one new dictionary pair and only the later touch group.',
'Dictionary reset revokes its token and pair only. Selected touch save commits the retained touch group under either permitted sibling-flush policy. Later missing pin creates exactly one known target.',
'Touch reset revokes the old touch group only. Durable blocked preference and one pending dictionary pair survive. Subsequent touch accepts against the empty touch epoch; the old sample group is absent.',
'Two nil-URL processes and the persistent authority are separate. Nil saves succeed as no-ops. Local reset clears learned payload but retains transient words. Persistent clear likewise retains local transient known state; a fresh persistent process cannot see it.',
'Background replies assert enqueue only. Completion is established by explicit successful saves, whose confirmed-busy-only retries cannot duplicate accepted learning. No intermediate getter assumes queue drainage. Two explicit dictionary admissions and two ordered touch groups survive; repeat save does not add a third.',
'Pipe acknowledgement precedes SIGSTOP acknowledgement. beforeTransaction holds no global lock; other process clear can commit. Fresh zero checks precede release and old writer reconciliation. After resume/release the completed save must reconcile both revoked epochs without an intervening new admission.',
'beforeCommit holds local/global plus SQLite transaction. A stopped owner causes immediate busy clear with no retry. Resume/release plus receive establishes successful payload completion in both stores before fresh reads. A later successful combined clear establishes the final fresh zeros.',
'Precommit transaction owner is stopped and killed; SIGKILL wait acknowledges lock release. Another process then resets successfully. Hot journal recovery cannot restore revoked learning. Later independent admissions follow completed reset and survive; killed pending command needs no reply.',
'Dictionary payload is independently committed before a fresh touch-only writer is admitted. That writer is killed only after real COMMIT acknowledgement barrier. No dependence on sibling flushing exists. Fresh process sees one durable dictionary pair and one touch group; its empty save and subsequent reader cannot duplicate either.',
'After-real-COMMIT gate still owns global/local locks, so touch clear is explicitly busy. Resume/release and successful receive finish both-store save. A second save reconciles rather than replays, giving one target pair and one touch group, with dictionary dirty false.',
'First selected dictionary save faults before COMMIT; confirmed rollback reports false/io and leaves local dirty and locally projected count one. Fresh successful constructor sees zero durable payload. Later successful touch then both saves guarantee both stores regardless of optional sibling flushing; each payload applies once and dirty becomes false.',
'Real COMMIT reported as IOERR is immediately reconciled by a healthy durable-status read. Save must report true/ok; following both-store save completes any sibling work. Fresh counts/pair/touch each represent one admission, not an error-driven replay.',
'Two fresh processes each arm one first-COMMIT error, targeting different-store admissions. Healthy immediate reconciliation confirms true/ok; dictionary local count is installed once. Separate completed saves and one repeat save result in one pair and one touch group.',
'Failed token INSERT is confirmed rollback: false/io, no teaching and dictionary dirty false. The second worker independently fails touch admission with no weight. Over-byte dictionary input and 41-letter kept touch word are false/invalid, not truncations. Later explicit valid admissions are new operations and produce exactly one target/pair and one touch group.',
'Each of eight real processes has admitted a token, holding eight lifetime slot locks. First owner is pipe-gated before global acquisition then acknowledged stopped. Ninth process can construct/read/reset with no slot, yet admission remains capacity before and after reset. A witness successfully reads zeros. Killing stopped owner releases one actual slot; ninth then admits exactly one new pair. Other seven owners save only revoked old tokens. Final slotless reader sees total one.',
'Eight forty-sample words on one key use fixed per-word references, Euclidean radius clamp, and sample-by-sample decay; retained key weight caps at 300. Decimal recomputation checks offsets for observed and untouched keys. Completed first save precedes second process admission/merge; repeated-key samples in the final mixed word preserve the start-of-word reference. Reload and fresh reader agree.'
]
review=[]; max_error=D(0); numeric_count=0
for i,c in enumerate(cases,1):
 actual=[a for a in c['actions'] if a['op']=='check' and a['field'] in {'touchWeight','offsetX','offsetY'}]
 assert len(actual)==len(expected[i]),(i,'numeric oracle count')
 for a,(f,w,value) in zip(actual,expected[i]):
  assert a['field']==f and a.get('word')==w,(i,'numeric query order')
  err=abs(D(a['expected'])-value); assert err<D('1e-11'),(i,'numeric mismatch'); max_error=max(max_error,err); numeric_count+=1
 # These static review checks supplement the human operation/control/count review above.
 result_actions=[a for a in c['actions'] if 'expected' in a and a['op']!='check']
 queries=[a for a in c['actions'] if a['op']=='check']
 review.append({'case':c['id'],'verdict':'pass','actionsReviewed':len(c['actions']),'typedResultOraclesReviewed':len(result_actions),'queryOraclesReviewed':len(queries),'touchMathOraclesIndependentlyRecomputed':len(actual),'operationCountStatusControlReview':notes[i-1]})
report={'kind':'Separate static manual operation/oracle/control feasibility review before sealing','payloadSha256':hashlib.sha256(P.joinpath('heldout.json').read_bytes()).hexdigest(),'sourceConsulted':False,'coreExecuted':False,'allCasesPass':True,'casesReviewed':len(cases),'actionsReviewed':sum(len(c['actions']) for c in cases),'allExpectedValuesReviewed':True,'supplementFormulaIndependentDecimalPrecision':70,'touchMathOraclesRecomputed':numeric_count,'maximumTouchAbsoluteDifference':str(max_error),'scope':'Every count, pair, history, total, known, block, dirty, numeric touch, typed result and control feasibility reviewed; selected-store saves do not assume sibling payload isolation or sibling completion. Non-touch scalar oracle derivations and gate feasibility are manually documented per case.','cases':review}
P.joinpath('manual-review-private.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['allCasesPass','casesReviewed','actionsReviewed','allExpectedValuesReviewed','touchMathOraclesRecomputed','maximumTouchAbsoluteDifference']}))
