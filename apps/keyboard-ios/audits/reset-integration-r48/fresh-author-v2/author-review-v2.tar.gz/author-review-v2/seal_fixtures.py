import pathlib,json
P=pathlib.Path('/tmp/pulpo-r48-fresh-author-v2');d=json.loads((P/'design.json').read_text());rs={r['id']:r for r in json.loads((P/'reference-values.json').read_text())}
ops=[];pairs=[];instances=[]
def push(id,op,input,expect,session=None):
 q={'id':id,'op':op,'session':session,'input':input,'expect':expect}
 if session and session.endswith('/persistent') and op in ['save','reopen']:expect['nonemptyFiles']=True
 ops.append(q);return id
for k in 'abcdefghijklmnopqrstuvwxyz':push('geometry/'+k,'center',{'byte':ord(k)},{'kind':'center'})
for f in d['families']:push('normalize/'+f['id'],'normalize',{'text':f['normalizationInput']},{'kind':'literal','value':rs[f['id']]['normalized']})
def point(k):return {'base':k,'dx':.17,'dy':-.08}
seed={'text':'cedar','target':'cedar','taps':[point(k) for k in 'cedar']}
for f in d['families']:
 fid=f['id'];r=rs[fid]; maps={}
 for mode in ['local','persistent']:
  sid=fid+'/'+mode;instances.append({'id':sid,'family':fid,'mode':mode});last=None;learning=True;stateby=[];status='ok'
  last=push(sid+'/construct','construct',{'persistent':mode=='persistent'},{'kind':'model','status':'ok','returned':None,'zero':True},sid)
  last=push(sid+'/setupLearning','setLearning',{'value':True},{'kind':'model','status':'ok','returned':None,'learning':True,'projectionEq':last,'filesEq':last},sid)
  last=push(sid+'/seed','learn',seed,{'kind':'model','status':'ok','returned':True,'learning':True,'nonzero':True,'projectionDiffersFrom':last},sid)
  last=push(sid+'/settle','save',{'inBackground':False},{'kind':'model','status':'ok','returned':True,'learning':True,'projectionEq':last},sid)
  ai=0
  for j,s in enumerate(f['steps']):
   inp={k:v for k,v in s.items() if k!='op'};ident=sid+'/step'+str(j)
   if s['op']=='setLearning':
    learning=s['value'];last=push(ident,'setLearning',inp,{'kind':'model','status':status,'returned':None,'learning':learning,'projectionEq':last,'filesEq':last},sid);stateby.append(last);continue
   a=r['alignments'][ai];ai+=1;orig=a['contributingOrigins'];accepted=learning and orig is not None and (mode=='local' or len(orig)<=40)
   ex={'kind':'model','status':'ok' if accepted else 'invalid','returned':accepted,'learning':learning,'nonzero':True}
   if not accepted:ex.update(projectionEq=last,filesEq=last)
   else:ex['projectionDiffersFrom']=last
   last=push(ident,'learn',inp,ex,sid);stateby.append(last);status=ex['status']
   if not accepted:
    last=push(ident+'/observe','observe',{}, {'kind':'model','status':'invalid','returned':None,'learning':learning,'projectionEq':last,'filesEq':last},sid)
   last=push(ident+'/save','save',{'inBackground':False},{'kind':'model','status':'ok','returned':True,'learning':learning,'projectionEq':last},sid);status='ok'
  final=last
  # Local nil-URL observation is an explicit false/.ok successful observation.
  last=push(sid+'/reload','reload',{}, {'kind':'model','status':'ok','returned':False,'learning':learning,'projectionEq':last},sid)
  if mode=='persistent':
   last=push(sid+'/reopen','reopen',{}, {'kind':'model','status':'ok','returned':None,'projectionEq':final},sid)
   last=push(sid+'/reopenedSetupLearning','setLearning',{'value':True},{'kind':'model','status':'ok','returned':None,'learning':True,'projectionEq':last,'filesEq':last},sid)
   last=push(sid+'/reopenedReload','reload',{}, {'kind':'model','status':'ok','returned':False,'learning':True,'projectionEq':last},sid)
  maps[mode]={'states':stateby,'final':last,'settled':final}
 pairs.append({'id':fid+'/equivalent-seed','left':fid+'/persistent/seed','right':fid+'/local/seed'})
 # Bind each persistent action to its matching accepted local prefix. Only cap overflow differs.
 for j,s in enumerate(f['steps']):
  if s['op']!='learn':continue
  pid=maps['persistent']['states'][j];lid=maps['local']['states'][j]
  po=next(o for o in ops if o['id']==pid);lo=next(o for o in ops if o['id']==lid)
  if po['expect']['returned'] is True:
   pairs.append({'id':fid+'/equivalent-step'+str(j),'left':pid,'right':lid})
 if fid=='sample_cap':
  pairs.append({'id':fid+'/saved-equivalence','left':maps['persistent']['final'],'right':fid+'/local/step0/save'})
 else:pairs.append({'id':fid+'/saved-equivalence','left':maps['persistent']['final'],'right':maps['local']['final']})
fixture={'format':'pulpo-r48-fixtures-v2','tolerance':1e-10,'families':[{'id':f['id'],'intent':f['intent'],'independence':'Distinct intent; local and persistent instances plus all within-family checks are correlated. Shared seed and geometry are controls, not independent accuracy evidence.','reference':rs[f['id']]} for f in d['families']],'instances':instances,'operations':ops,'relations':pairs,'denominators':{'families':len(d['families']),'instances':len(instances),'operations':len(ops),'relations':len(pairs),'modelOperations':sum(o['session'] is not None for o in ops),'normalizationCalls':len(d['families']),'geometryCalls':26,'learnCalls':sum(o['op']=='learn' for o in ops),'expectedAcceptedLearnCalls':sum(o['op']=='learn' and o['expect']['returned'] is True for o in ops),'expectedRejectedLearnCalls':sum(o['op']=='learn' and o['expect']['returned'] is False for o in ops),'persistentReopens':len(d['families'])}}
(P/'operation-manifest.json').write_text(json.dumps([{k:o[k] for k in ['id','op','session','input']} for o in ops],ensure_ascii=False,indent=2)+'\n')
(P/'fixtures.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
