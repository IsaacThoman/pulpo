import Foundation
import CryptoKit
import KeyboardCore

// Public API only. No product state/file decoding, formula, dictionary, threads or retries.
func optionalPoint(_ p: KeyPoint) -> KeyPoint? { p }
func optionalPoint(_ p: KeyPoint?) -> KeyPoint? { p }
enum HarnessError: Error { case invalid(String) }
func fail(_ s: String) throws -> Never { throw HarnessError.invalid(s) }
let null = NSNull()
func pointJSON(_ p: KeyPoint) -> [String: Any] {
  func n(_ v: Double) -> Any { v.isFinite ? v : (v.isNaN ? "nan" : (v > 0 ? "posInf" : "negInf")) }
  return ["x": n(Double(p.x)), "y": n(Double(p.y))]
}
func decodedNumber(_ a: Any) throws -> Double {
  if let s = a as? String {
    switch s { case "nan": return .nan; case "posInf": return .infinity; case "negInf": return -.infinity; default: try fail("unknown finite-input tag") }
  }
  guard let n = a as? NSNumber else { try fail("point number") }
  return n.doubleValue
}
func projection(_ m: TouchModel) -> [String: Any] {
  let w = m.weight
  return ["weight": w.isFinite ? w as Any : (w.isNaN ? "nan" : (w > 0 ? "posInf" : "negInf")),
          "offsets": m.offsets.map(pointJSON), "learning": m.isLearning]
}
// Harness filesystem mechanics only. No model, payload decoding, retry or mutation.
enum InventoryError: Error { case invalid(String) }
func inventoryFail(_ reason: String) throws -> Never { throw InventoryError.invalid(reason) }
func inventoryCanonicalURL(_ url: URL) -> URL {
  url.standardizedFileURL.resolvingSymlinksInPath().standardizedFileURL
}
func inventoryDescends(_ path: [String], from root: [String]) -> Bool {
  path.count > root.count && Array(path.prefix(root.count)) == root
}
// Preserve the first cause; later blocked rows must not wrap it recursively.
func retainedBlockedReason(_ previous: String?, _ proposed: String) -> String { previous ?? proposed }

struct InventoryCollector {
  let root: URL
  let diagnostic: ((String, String) -> Void)?
  private(set) var rows: [[String: Any]] = []
  private(set) var total = 0
  private var seen: Set<String> = []
  static let resourceKeys: Set<URLResourceKey> = [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey, .isAliasFileKey, .fileSizeKey]

  init(root input: URL, diagnostic: ((String, String) -> Void)? = nil) throws {
    guard input.isFileURL else { try inventoryFail("inventory nonfile root") }
    let lexical = input.standardizedFileURL
    let original = try lexical.resourceValues(forKeys: Self.resourceKeys)
    guard original.isSymbolicLink != true, original.isAliasFile != true else { try inventoryFail("inventory root link") }
    let canonical = inventoryCanonicalURL(lexical)
    let values = try canonical.resourceValues(forKeys: Self.resourceKeys)
    guard values.isDirectory == true, values.isSymbolicLink != true, values.isAliasFile != true else { try inventoryFail("inventory root directory") }
    self.root = canonical
    self.diagnostic = diagnostic
  }

  mutating func visit(_ input: URL) throws {
    guard input.isFileURL, !input.pathComponents.contains("."), !input.pathComponents.contains("..") else { try inventoryFail("inventory entry traversal") }
    let lexical = input.standardizedFileURL
    let canonical = inventoryCanonicalURL(lexical)
    let rootComponents = root.pathComponents
    guard inventoryDescends(canonical.pathComponents, from: rootComponents) else { try inventoryFail("inventory canonical escape") }
    let relativeComponents = canonical.pathComponents.dropFirst(rootComponents.count)
    let relative = relativeComponents.joined(separator: "/")
    // Derive the root in the entry's spelling; system aliases can add components.
    let lexicalComponents = lexical.pathComponents
    guard lexicalComponents.count > relativeComponents.count else { try inventoryFail("inventory lexical escape") }
    let lexicalRoot = URL(fileURLWithPath: NSString.path(withComponents: Array(lexicalComponents.dropLast(relativeComponents.count))), isDirectory: true)
    guard inventoryCanonicalURL(lexicalRoot).pathComponents == rootComponents else { try inventoryFail("inventory lexical escape") }
    let lexicalRootValues = try lexicalRoot.resourceValues(forKeys: Self.resourceKeys)
    guard lexicalRootValues.isSymbolicLink != true, lexicalRootValues.isAliasFile != true else { try inventoryFail("inventory entry link") }
    guard lexicalRootValues.isDirectory == true else { try inventoryFail("inventory intermediate non-directory") }
    guard !relative.isEmpty, !seen.contains(relative) else { try inventoryFail("inventory duplicate") }

    // Check every descendant component in the original spelling, before content.
    // Root aliases such as /var vs /private/var were canonicalized separately.
    var cursor = lexicalRoot
    let descendants = lexical.pathComponents.dropFirst(lexicalRoot.pathComponents.count)
    var values: URLResourceValues?
    for (index, component) in descendants.enumerated() {
      cursor.appendPathComponent(component)
      let current = try cursor.resourceValues(forKeys: Self.resourceKeys)
      guard current.isSymbolicLink != true, current.isAliasFile != true else { try inventoryFail("inventory entry link") }
      if index + 1 < descendants.count && current.isDirectory != true { try inventoryFail("inventory intermediate non-directory") }
      values = current
    }
    guard let values else { try inventoryFail("inventory missing entry metadata") }
    seen.insert(relative)
    diagnostic?("contained", relative)
    if values.isDirectory == true { return }
    guard values.isRegularFile == true else { try inventoryFail("inventory nonregular entry") }
    guard let size = values.fileSize, size >= 0, size <= 16 * 1024 * 1024,
          total + size <= 32 * 1024 * 1024, rows.count < 128 else { try inventoryFail("inventory pre-read bound") }
    diagnostic?("beforeRead", relative)
    let data = try Data(contentsOf: canonical)
    diagnostic?("afterRead", relative)
    total += data.count
    guard data.count <= 16 * 1024 * 1024, total <= 32 * 1024 * 1024, rows.count < 128 else { try inventoryFail("inventory bound") }
    rows.append(["path": relative, "bytes": data.count,
                 "sha256": SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()])
  }

  var sortedRows: [[String: Any]] { rows.sorted { ($0["path"] as! String) < ($1["path"] as! String) } }
}

func inventoryRegularFiles(_ directory: URL?, diagnostic: ((String, String) -> Void)? = nil) throws -> [[String: Any]] {
  guard let directory else { return [] }
  var collector = try InventoryCollector(root: directory, diagnostic: diagnostic)
  var enumerationError: Error?
  guard let enumerator = FileManager.default.enumerator(at: collector.root,
    includingPropertiesForKeys: Array(InventoryCollector.resourceKeys), options: [],
    errorHandler: { _, error in enumerationError = error; return false }) else { try inventoryFail("inventory enumeration") }
  for case let entry as URL in enumerator { try collector.visit(entry) }
  if let enumerationError { throw enumerationError }
  return collector.sortedRows
}

func files(_ dir: URL?) throws -> [[String: Any]] { try inventoryRegularFiles(dir) }
final class Session {
  var model: TouchModel
  let directory: URL?
  let url: URL?
  var blocked: String?
  init(directory: URL?) {
    self.directory = directory; self.url = directory?.appendingPathComponent("TouchModel.json")
    self.model = TouchModel(url: self.url)
    if model.persistenceResult.rawValue != "ok" { blocked = "constructor status " + String(describing: model.persistenceResult.rawValue) }
  }
}
@main struct Main {
  static func main() throws {
    guard CommandLine.arguments.count == 4 else { try fail("usage Runner fixtures.json raw.json environment.json") }
    let fm = FileManager.default
    let fixtureData = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
    let fixture = try JSONSerialization.jsonObject(with: fixtureData) as! [String: Any]
    let env = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[3]))) as! [String: Any]
    let base = fm.temporaryDirectory.resolvingSymlinksInPath().appendingPathComponent("pulpo-r48-" + UUID().uuidString, isDirectory: true)
    try fm.createDirectory(at: base, withIntermediateDirectories: false)
    var sessions: [String: Session] = [:]; var centers: [String: KeyPoint] = [:]
    var records: [[String: Any]] = []
    for operation in fixture["operations"] as! [[String: Any]] {
      let id = operation["id"] as! String; let op = operation["op"] as! String
      let input = operation["input"] as! [String: Any]; let sid = operation["session"] as? String
      var record: [String: Any] = ["id": id, "op": op, "session": sid as Any? ?? null,
        "input": input, "resolvedInput": null, "returned": null, "status": null,
        "state": null, "files": [], "available": true, "invoked": false, "error": null]
      do {
        if op == "center" {
          let b = (input["byte"] as! NSNumber).uint8Value
          record["invoked"] = true
          guard let p = optionalPoint(LetterGeometry.qwerty.center(b)) else { try fail("missing center") }
          centers[String(UnicodeScalar(b))] = p; record["returned"] = pointJSON(p)
        } else if op == "normalize" {
          record["invoked"] = true
          record["returned"] = TextNormalizer.key(input["text"] as! String)
        } else if op == "construct" {
          guard let sid, sessions[sid] == nil else { try fail("constructor session") }
          var directory: URL? = nil
          if input["persistent"] as! Bool {
            let d = base.appendingPathComponent(UUID().uuidString, isDirectory: true)
            try fm.createDirectory(at: d, withIntermediateDirectories: false); directory = d
          }
          record["invoked"] = true
          sessions[sid] = Session(directory: directory)
          record["resolvedInput"] = ["url": sessions[sid]!.url?.path as Any? ?? null]
        } else {
          guard let sid, let s = sessions[sid] else { try fail("missing session") }
          if let blocked = s.blocked {
            record["available"] = false; record["error"] = blocked
            records.append(record)
            continue
          }
          switch op {
          case "learn":
            let taps = try (input["taps"] as! [Any]).map { item -> KeyPoint? in
              if item is NSNull { return nil }
              let d = item as! [String: Any]
              if let key = d["base"] as? String {
                guard let p = centers[key] else { try fail("missing fixture base") }
                return KeyPoint(x: Double(p.x) + (d["dx"] as! NSNumber).doubleValue,
                                y: Double(p.y) + (d["dy"] as! NSNumber).doubleValue)
              }
              return try KeyPoint(x: decodedNumber(d["x"]!), y: decodedNumber(d["y"]!))
            }
            let text = input["text"] as! String; let target = input["target"] as! String
            record["resolvedInput"] = ["text": text, "target": target, "taps": taps.map { $0.map(pointJSON) as Any? ?? null }]
            record["invoked"] = true
            record["returned"] = s.model.learn(TypedWord(text: text, taps: taps), intended: target, geometry: LetterGeometry.qwerty)
          case "save": record["invoked"] = true; record["returned"] = s.model.save(inBackground: false)
          case "reload": record["invoked"] = true; record["returned"] = s.model.reloadIfChangedOnDisk()
          case "setLearning": record["invoked"] = true; s.model.isLearning = input["value"] as! Bool
          case "observe": record["invoked"] = true
          case "reopen":
            record["resolvedInput"] = ["url": s.url?.path as Any? ?? null]
            record["invoked"] = true
            s.model = TouchModel(url: s.url)
          default: try fail("unknown operation")
          }
        }
        if let sid, let s = sessions[sid] {
          record["status"] = String(describing: s.model.persistenceResult.rawValue)
          record["state"] = projection(s.model); record["files"] = try files(s.directory)
          let status = record["status"] as! String
          if status != "ok" && status != "invalid" { s.blocked = retainedBlockedReason(s.blocked, "operation status " + status) }
          if (op == "save" && record["returned"] as? Bool != true) || ((op == "construct" || op == "reopen" || op == "reload") && status != "ok") { s.blocked = retainedBlockedReason(s.blocked, "unconfirmed settlement or observation") }
        }
      } catch {
        let reason: String
        if let sid, let s = sessions[sid] {
          reason = retainedBlockedReason(s.blocked, String(describing: error)); s.blocked = reason
        } else { reason = String(describing: error) }
        record["available"] = false; record["error"] = reason
      }
      records.append(record)
    }
    let output: [String: Any] = ["format": "pulpo-r48-raw-v2", "environment": env.merging(["runtime": ProcessInfo.processInfo.operatingSystemVersionString], uniquingKeysWith: { _, b in b }), "operations": records]
    let data = try JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys])
    try data.write(to: URL(fileURLWithPath: CommandLine.arguments[2]), options: .atomic)
    // Preserve fresh unique storage for audit; no cleanup mutations or automatic retries.
  }
}
