# Pulpo R44 — independent external-text touch-learning contract

Status: frozen independent user-intent contract, 2026-10-16. This document is defined before any production edits by this reviewer. It uses only the public behavior supplied in the task. No production source, dictionaries, tests, audit artifacts, or model outputs were inspected. No claim is made about the current implementation or the timing of other agents' edits.

Correction note (2026-10-16, pre-bench-author): The coordinator corrected the previously supplied public spacing description. `spacing: true` can prepend a space when the prior character is nonwhitespace and not opening punctuation, and the supplied text does not begin with whitespace or attaching punctuation. It inserts the resulting text verbatim and adds no automatic trailing space. Only the erroneous spacing statements below have been revised; the rest of the frozen contract is preserved. This correction is recorded before any production edits by this reviewer.

## Intent and scope

A user who taps a complete eligible word, keeps that word, and then selects an emoji has expressed the same acceptance of that word as a user who taps Space. The retained word should teach the same eligible touch offsets, once, when learning is enabled. The emoji itself contributes no letter-tap evidence.

This equivalence requires proof that the retained word ended. A call to the external insertion API is not itself proof of word completion. That API also handles literal text and `.com`, which can continue or transform the current word.

This review authorizes only parity for a proven completed, kept word at an external insertion boundary. It does not authorize changes to learning policy, dictionaries, touch alignment, sample weights, thresholds, numerical updates, word learning, pair learning, correction policy, or insertion/caret behavior.

## Exact eligibility contract

Let W be one occurrence of the pending tapped word, rather than a string value shared across occurrences. W may contribute touch learning on an external insertion action if and only if **all** of the following hold:

1. **Policy permits learning.** Learning is enabled at the acceptance event and the current privacy/input context permits touch learning. All existing exclusions that apply to an ordinary Space commit also apply here. The external path cannot make an otherwise ineligible word eligible.
2. **The word is eligible.** W satisfies the same existing word-eligibility requirements as an ordinary Space commit, including applicable lexical, language, numeric, and identifier restrictions. Unknown words do not gain eligibility merely because the user kept them. This contract does not invent a new dictionary or eligibility test.
3. **There is legitimate tap evidence.** The recorded letter taps belong to this occurrence of W and meet the ordinary Space path's existing alignment requirements. Tapless text, partial or mismatched tap histories, and evidence invalidated by edits cannot be promoted into a complete aligned tapped word.
4. **The actual accepted word is W.** After any pending autocorrection resolves, the displayed word remains the word supported by those taps under the existing alignment policy. It must not be a rejected candidate, a replaced original spelling, or a stale pre-correction buffer. A correction changing the word does not authorize learning the original as a kept word. Existing ordinary correction-learning behavior remains outside this additional acceptance rule.
5. **The document context is current.** The pending word occurrence, document text, tap history, and caret refer to the same current composition. The selection is collapsed immediately after W, with no intervening cursor movement, selection replacement, external edit, or context loss that makes this association uncertain. If current context is insufficient to prove this association, the extra external-boundary learning is ineligible.
6. **The action actually establishes a boundary after W.** Its effective insertion, including existing spacing behavior, terminates W in the relevant language/context. It does not append letters, combining marks, a word-internal connector, an identifier suffix, or a URL continuation to W. A perceived boundary must be assessed using the effective text and surrounding context, not merely the API name, a non-letter character, or a caller's intention.
7. **W is retained through the action.** The action accepts W at that boundary; it does not delete, replace, or absorb W into another token. A canceled or failed insertion that establishes no boundary does not justify learning on the expectation of success.
8. **This occurrence has not already taught.** The same accepted word occurrence and its tap evidence contribute at most once, across acceptance actions, repeated callbacks, subsequent Space, and other follow-on actions. A later separately tapped occurrence of the same spelling remains independently eligible.

These conditions are conjunctive. Uncertainty about a required fact means no additional touch learning from this external action. It must not suppress independent learning already justified by the ordinary Space path or change the text operation.

“Complete” means a word occurrence actually accepted at a proven boundary, not merely a dictionary-looking prefix that happens to be present before an API call.

## Boundary proof and required controls

| Situation | Required touch-learning result for the pending word |
| --- | --- |
| Complete eligible word typed with aligned letter taps, then ordinary Space | Existing baseline behavior. |
| Same word, then emoji-picker acceptance at the current word-end caret | Same eligible contribution as Space, once, if the selected emoji terminates the word and all eligibility conditions hold. |
| Same word, then emoji-search result acceptance | Same result as picker acceptance. Search interaction must not confuse search-query taps with document-word taps. |
| Emoji inserted with `insertText(text, spacing: false)` immediately after the word | The absence of an added space does not by itself prevent a semantic emoji boundary. Preserve the exact text and caret behavior. |
| Emoji accepted with no pending word or no letter taps | Insert normally; no fabricated word touch sample. |
| Literal external insertion with proven separating whitespace before its text | A boundary can qualify on its own merits if W remains eligible and retained. External insertion alone is insufficient. |
| `spacing: true` actually adds a separating space after W | The actual separator can establish the boundary, subject to all other conditions. Preserve the existing conditional leading-space rule and verbatim insertion. |
| `spacing: true` does not add a leading separator | The flag alone proves nothing. Evaluate the effective insertion and existing context. If the supplied text appends letters and then whitespace, that whitespace commits the resulting text, not the original prefix W; the API adds no automatic trailing space. |
| Literal letters appended with `spacing: false`, such as tapped `cat` followed by `s` | Do not prematurely teach `cat`. Any later eligibility of `cats` requires its own valid tap alignment under existing policy; the inserted `s` has no letter tap. |
| External empty text or an action with no effective boundary | No new boundary-based contribution. If spacing has an actual text effect, assess that effect rather than assuming the call was empty. |
| `.com` shortcut appended to tapped text | Do not teach the preceding fragment as a completed natural-language word. The shortcut continues a URL/domain-style token. |
| Literal identifier/URL continuations, including contextually internal `.`, `_`, `@`, `/`, `-`, or apostrophe | No boundary inferred from the character class alone; do not learn an intermediate word prefix. Existing identifier exclusions still apply. |
| Unambiguous sentence punctuation that actually ends a retained eligible word | A real boundary can qualify, subject to existing policy. This is not permission to classify every punctuation mark as a boundary. |
| Apostrophe, hyphen, decimal point, or punctuation inside a larger token | No premature word acceptance. The complete token and context determine eligibility. |
| Learning disabled | No touch update; insertion and existing correction acceptance proceed normally. |
| Privacy-sensitive context in which learning is prohibited | No touch update or new learning persistence; preserve existing input behavior and policy for all learning channels. |
| Numeric-only text | No additional word touch learning. Do not treat retained digits as a newly eligible word. |
| Mixed letters/digits or identifiers | Apply existing exclusions; do not grant eligibility because an emoji follows. |
| Unknown or otherwise lexically ineligible word | No additional touch learning, even if retained. Preserve any separate existing word-learning policy. |
| Pasted, externally inserted, restored, suggested, or otherwise tapless word | No fabricated touch sample. Other learning remains governed by existing policy. |
| Word edited by selection replacement, deletion/retyping, or an external edit that invalidates the tap-to-word association | No additional contribution from the invalidated history. A subsequently established independent valid tapped occurrence may qualify. |
| Stale pending word after cursor movement, host edit, context truncation, or composition change | No additional contribution without current proof of the same word occurrence and aligned taps. |
| Nonempty selection, caret inside W, or caret elsewhere | No learning of the old pending word merely because emoji is accepted. Perform the existing caret/selection insertion behavior. |
| Correction replaces the pending original before emoji insertion | Do not teach the original as kept. Preserve existing correction, word, pair, and aligned correction-learning behavior. |
| Duplicate callback, emoji followed by Space, or several emoji after one accepted word | At most one contribution from that word occurrence. |
| Same spelling tapped again as a new complete word | Treat as a distinct occurrence, subject to ordinary eligibility; do not globally suppress by spelling. |

## Spanish and Unicode controls

Spanish is a control against overbroad character and punctuation assumptions, not a request for new language policy.

- Eligible tapped Spanish words containing supported accented letters or `ñ` should have the same external-boundary eligibility as their ordinary Space baseline. For example, `niño` followed by emoji should not lose eligibility solely because it contains a non-ASCII letter.
- Precomposed and decomposed spellings, such as `canción` and `cancio\u0301n`, must retain the existing Unicode/alignment semantics. A combining mark belongs to its base letter; it is not an independent word boundary or a fabricated tap. This contract does not authorize changing normalization or alignment algorithms.
- An externally appended combining mark can change the pending word. It does not prove the preceding base spelling was completed and kept, even if the resulting grapheme looks familiar.
- `¿` and `¡` are not blanket word-completion signals independent of position and context. Existing opening-punctuation spacing behavior must remain unchanged. Word-final `?` and `!` may be real boundaries when the word and context otherwise qualify.
- Emoji variation selectors, modifiers, and joiner sequences are part of the selected emoji text. Preserve that text exactly and do not manufacture letter taps or multiple word acceptances from its code points.

## Preserved observable behavior

Emoji-picker and emoji-search acceptance must continue to insert the selected emoji at the current caret through `insertText(text, spacing: false)`. Literal insertion and the `.com` shortcut must retain their current text and caret results. Selection replacement behavior must remain unchanged.

For `spacing: true`, preserve the corrected public contract: a space can be prepended if the prior last character is neither whitespace nor opening punctuation and the supplied text does not begin with whitespace or attaching punctuation. Insert the resulting text verbatim, with no automatic trailing space. This review does not expand the definition of opening punctuation, attaching punctuation, or whitespace.

Pending autocorrections must still be accepted on the subsequent actions that currently accept them. Touch-learning parity cannot keep a rejected spelling, change which correction is accepted, move the caret, add spaces to emoji insertion, or alter the returned text.

Existing word learning and pair learning must keep their established eligibility, ordering semantics, and occurrence counts. Adding touch-learning parity must neither manufacture additional word/pair events nor prevent existing ones. Privacy and learning-disabled behavior remain governed by their existing policy for each channel.

## Justified bounded outcome

The justified fix is an observable increase from a missing touch contribution to exactly the ordinary Space-equivalent contribution for a complete, retained, eligible tapped word at a proven external boundary. Picker and search acceptance should agree. All ineligible and ambiguous controls above retain their existing insertion/correction behavior and gain no new touch contribution.

Unacceptable outcomes include learning on every `insertText` call; treating all nonletters as delimiters; learning a prefix before `.com`, literal suffixes, or combining marks; teaching stale or replaced words; associating search-query taps with the document; bypassing privacy, numeric, unknown-word, or disabled-learning exclusions; and contributing twice when emoji acceptance is followed by another commit action.

This is a behavioral contract, not a source-derived implementation recommendation. It does not prescribe a hook, helper, state field, tokenization change, or algorithm change.

## Review concerns and limits

1. **An API event is weaker evidence than acceptance.** The shared external API spans both delimiters and continuations. A remedy justified only by the emoji example can silently learn word prefixes in the other cases.
2. **Correction ordering affects which word was kept.** An original spelling cannot be counted as accepted when the same action replaces it. The accepted document state and valid tap association must agree.
3. **Touch evidence is occurrence-specific.** Caret movement, selection, host context changes, search UI, and callbacks can separate a pending string from the taps that once produced it. Equal text alone is insufficient proof.
4. **Parity is conditional on the established policy.** The public brief supplies no dictionary entries, exact numeric/identifier policy, alignment thresholds, or normalization rules. Those details must remain those of the ordinary Space baseline; this independent contract cannot certify specific words against unseen policy.
5. **“Before edits” is a review artifact boundary.** This contract was written without inspecting implementation or other review outputs. Its creation does not establish what other actors may already have changed in the shared checkout.

No implementation compliance or test result is claimed by this sourceblind review.
