import copy,gzip,hashlib,importlib.util,json,pathlib,sys,traceback
P=pathlib.Path(__file__).resolve().parent; B=P/'review-v1/author-review-v1'
spec=importlib.util.spec_from_file_location('author_evaluator',B/'evaluate.py'); E=importlib.util.module_from_spec(spec);spec.loader.exec_module(E)
F=E.preflight(); A=E.read(B/'accounting.json'); refs=json.loads((P/'independent-reference-values.json').read_text())
def require(x,m):
 if not x:raise RuntimeError(m)
require(E.equal(refs,E.read(B/'reference-values.json')),'independent Foundation references mismatch')
expected=[o['id']+'/'+n for o in F['operations'] for n in E.names(o)]+['relation/'+r['id'] for r in F['relations']]
require(expected==A['intendedCheckIDs'] and len(set(expected))==len(expected)==1961,'exact unique accounting checks')
require([o['id'] for o in F['operations']]==A['intendedOperationIDs'],'accounting action IDs')
for k,v in A['operationCounts'].items(): require(v==sum(o['op']==k for o in F['operations']),'operation count '+k)
centers={chr(97+n):{'x':n/30.,'y':n/50.} for n in range(26)};states={};naccepted={};urls={};fs={};rs=[]
for o in F['operations']:
 i=o['input'];sid=o['session'];op=o['op'];e=o['expect']
 r={k:copy.deepcopy(o[k]) for k in ['id','op','session','input']};r.update(resolvedInput=None,returned=None,status=None,state=None,files=[],available=True,invoked=True,error=None)
 if op=='center':r['returned']=centers[chr(i['byte'])]
 elif op=='normalize':r['returned']=e['value']
 else:
  if op=='construct':
   naccepted[sid]=0;states[sid]={'weight':0.,'offsets':[{'x':0.,'y':0.} for _ in range(26)],'learning':True};fs[sid]=[];urls[sid]='/independent-synthetic/'+sid.replace('/','_')+'/TouchModel.json' if i['persistent'] else None;r['resolvedInput']={'url':urls[sid]}
  elif op=='learn':
   taps=[]
   for p in i['taps']:
    taps.append(None if p is None else {c:centers[p['base']][c]+p['d'+c] for c in ['x','y']} if 'base' in p else copy.deepcopy(p))
   r['resolvedInput']={'text':i['text'],'target':i['target'],'taps':taps}
   if e['returned']:
    naccepted[sid]+=1;n=naccepted[sid];states[sid].update(weight=float(n),offsets=[{'x':.01*n+(j/10000.),'y':-.02*n-(j/20000.)} for j in range(26)])
  elif op=='setLearning':states[sid]['learning']=i['value']
  elif op=='save' and sid.endswith('/persistent'):fs[sid]=[{'path':'TouchModel.json','bytes':20,'sha256':hashlib.sha256(b'validator-only-state').hexdigest()}]
  elif op=='reopen':r['resolvedInput']={'url':urls[sid]};states[sid]['learning']=True
  r.update(returned=e['returned'],status=e['status'],state=copy.deepcopy(states[sid]),files=copy.deepcopy(fs[sid]))
 rs.append(r)
base={'format':'pulpo-r48-raw-v1','environment':{'compiler':'MECHANICS ONLY swiftlang-6.4.0.34.1','runtime':'MECHANICS ONLY 27.0.1 26A434','architecture':'arm64','productSourceSHA256':'0'*64,'runnerSHA256':E.hashfile(B/'Runner.swift'),'fixturesSHA256':E.hashfile(B/'fixtures.json'),'versionLabel':'independent-synthetic-only'},'operations':rs}
mode='optimized' if not __debug__ else 'normal';D=P/('adversarial-'+mode);D.mkdir(exist_ok=True);reports=[];current=P/('current-'+mode+'.json')
def at(raw,id):return next(r for r in raw['operations'] if r['id']==id)
# Capture actual scored rows from unchanged evaluator at return, independently of its reported count.
def run(name,raw=None,mut=None,text=None,pass_expected=False,needle=None):
 raw=copy.deepcopy(base if raw is None else raw)
 if mut:mut(raw)
 payload=text if text is not None else json.dumps(raw,allow_nan=False)
 current.write_text(payload);(D/(name+'.json.gz')).write_bytes(gzip.compress(payload.encode()))
 captured=[]
 def trace(frame,event,arg):
  if frame.f_code is E.evaluate.__code__ and event=='return' and 'checks' in frame.f_locals:captured.extend(copy.deepcopy(frame.f_locals['checks']))
  return trace
 sys.settrace(trace)
 try:
  result=E.evaluate(current);passed=result['pass'];error=None
 except (E.Invalid,KeyError,TypeError,ValueError,IndexError,StopIteration,OSError) as ex:
  result=None;passed=False;error=type(ex).__name__+': '+str(ex)
 finally:sys.settrace(None)
 require(passed==pass_expected,name+' unexpected verdict')
 if result is not None:
  require([x['id'] for x in captured]==expected,name+' did not evaluate exact 1961 rows')
  require(len(result['failedCheckIDs'])+result['passedChecks']==1961,name+' incomplete denominator')
  require(result['failedCheckIDs']==[x['id'] for x in captured if not x['pass']],name+' lost failure rows')
 if needle:require(result is not None and needle in result['failedCheckIDs'],name+' missed targeted check '+needle)
 reports.append({'id':name,'passExpected':pass_expected,'observedPass':passed,'validationError':error,'scoredRows':len(captured),'evaluation':result})
run('baseline',pass_expected=True)
# Transport/accounting and type gates.
probes=[('missing-ID',lambda r:r['operations'].pop()),('extra-ID',lambda r:r['operations'].append(copy.deepcopy(r['operations'][-1]))),('duplicate-ID',lambda r:r['operations'][1].update(id=r['operations'][0]['id'])),('unknown-ID',lambda r:r['operations'][0].update(id='unknown')),('reorder',lambda r:r['operations'].reverse()),('unknown-operation',lambda r:r['operations'][0].update(op='unknown')),('unknown-top-field',lambda r:r.update(x=1)),('unknown-env-field',lambda r:r['environment'].update(x=1)),('wrong-source-hash-type',lambda r:r['environment'].update(productSourceSHA256=True)),('record-extra',lambda r:r['operations'][0].update(x=1)),('missing-input',lambda r:r['operations'][0].pop('input')),('input-extra',lambda r:r['operations'][0]['input'].update(x=1)),('input-bool-byte',lambda r:r['operations'][0]['input'].update(byte=True))]
for n,m in probes:run(n,mut=m)
model=next(o for o in F['operations'] if o['op']=='learn' and o['expect']['returned'] is True);mid=model['id']
for field,v in [('returned',1),('invoked',1),('available',1),('status',True),('state',None),('resolvedInput',None)]:run('model-'+field,mut=lambda r,f=field,v=v:at(r,mid).update({f:v}))
for n,m in [('weight-bool',lambda s:s.update(weight=True)),('weight-string',lambda s:s.update(weight='1')),('weight-tag',lambda s:s.update(weight='nan')),('weight-negative',lambda s:s.update(weight=-1)),('weight-bigint',lambda s:s.update(weight=10**400)),('learning-number',lambda s:s.update(learning=1)),('state-extra',lambda s:s.update(x=0)),('offset25',lambda s:s['offsets'].pop()),('offset27',lambda s:s['offsets'].append({'x':0,'y':0})),('offset-notlist',lambda s:s.update(offsets={})),('coord-missing',lambda s:s['offsets'][0].pop('x')),('coord-extra',lambda s:s['offsets'][0].update(z=0)),('coord-bool',lambda s:s['offsets'][0].update(x=True)),('coord-string',lambda s:s['offsets'][0].update(x='0')),('coord-null',lambda s:s['offsets'][0].update(x=None))]:run(n,mut=lambda r,m=m:m(at(r,mid)['state']))
for token in ['NaN','Infinity','-Infinity','1e999','-1e999']:
 payload=json.dumps(base);payload=payload.replace('"weight": 1.0','"weight": '+token,1);run('nonfinite-'+token.replace('-','negative'),text=payload)
for depth,old,new in [('top','"format":','"format":"duplicate","format":'),('record','"invoked": true','"invoked":true,"invoked":true'),('state','"weight": 1.0','"weight":1.0,"weight":1.0'),('point','"x": 0.01','"x":0.01,"x":0.01')]:
 payload=json.dumps(base);require(old in payload,'duplicate mutation present');run('duplicate-key-'+depth,text=payload.replace(old,new,1))
for n,t in [('trailing-json',json.dumps(base)+'{}'),('truncated-json',json.dumps(base)[:-10])]:run(n,text=t)
# Every expected positive, rejection, availability outcome, and relation class.
for o in F['operations']:
 if o['session'] is None:continue
 id=o['id'];ex=o['expect']
 if o['op']=='learn' and ex['returned'] is False:
  for status in ['busy','io','capacity','uncertain','cleanup']:
   run('invalid-status-'+str(len(reports)),mut=lambda r,id=id,status=status:at(r,id).update(status=status),needle=id+'/status')
  run('invalid-unfired-'+str(len(reports)),mut=lambda r,id=id:at(r,id).update(available=False,invoked=False,error='mechanical blocked'),needle=id+'/available')
  run('invalid-conservation-'+str(len(reports)),mut=lambda r,id=id:at(r,id)['state'].update(weight=23.),needle=id+'/projectionEq')
  if o['session'].endswith('/persistent'):run('invalid-files-'+str(len(reports)),mut=lambda r,id=id:at(r,id)['files'][0].update(sha256='f'*64),needle=id+'/filesEq')
 if ex.get('nonzero'):
  run('zero-positive-'+str(len(reports)),mut=lambda r,id=id:at(r,id)['state'].update(weight=0.,offsets=[{'x':0.,'y':0.} for _ in range(26)]),needle=id+'/nonzero')
 if o['op'] in ['construct','reopen']:
  run('unavailable-read-'+str(len(reports)),mut=lambda r,id=id:at(r,id).update(status='io'),needle=id+'/status')
 if 'projectionEq' in ex:
  run('projection-equality-'+str(len(reports)),mut=lambda r,id=id:at(r,id)['state']['offsets'][25].update(y=.3),needle=id+'/projectionEq')
for rel in F['relations']:
 for part in ['weight','x','y']:
  def mutate(r,rel=rel,part=part):
   s=at(r,rel['left'])['state']
   if part=='weight':s['weight']+=1.
   else:s['offsets'][25][part]+=.01
  run('cross-relation-'+str(len(reports)),mut=mutate,needle='relation/'+rel['id'])
rel=F['relations'][0]
for j in range(26):
 for c in ['x','y']:
  run('all26-'+str(j)+'-'+c,mut=lambda r,j=j,c=c:at(r,rel['left'])['state']['offsets'][j].update({c:.31}),needle='relation/'+rel['id'])
# Required nonfinite-input tags and strict file/resolved shapes.
for o in F['operations']:
 if o['op']=='learn':
  ri=at(base,o['id'])['resolvedInput']
  for j,p in enumerate(ri['taps']):
   if p is not None and any(isinstance(v,str) for v in p.values()):
    run('input-tag-'+str(len(reports)),mut=lambda r,id=o['id'],j=j:at(r,id)['resolvedInput']['taps'][j].update(x='Infinity'))
    break
persistent=next(o['id'] for o in F['operations'] if o['op']=='save' and o['session'].endswith('/persistent'))
for n,m in [('file-extra',lambda f:f[0].update(extra=1)),('file-bool',lambda f:f[0].update(bytes=True)),('file-negative',lambda f:f[0].update(bytes=-1)),('file-large',lambda f:f[0].update(bytes=2**25)),('file-traversal',lambda f:f[0].update(path='../x')),('file-duplicate',lambda f:f.append(copy.deepcopy(f[0]))),('file-hash',lambda f:f[0].update(sha256='g'*64))]:run(n,mut=lambda r,m=m:m(at(r,persistent)['files']))
# Explicit tolerance boundary controls on one cross-mode relation only: avoid other state equalities by modifying entire same-session chain after seed.
# Boundary is additionally verified directly for all components by pure evaluator relation helper.
for c in ['weight','x','y']:
 a={'weight':1.,'offsets':[{'x':0.,'y':0.} for _ in range(26)]};b=copy.deepcopy(a)
 if c=='weight':b[c]+=F['tolerance']*.5
 else:b['offsets'][25][c]=F['tolerance']*.5
 require(E.projectioneq(a,b,F['tolerance']),'tolerance inner')
 if c=='weight':b[c]=a[c]+F['tolerance']*2
 else:b['offsets'][25][c]=F['tolerance']*2
 require(not E.projectioneq(a,b,F['tolerance']),'tolerance outer')
current.unlink();out={'format':'independent-r48-adversarial-v1','mode':mode,'source':'synthetic parser/accounting/relational mechanics only; zero product/mock behavior credit','pass':True,'count':len(reports),'checksPerCompleteEvaluation':1961,'cases':reports};(P/('adversarial-'+mode+'.json')).write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='cases'}))
