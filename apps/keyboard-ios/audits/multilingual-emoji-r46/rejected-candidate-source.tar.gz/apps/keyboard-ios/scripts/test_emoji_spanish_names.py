import copy
import tempfile
import unittest
from pathlib import Path

from build_language_data import add_spanish_emoji_names, verify_spanish_emoji_sources


class SpanishEmojiNameTests(unittest.TestCase):
  def source(self, directory, name, body, language='es'):
    path = Path(directory) / name
    path.write_text(f'<ldml><identity><language type="{language}"/></identity>'
                    f'<annotations>{body}</annotations></ldml>', encoding='utf-8')
    return path

  def test_speech_names_join_existing_bases_without_changing_english_fields(self):
    baseline = {'version': '18.0', 'categories': [{'id': 'objects', 'name': 'Objects', 'emoji': [
      {'e': '☕️', 'n': 'hot beverage', 'v': 0.6, 'k': ['coffee', 'drink']},
      {'e': '👍', 'n': 'thumbs up', 'v': 0.6, 't': ['👍🏻', '👍🏼', '👍🏽', '👍🏾', '👍🏿']},
      {'e': '🫪', 'n': 'new emoji', 'v': 18.0},
    ]}]}
    with tempfile.TemporaryDirectory() as directory:
      base = self.source(directory, 'base.xml',
        '<annotation cp="☕">unrelated keyword</annotation>'
        '<annotation cp="☕" type="tts">bebida caliente</annotation>'
        '<annotation cp="🫂" type="tts">abrazo</annotation>')
      derived = self.source(directory, 'derived.xml',
        '<annotation cp="☕️" type="tts">bebida caliente</annotation>'
        '<annotation cp="👍" type="tts">pulgar hacia arriba</annotation>')
      result = add_spanish_emoji_names(copy.deepcopy(baseline), [base, derived])
      entries = result['categories'][0]['emoji']
      self.assertEqual([e.get('s') for e in entries],
                       ['bebida caliente', 'pulgar hacia arriba', None])
      for entry in entries:
        entry.pop('s', None)
      self.assertEqual(result, baseline)

  def test_conflicts_wrong_language_and_unpinned_rebuild_inputs_are_rejected(self):
    with tempfile.TemporaryDirectory() as directory:
      base = self.source(directory, 'base.xml', '<annotation cp="☕" type="tts">bebida</annotation>')
      conflict = self.source(directory, 'derived.xml', '<annotation cp="☕️" type="tts">café</annotation>')
      wrong = self.source(directory, 'wrong.xml', '<annotation cp="☕" type="tts">coffee</annotation>', 'en')
      for paths in ([base, conflict], [wrong]):
        with self.assertRaises(ValueError):
          add_spanish_emoji_names({'categories': []}, paths)
      for paths in ([], [base], [base, base], [base, conflict]):
        with self.assertRaisesRegex(ValueError, 'pinned CLDR48'):
          verify_spanish_emoji_sources(paths)


if __name__ == '__main__':
  unittest.main()
