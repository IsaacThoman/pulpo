# R33 v4 static reseal decision: REJECT

Decision code: RETRY_HISTORY_NOT_RETAINED_ON_WORKER_RESPONSE_TIMEOUT.

The new runner yields only in the confirmed-busy retry branch. The 5000-attempt and 5-second checks, operation handling, schema, expectations and oracle comparisons are unchanged. An AST comparison confirmed no changes beyond the yield, BusyDeadline history carrier and its unavailable event.

Blocking finding: BusyDeadline retains history when the retry count/deadline check fires, but a retried actor.command can instead raise the ordinary worker-response TimeoutError from Actor.read. await_expected then exits without returning its local retry list. The caller's tuple assignment never completes, and the generic exception handler records only unavailable because this exception is not BusyDeadline. Collected retry command/results are lost. This violates the approved supplement's requirement to preserve every retry, and the requested all-timeout retention claim. This is a static control-flow finding, with zero runner, worker or product executions.

Static --novel validation: PASS, 1 current attempt, 0 failures, 0 novelty conflicts; 3 prior attempts, 4 total. Counts remain 18 cases, 388 actions, 361 typed oracles, 6 barriers and 64 actor processes. The original 64 touch computations and sealed manual feasibility review remain applicable by exact payload/input/manual-review hashes and unchanged public semantics; no fresh numerical recomputation is claimed. Unsupported categories remain 10 and their sealed bytes are unchanged. Two original preseal oracle corrections remain historical only.

Payload and every approved old input matched the old seal; gzip decompressed losslessly to the original payload. No old input, payload, oracle, author artifact or seal was modified. No reseal was issued. No case contents, targets or oracle values appear here.

All exact input hashes, prior references, counts, validator outcome and the blocking finding are recorded in the accompanying JSON.

Payload SHA-256: `0834b19e144e30b46506484d04e5d61748976e4e8699614525340bc1e06ccbae`

Prior seal SHA-256: `b5114fd3d2b586ac3d1e0a8e2696e0ae20a5ccc02daba78f6fdd420992fc1c68`

- `contract-preflight-v3.md`: `a517f4b627b3575a99d0959240a0a6bd3a0dd2781c7d763c52214fe714799ccd`
- `schema-preflight-v3.json`: `2b7a34f6c482a6ac0ffe7f23c2d9964c72b6f31c34eed3f0b7aa59f75e4cb6ef`
- `public-api-v3.md`: `85289af4b0993e78250b0d223d28aa4568ca0488036dd0356f1818c8c701997e`
- `worker-v3.swift`: `420e7003a48cf7d5a5b63945830cbf03250a871e6c2661e6b57e37632fa9a6f7`
- `run-v3.py`: `a36d009cd3a7dea65dee1320a144019b3765c940c62d1fafa0f98cf57fd63c91`
- `validate-v3.py`: `218cb903730a3557f53b0a7d353be3e40354548a3eb7700d02ca780eecd05d64`
- `transaction-gate-v3.c`: `c16b02907a8ac665f071ac94b24b427b843f3b92ba45caf56ffb2fca30cf9b0d`
- `r29-exclusion-hashes.json`: `f8c67549c31e650cf283f01ade44922e73ad584aed52ab118c39142e2fc54a77`
- `adapter-capabilities-v3.md`: `f24e6e50f9fc803282cfe86a2a2474ec56ed94ca120584d06d501f613dc36b2d`
- `run-v4.py`: `26e965bab271156d8b744ebdf8ec5fe30ab3d17523c3de92f8d8b0c360517e85`

JSON artifact: `/tmp/pulpo-r33-blind/rejection-v4.json`

Markdown artifact: `/tmp/pulpo-r33-blind/rejection-v4.md`
