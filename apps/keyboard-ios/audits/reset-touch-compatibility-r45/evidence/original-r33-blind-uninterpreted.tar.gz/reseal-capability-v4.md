Decision: **ACCEPT_STATIC_RESEAL** (independent blind static capability reseal, round 4).

Payload SHA256: `0834b19e144e30b46506484d04e5d61748976e4e8699614525340bc1e06ccbae`.
Runner SHA256: `09072bc189cfedf010caad9b401b00e6e6f6b8e06f0fe025ce432ef8c4af48dd`.
Capability v4 SHA256: `5f05353a1596ccc8470f072add6a129ecd578c636aca68c7f7199351c8f6d85f`.
JSON SHA256: `a46b6b7ca7f4319771fafba5bde348e0e7387132c58574701530dd8767adb040`.

18 cases; 388 actions; 361 expected oracles (218 typed results, 79 scalar queries, 64 touch calculations); 6 barriers; 64 actor processes. All expectations manually reviewed against the public map. All 64 touch calculations recomputed from the public formula.

Normalization: 222 string occurrences, 103 unique strings, 32 non-ASCII occurrences; 0 operation-order differences on these payload inputs; 14 normalization-case scalar oracles independently rechecked; 1 raw-word byte-limit recheck; 0 semantic or numeric mismatches.

Static `--novel` validation: 1 current attempt, 0 failures; 7 recorded attempts total (3 original author, 1 prior rejected-runner review, 2 prior accepted-runner review, 1 current). Prior 2 preseal oracle corrections remain recorded. Prior fake harness: 32/32 final checks, 2 invocations, 7 initial fixture failures retained; 0 current fake harness invocations.

10 unsupported categories unchanged. 0 payload/oracle/seal/input edits; all original artifact and approved input hashes verified. 0 product executions, real worker executions, sealed schedule executions, or nested delegations.

Artifacts: `/tmp/pulpo-r33-blind/reseal-capability-v4.json` and `/tmp/pulpo-r33-blind/reseal-capability-v4.md`.

Exact hashes, byte counts, history counts, validator output, and scope are in the JSON. This is a static compatibility decision; candidate freeze and the single reveal remain required.
