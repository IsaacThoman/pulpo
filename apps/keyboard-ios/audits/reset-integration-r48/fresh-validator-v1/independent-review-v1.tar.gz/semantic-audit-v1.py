import hashlib,json,pathlib,collections
P=pathlib.Path(__file__).resolve().parent;B=P/'review-v1/author-review-v1'
f=json.loads((B/'fixtures.json').read_text());ref=json.loads((P/'independent-reference-values.json').read_text());a=json.loads((B/'accounting.json').read_text());byid={o['id']:o for o in f['operations']};states={};prefix={};proof=[];problems=[]
def need(x,m):
 if not x:raise RuntimeError(m)
for fam in f['families']:need(fam['reference']==next(x for x in ref if x['id']==fam['id']),'reference literal')
for o in f['operations']:
 sid=o['session'];op=o['op'];e=o['expect'];i=o['input']
 if sid is None:continue
 if op=='construct':
  states[sid]={'accepted':[],'learning':None,'last':o,'settled':True,'ai':0};problems.append({'code':'UNSPECIFIED_INITIAL_LEARNING_DEFAULT','operation':o['id'],'severity':'blocking'})
 else:
  s=states[sid];prev=s['last']
  if op=='setLearning':s['learning']=i['value'];need(e['projectionEq']==prev['id'] and e['filesEq']==prev['id'],'setter conservation')
  if op=='learn':
   if o['id'].endswith('/seed'):
    # Independently audit seed shape and taps rather than trusting special-cased author preflight.
    need(i['text']==i['target'] and len(i['text'])==len(i['taps'])>=2,'seed literal')
    need(all(p['base']==c and p['dx']!=0 and p['dy']!=0 for c,p in zip(i['target'],i['taps'])),'seed target-relative positive displacements')
    accepted=True
   else:
    fam=next(x for x in f['families'] if sid.startswith(x['id']+'/'));r=fam['reference']['alignments'][s['ai']];s['ai']+=1;orig=r['contributingOrigins'];enabled=s['learning'] if s['learning'] is not None else True
    accepted=enabled and orig is not None and (sid.endswith('/local') or len(orig)<=40)
   need(e['returned']==accepted and e['status']==('ok' if accepted else 'invalid'),'independent admission')
   if accepted:
    need(e.get('nonzero') and e.get('projectionDiffersFrom')==prev['id'],'positive accepted reference');s['accepted'].append(i);s['settled']=False
   else:
    need(s['settled'] and e['projectionEq']==prev['id'] and e['filesEq']==prev['id'],'settled rejection full conservation')
  elif op=='save':need(i['inBackground'] is False and e['returned'] is True and e['status']=='ok' and e['projectionEq']==prev['id'],'sync save');s['settled']=True
  elif op=='observe':need(prev['op']=='learn' and prev['expect']['returned'] is False and e['projectionEq']==prev['id'] and e['filesEq']==prev['id'] and e['status']=='invalid','invalid retained observation')
  elif op=='reload':need(e['returned'] is False and e['status']=='ok' and e['projectionEq']==prev['id'],'normal false ok observation')
  elif op=='reopen':
   need(s['settled'] and e['status']=='ok' and byid[e['projectionEq']]['op']=='save','fresh settled durable relation');problems.append({'code':'UNSPECIFIED_REOPEN_LEARNING_DEFAULT','operation':o['id'],'severity':'blocking'});s['learning']=None
  s['last']=o
 prefix[o['id']]=list(states[sid]['accepted'])
for r in f['relations']:
 need(prefix[r['left']]==prefix[r['right']],'same accepted sequence exact order')
 proof.append({'id':r['id'],'sameAcceptedOperations':len(prefix[r['left']]),'fullProjectionRequired':True})
need(len(proof)==49 and all(x['sameAcceptedOperations']>0 for x in proof),'nonvacuous relational coverage')
need(len(f['families'])>=12 and len(f['instances'])>=16,'family requirement')
result={'format':'independent-r48-semantic-audit-v1','referenceMatches':18,'alignmentMatches':sum(len(r['alignments']) for r in ref),'families':len(f['families']),'instances':len(f['instances']),'allDeclaredRelationsIndependentlyReviewed':True,'relations':proof,'blockingFindingClasses':2,'blockingOperationOccurrences':len(problems),'findings':problems,'conditionalAdmissionAudit':'All declared acceptance/rejection oracles match approved semantics if unspecified default learning state is assumed true; this assumption is not approved by domain map.','runnerReview':{'everyActionBranchReviewed':True,'directPublicAPICalls':True,'fullProjectionPerModelRecord':True,'sequential':True,'mutationRetries':0,'readRetries':0,'backgroundSaves':0,'declarationOnlyIndependentTypecheck':'pass; zero stub executions'},'productExecutions':0}
(P/'semantic-audit-v1.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['relations','findings']}))
