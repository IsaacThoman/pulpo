import gzip,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;B=P/'review-v1/author-review-v1';base=json.loads(gzip.decompress((P/'adversarial-normal/baseline.json.gz').read_bytes()));f=json.loads((B/'fixtures.json').read_text());id=next(o['id'] for o in f['operations'] if o['op']=='learn' and o['expect']['returned'] is False)
results=[]
for mode in ['normal','optimized']:
 for kind in ['pass','behavior','shape','unavailable-invalid','unavailable-busy']:
  raw=json.loads(json.dumps(base));r=next(x for x in raw['operations'] if x['id']==id)
  if kind=='behavior':r['state']['weight']+=1.
  elif kind=='shape':raw['extra']=1
  elif kind=='unavailable-invalid':r.update(available=False,error='independent mechanical inventory failure')
  elif kind=='unavailable-busy':r.update(available=False,error='independent mechanical inventory failure',status='busy')
  rp=P/(mode+'-cli-'+kind+'.json');rp.write_text(json.dumps(raw));cmd=[sys.executable]+(['-O'] if mode=='optimized' else [])+[str(B/'evaluate.py'),str(rp)];p=subprocess.run(cmd,capture_output=True,text=True)
  (P/(mode+'-cli-'+kind+'-stdout.json')).write_text(p.stdout);(P/(mode+'-cli-'+kind+'-stderr.txt')).write_text(p.stderr)
  j=json.loads(p.stdout);want=0 if kind=='pass' else 2 if kind=='shape' else 1
  if p.returncode!=want:raise RuntimeError((mode,kind,p.returncode,want))
  results.append({'mode':mode,'kind':kind,'exit':p.returncode,'actualAccounting':j.get('actualAccounting'),'checks':j.get('denominators',{}).get('individualChecks'),'passedChecks':j.get('passedChecks'),'failedChecks':len(j.get('failedCheckIDs',[]))})
normal={x['kind']:x for x in results if x['mode']=='normal'}
result={'pass':True,'cliExitsValidated':[0,1,2],'results':results,'confirmedAccountingFindings':{'unavailableIntentionalInvalidStillCounted':normal['pass']['actualAccounting']['observedExpectedInvalidRejections']==normal['unavailable-invalid']['actualAccounting']['observedExpectedInvalidRejections'],'unavailableBusyNotReportedAsUnexpected':normal['unavailable-busy']['actualAccounting']['unexpectedStatuses']==0},'productRuns':0}
(P/'cli-check-v1.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='results'}))
