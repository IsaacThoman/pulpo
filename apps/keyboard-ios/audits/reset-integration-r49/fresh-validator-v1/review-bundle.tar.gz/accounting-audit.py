from pathlib import Path
import json,gzip,collections,copy,importlib.util
A=Path('/tmp/pulpo-r49-fresh-author-v1');D=Path('/tmp/pulpo-r49-fresh-validator-v1');e=json.loads((A/'expectations.json').read_text());base=json.loads((A/'synthetic-raw.json').read_text())
want={'unavailable_intentional_invalid','unfired_intentional_invalid','unavailable_observed_busy','unavailable_observed_capacity','unavailable_observed_io','unavailable_observed_uncertain','unavailable_observed_cleanup'}
def independent(raw):
 rows=raw['operations'];learn=[r for r in rows if r['op']=='learn'];statuses=collections.Counter(r['status'] for r in rows if r['invoked'] and r['status'] is not None)
 return {'invoked_actions':sum(r['invoked'] for r in rows),'invoked_learns':sum(r['invoked'] for r in learn),'verified_accepted_learns':sum(r['available'] and r['invoked'] and e['operations'][r['id']]['returned'] is True and r['returned'] is True and r['status']=='ok' for r in learn),'verified_intentional_invalid_learns':sum(r['available'] and r['invoked'] and e['operations'][r['id']]['returned'] is False and r['returned'] is False and r['status']=='invalid' for r in learn),'retained_invoked_status_counts':dict(statuses),'transport_unavailable':sum(not r['available'] for r in rows),'unfired':sum(not r['invoked'] for r in rows)}
results=json.loads((D/'independent-results-normal.json').read_text());reports={x['id']:x['report'] for x in results['results']};w=[]
with gzip.open(D/'independent-inputs-normal.jsonl.gz','rt') as g:
 for line in g:
  x=json.loads(line)
  if x['id'] in want:w.append({'id':x['id'],'raw_sha256':x['raw_sha256'],'independent_actual_facts':independent(x['raw']),'frozen_evaluator_report':reports[x['id']]})
spec=importlib.util.spec_from_file_location('ev',A/'evaluate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
v=copy.deepcopy(base)
for r in v['operations']:
 if r['op']=='learn' and e['operations'][r['id']]['returned'] is True:r.update(available=False,error='independent accepted-call inventory unavailability');break
path=D/'unavailable-accepted.json';path.write_text(json.dumps(v,separators=(',',':')));code,report=m.evaluate(path)
if code!=1:raise RuntimeError('false success')
w.append({'id':'unavailable_accepted_learn','raw_sha256':__import__('hashlib').sha256(path.read_bytes()).hexdigest(),'independent_actual_facts':independent(v),'frozen_evaluator_report':report})
normal=json.loads((D/'independent-results-normal.json').read_text());optimized=json.loads((D/'independent-results-optimized.json').read_text())
if normal['results']!=optimized['results']:raise RuntimeError('mode divergence')
(D/'accounting-audit.json').write_text(json.dumps({'baseline_actual_facts':independent(base),'witnesses':w,'normal_optimized_results_identical':True,'finding':'No actual calls/learn outcomes or retained observed unexpected-status counts are emitted by the frozen evaluator; expected_invalid_rejections=31 is planned only. Witnesses continue to fail with exit1 and preserve 452/772 denominators.'},indent=2)+'\n');print(json.dumps({'baseline':independent(base),'witnesses':len(w),'modes_identical':True},sort_keys=True))
