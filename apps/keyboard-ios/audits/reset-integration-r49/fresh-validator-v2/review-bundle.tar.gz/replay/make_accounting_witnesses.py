"""Declare only synthetic reporting counterexamples; no behavior/oracle changes."""
from pathlib import Path
import json,collections
D=Path(__file__).resolve().parent
raw=json.loads((D/'synthetic-raw.json').read_text());index={r['id']:i for i,r in enumerate(raw['operations'])};cases=[]
reject='transactional_invalid.local.invalid0';accept='target_geometry.local.seed'
def patch(id,key,v):return {'action':'set','path':['operations',index[id],key],'value':v}
def emit(id,exit,patches=[],text=None):cases.append({'id':id,'expected_exit':exit,'patches':patches,'text_mutation':text})
emit('full_plan_complete',0)
emit('expected_rejection_unavailable',1,[patch(reject,'available',False),patch(reject,'error','synthetic inventory unavailable')])
emit('expected_rejection_unfired',1,[patch(reject,'available',False),patch(reject,'invoked',False),patch(reject,'error','synthetic blocked'),patch(reject,'returned',None),patch(reject,'status',None),patch(reject,'state',None),patch(reject,'resolvedInput',None),patch(reject,'files',[])])
emit('unfired_stale_status_not_observed',1,[patch(reject,'invoked',False)])
emit('expected_acceptance_unavailable',1,[patch(accept,'available',False),patch(accept,'error','synthetic inventory unavailable')])
for status in ('busy','capacity','io','uncertain','cleanup'):
 for available in (True,False):
  emit('unexpected_'+status+('_available' if available else '_unavailable'),1,[patch(accept,'status',status),patch(accept,'available',available),patch(accept,'error',None if available else 'synthetic inventory unavailable')])
emit('unavailable_reject_unexpected_status',1,[patch(reject,'status','io'),patch(reject,'available',False),patch(reject,'error','synthetic inventory unavailable')])
emit('unfired_unavailable_stale_storage_status',1,[patch(reject,'invoked',False),patch(reject,'status','busy'),patch(reject,'available',False),patch(reject,'error','synthetic blocked')])
emit('wrong_acceptance_not_verified_expected_success',1,[patch(reject,'returned',True),patch(reject,'status','ok')])
emit('wrong_rejection_not_verified_intended_invalid',1,[patch(accept,'returned',False),patch(accept,'status','invalid')])
emit('invoked_unavailable_no_outcome_claim',1,[patch(accept,'available',False),patch(accept,'error','synthetic unavailable'),patch(accept,'returned',None),patch(accept,'status',None),patch(accept,'state',None)])
emit('missing_record_unknown',2,[{'action':'delete','path':['operations',len(raw['operations'])-1]}])
emit('missing_field_unknown',2,[{'action':'delete','path':['operations',index[accept],'invoked']}])
emit('nonboolean_invocation_unknown',2,[patch(accept,'invoked',1)])
emit('unsupported_status_unknown',2,[patch(accept,'status','unsupported')])
emit('nonfinite_json_unknown',2,text='nan_token')
emit('duplicate_json_key_unknown',2,text='duplicate_top_format')
emit('truncated_json_unknown',2,text='truncate')
emit('missing_file_unknown',2,text='missing_file')
(D/'accounting-witnesses.json').write_text(json.dumps(cases,indent=2,allow_nan=False)+'\n')
