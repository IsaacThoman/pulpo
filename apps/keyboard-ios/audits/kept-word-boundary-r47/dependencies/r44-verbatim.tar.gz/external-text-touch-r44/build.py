#!/usr/bin/env python3
import pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parents[4]
audit=pathlib.Path(__file__).resolve().parent
out=pathlib.Path(sys.argv[1]); out.mkdir(parents=True,exist_ok=True)
main=out/'Runner.swift'; main.write_bytes((audit/'Runner.swift.txt').read_bytes())
sources=sorted((root/'apps/keyboard-ios/PulpoKeyboardKit/Sources/KeyboardCore').rglob('*.swift'))
if len(sys.argv)>2 and sys.argv[2]=='--baseline':
 baseline=out/'KeyboardEngine.swift'; baseline.write_bytes((audit/'baseline-KeyboardEngine.swift.txt').read_bytes())
 sources=[x for x in sources if x.name!='KeyboardEngine.swift']+[baseline]
with (out/'build.log').open('w') as log:
 r=subprocess.run(['swiftc','-O','-parse-as-library',*map(str,sources),str(main),'-o',str(out/'runner')],stdout=log,stderr=log)
if r.returncode: print((out/'build.log').read_text()); sys.exit(r.returncode)
print(out/'runner')
