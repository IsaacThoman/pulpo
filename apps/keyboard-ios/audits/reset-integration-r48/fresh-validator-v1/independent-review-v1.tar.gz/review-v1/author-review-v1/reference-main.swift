import Foundation
let root = URL(fileURLWithPath: "/tmp/pulpo-r48-fresh-author")
let data = try Data(contentsOf: root.appendingPathComponent("design.json"))
let design = try JSONSerialization.jsonObject(with: data) as! [String: Any]
var refs: [[String: Any]] = []
for family in design["families"] as! [[String: Any]] {
  let normalizationInput = family["normalizationInput"] as! String
  var alignments: [[String: Any]] = []
  for step in family["steps"] as! [[String: Any]] where step["op"] as! String == "learn" {
    let a = publicAlignmentReference(text: step["text"] as! String, target: step["target"] as! String)
    let taps = step["taps"] as! [Any]
    let finite: [Bool?] = taps.map { t in
      guard let d = t as? [String: Any] else { return nil }
      if d["base"] != nil { return true }
      return d["x"] is NSNumber && d["y"] is NSNumber
    }
    let contributing = a.contributingOrigins(finitePoints: finite)
    alignments.append(["characters": a.characters, "typedBytes": a.typedBytes.map(Int.init), "origins": a.origins, "targetBytes": a.targetBytes.map(Int.init), "contributingOrigins": contributing as Any? ?? NSNull()])
  }
  refs.append(["id": family["id"]!, "normalized": publicKeyReference(normalizationInput), "alignments": alignments])
}
let result = try JSONSerialization.data(withJSONObject: refs, options: [.prettyPrinted, .sortedKeys, .fragmentsAllowed])
try result.write(to: root.appendingPathComponent("reference-values.json"))
