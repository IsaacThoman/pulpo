from pathlib import Path
import json,sys,copy,gzip,collections,importlib.util,contextlib,io,tempfile,hashlib
A=Path('/tmp/pulpo-r49-fresh-author-v2');D=Path('/tmp/pulpo-r49-fresh-validator-v2');V=Path('/tmp/pulpo-r49-fresh-validator-v1');mode='optimized' if sys.flags.optimize else 'normal'
def need(v,s):
 if not v:raise RuntimeError(s)
def load(p):return json.loads(p.read_text())
f=load(A/'fixtures.json')['operations'];spec=load(A/'expectations.json')['operations'];base=load(A/'synthetic-raw.json');ids=[o['id'] for o in f];pos={id:i for i,id in enumerate(ids)};planned={'operations':452,'learn_calls':80,'expected_accepted_learn_calls':49,'intended_invalid_learn_calls':31};statuses=['ok','invalid','busy','capacity','io','uncertain','cleanup']
sp=importlib.util.spec_from_file_location('frozen_v2',A/'evaluate.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
# Reviewer-only reference independently inventories strictly validated raw facts.
# Separate ID sets, then stable ordered projection, avoid using the new helper.
def truth(raw,code):
 if code==2:return {'format':'pulpo-r49-observed-accounting-v2','known':False,'planned':planned,'observed':None,'unknown_operation_ids':ids}
 rows=raw['operations'];by={r['id']:r for r in rows};F={r['id'] for r in rows if r['invoked'] is True};L={o['id'] for o in f if o['op']=='learn'};U={r['id'] for r in rows if r['available'] is False};S={r['id'] for r in rows if r['invoked'] is True and r['session'] is not None and r['status'] is not None};T={id for id in F&L if by[id]['returned'] is True};K={id for id in T if by[id]['status']=='ok'}
 accept={id for id in K-U if spec[id]['returned'] is True};reject={id for id in F&L-U if spec[id]['returned'] is False and spec[id]['status']=='invalid' and by[id]['returned'] is False and by[id]['status']=='invalid'}
 groups={'actual_invocation':F,'actual_learn_call':F&L,'observed_true_learn_return':T,'observed_true_ok_learn_outcome':K,'verified_expected_accepted_learn':accept,'verified_intended_invalid_rejection':reject,'unexpected_learn_outcome':{id for id in F&L if by[id]['returned'] is not None and (by[id]['returned'] is not spec[id]['returned'] or by[id]['status'] is not None and by[id]['status']!=spec[id]['status'])},'unavailable_operation':U,'unfired_operation':set(ids)-F,'unknown_learn_outcome':L&(U|(set(ids)-F)),'unknown_invoked_model_status':{r['id'] for r in rows if r['invoked'] and r['session'] is not None and r['status'] is None},'unexpected_observed_status':{id for id in S if by[id]['status']!=spec[id]['status']},'unexpected_storage_status':{id for id in S if by[id]['status'] not in ('ok','invalid')}}
 out={}
 for key,values in groups.items():out[key+'_count']=len(values);out[key+'_ids']=[id for id in ids if id in values]
 out['status_counts']={s:sum(by[id]['status']==s for id in S) for s in statuses}
 out['status_ledger']=[{'id':id,'status':by[id]['status'],'available':by[id]['available'],'expected_status':spec[id]['status'],'unexpected':id in groups['unexpected_observed_status']} for id in ids if id in S]
 out['learn_outcome_ledger']=[{'id':id,'returned':by[id]['returned'],'status':by[id]['status'],'available':by[id]['available'],'expected_returned':spec[id]['returned'],'expected_status':spec[id]['status'],'classification':'verified_expected_acceptance' if id in accept else 'verified_intended_invalid_rejection' if id in reject else 'unavailable_outcome' if id in U else 'unexpected_outcome'} for id in ids if id in F&L]
 return {'format':'pulpo-r49-observed-accounting-v2','known':True,'planned':planned,'observed':out,'unknown_operation_ids':[]}
def validate(report,expected):
 actual=report['accounting']
 for k,v in expected.items():need(actual[k]==v,'counter mismatch '+k)
 need(report['operations_denominator']==452 and report['checks_denominator']==772,'denominators')
 need('expected_invalid_rejections' not in report,'ambiguous old field')
 if expected['known']:
  need(report['diagnostic_message_count']==report['failure_count']==len(report['failures']),'diagnostic count');need(report['failure_count_unit']=='diagnostic_messages_not_failed_aggregates','unit')
 else:need(report['unavailable_operations'] is None and report['unfired_operations'] is None,'strict-invalid unknown counters')
results=[];raw_archive=gzip.open(D/('independent-inputs-'+mode+'.jsonl.gz'),'wt',encoding='utf8')
with tempfile.TemporaryDirectory(dir=D) as td:
 path=Path(td)/'raw.json'
 def run(name,value,want,old=None,text=None,missing=False):
  data=json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False) if text is None else text
  if missing:
   if path.exists():path.unlink()
  else:path.write_text(data)
  oldargv=sys.argv;sys.argv=['evaluate.py',str(path)];capture=io.StringIO()
  try:
   with contextlib.redirect_stdout(capture):code=m.main()
  finally:sys.argv=oldargv
  report=json.loads(capture.getvalue());need(code==want,name+' code mismatch '+str(code));expected=truth(value,code);validate(report,expected)
  if old is not None and code!=2:
   for k,v in old.items():
    if k!='expected_invalid_rejections':need(report[k]==v,name+' changed prior behavioral result '+k)
  rawsha=None if missing else hashlib.sha256(data.encode()).hexdigest()
  raw_archive.write(json.dumps({'id':name,'raw_sha256':rawsha,'raw':None if missing else value,'text_override':text,'missing_file':missing},ensure_ascii=False,separators=(',',':'))+'\n')
  results.append({'id':name,'exit':code,'raw_sha256':rawsha,'report':report})
  return report
 prior={x['id']:x for x in load(V/'independent-results-normal.json')['results']}
 with gzip.open(V/'independent-inputs-normal.jsonl.gz','rt') as g:
  for line in g:
   x=json.loads(line);o=prior[x['id']];run('prior_'+x['id'],x['raw'],o['exit'],old=o['report'])
 # Original eighth witness was outside the old 843-case stream.
 run('original_unavailable_accepted',load(V/'unavailable-accepted.json'),1)
 # Fresh combinations independently challenge known/unknown and every status.
 accepted=next(o['id'] for o in f if o['op']=='learn' and spec[o['id']]['returned'] is True)
 rejected=next(o['id'] for o in f if o['op']=='learn' and spec[o['id']]['returned'] is False)
 for who in [accepted,rejected]:
  for available in [False,True]:
   for invoked in [False,True]:
    for status in [None,*statuses]:
     for ret in [None,False,True]:
      v=copy.deepcopy(base);r=v['operations'][pos[who]];r.update(available=available,invoked=invoked,status=status,returned=ret,error=None if available else 'independent unavailable')
      strict=available and invoked and (status is None or ret is None)
      want=2 if strict else 0 if available and invoked and status==spec[who]['status'] and ret is spec[who]['returned'] else 1
      run('outcome_matrix_'+str(pos[who])+'_'+str(available)+'_'+str(invoked)+'_'+str(status)+'_'+str(ret),v,want)
 # API outcome counters must not certify state or relation correctness.
 v=copy.deepcopy(base);v['operations'][pos[accepted]]['state']['weight']=0
 rep=run('valid_api_outcome_bad_state',v,1);need(rep['accounting']['observed']['verified_expected_accepted_learn_count']==49,'outcome vs state distinction')
 # Broken IDs/inputs/type coercions/nonfinite/extra alleged counters are unknown.
 for name,mut in [
  ('false_id',lambda v:v['operations'][0].update(id='false')),
  ('wrong_input',lambda v:v['operations'][0]['input'].update(byte=True)),
  ('extra_alleged_count',lambda v:v.update(actual_invocation_count=452)),
  ('extra_alleged_record_count',lambda v:v['operations'][0].update(actual_invocation_count=1)),
  ('boolean_return',lambda v:v['operations'][pos[accepted]].update(returned=1)),
  ('boolean_availability',lambda v:v['operations'][pos[accepted]].update(available=1)),
  ('boolean_invocation',lambda v:v['operations'][pos[accepted]].update(invoked=1)),
  ('unknown_status',lambda v:v['operations'][pos[accepted]].update(status='unsupported')),
  ('nonfinite_tag',lambda v:v['operations'][pos[accepted]]['state'].update(weight='nan')),
 ]:
  v=copy.deepcopy(base);mut(v);run(name,v,2)
 s=json.dumps(base,separators=(',',':'))
 for name,text in [('json_nan',s.replace('"weight":0','"weight":NaN',1)),('json_infinity',s.replace('"weight":0','"weight":Infinity',1)),('json_overflow',s.replace('"weight":0','"weight":1e9999',1)),('duplicate_json','{"format":"pulpo-r48-raw-v2",'+s[1:]),('truncated_json',s[:-2])]:run(name,base,2,text=text)
 run('missing_file',base,2,missing=True)
 # Validator sensitivity: falsified returned reporting objects cannot satisfy
 # independently reconstructed counts, ID sets or ledger classifications.
 rep=run('independent_baseline',base,0);counter_mutants=[]
 for key in [k for k in rep['accounting']['observed'] if k.endswith('_count')]:
  bad=copy.deepcopy(rep);bad['accounting']['observed'][key]+=1
  try:validate(bad,truth(base,0))
  except RuntimeError:counter_mutants.append(key)
  else:raise RuntimeError('falsified count accepted '+key)
 for key in [k for k in rep['accounting']['observed'] if k.endswith('_ids')]:
  bad=copy.deepcopy(rep);bad['accounting']['observed'][key].append('false-id')
  try:validate(bad,truth(base,0))
  except RuntimeError:counter_mutants.append(key)
  else:raise RuntimeError('falsified IDs accepted '+key)
 for key in ['status_counts','status_ledger','learn_outcome_ledger']:
  bad=copy.deepcopy(rep)
  if key=='status_counts':bad['accounting']['observed'][key]['busy']=1
  else:bad['accounting']['observed'][key][0]['available']=False
  try:validate(bad,truth(base,0))
  except RuntimeError:counter_mutants.append(key)
  else:raise RuntimeError('falsified ledger accepted '+key)
raw_archive.close()
(D/('independent-results-'+mode+'.json')).write_text(json.dumps({'mode':mode,'synthetic_only':True,'cases':len(results),'falsified_report_counterchecks':counter_mutants,'results':results},indent=2)+'\n')
print(json.dumps({'mode':mode,'cases':len(results),'falsified_reporting_objects_rejected':len(counter_mutants),'all_counts_ids_ledgers_checked':True},sort_keys=True))
