#!/usr/bin/env python3
"""Strict frozen preexecution/evaluation implementation. Python Unicode is never an oracle."""
import argparse, hashlib, json, math, pathlib, re, sys
ROOT=pathlib.Path(__file__).resolve().parent
class Invalid(Exception): pass
def need(ok,msg):
    if not ok: raise Invalid(msg)
def keys(x,ks,label):need(type(x) is dict and set(x)==set(ks),label+' fields')
def number(x):
    if type(x) not in (int,float):return False
    try:return math.isfinite(x)
    except OverflowError:return False
def string(x):return type(x) is str
def strict_pairs(pairs):
    d={}
    for k,v in pairs:
        need(k not in d,'duplicate JSON key '+k);d[k]=v
    return d
def read(path):
    def bad(x):raise Invalid('nonfinite JSON token '+x)
    def finite_float(token):
        value=float(token);need(math.isfinite(value),'overflow JSON number');return value
    with open(path,encoding='utf8') as f:return json.load(f,object_pairs_hook=strict_pairs,parse_constant=bad,parse_float=finite_float)
def equal(a,b):
    if type(a) is not type(b):return False
    if type(a) is dict:return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
    if type(a) is list:return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b
# Fixture exactness is hash-frozen as well as semantically checked below.
def inputcheck(op,d):
    if op=='center':keys(d,['byte'],'center input');need(type(d['byte']) is int and 97<=d['byte']<=122,'center byte')
    elif op=='normalize':keys(d,['text'],'normalize input');need(string(d['text']),'normalize text')
    elif op=='construct':keys(d,['persistent'],'construct input');need(type(d['persistent']) is bool,'persistent boolean')
    elif op=='learn':
        keys(d,['text','target','taps'],'learn input');need(string(d['text']) and string(d['target']) and type(d['taps']) is list,'learn values')
        for p in d['taps']:
            if p is None:continue
            need(type(p) is dict,'tap type')
            if 'base' in p:
                keys(p,['base','dx','dy'],'relative point');need(p['base'] in list('abcdefghijklmnopqrstuvwxyz') and number(p['dx']) and number(p['dy']),'relative values')
            else:
                keys(p,['x','y'],'absolute point')
                for n in p.values():need(number(n) or (string(n) and n in ['nan','posInf','negInf']),'tagged input number')
    elif op=='save':keys(d,['inBackground'],'save input');need(d['inBackground'] is False,'synchronous saves only')
    elif op=='setLearning':keys(d,['value'],'learning input');need(type(d['value']) is bool,'learning boolean')
    elif op in ['reload','reopen','observe']:keys(d,[],op+' input')
    else:raise Invalid('unknown operation '+str(op))
def names(o):
    e=o['expect'];n=['available']
    if e['kind']=='center':return n+['finite-center']
    if e['kind']=='literal':return n+['literal']
    n+=['status','return','learning','state-shape-finite-bounds']
    return n+[k for k in ['zero','nonzero','projectionEq','filesEq','projectionDiffersFrom','nonemptyFiles'] if k in e]
def preflight():
    f=read(ROOT/'fixtures.json');keys(f,['format','tolerance','families','instances','operations','relations','denominators'],'fixtures')
    need(f['format']=='pulpo-r48-fixtures-v1' and type(f['tolerance']) is float and f['tolerance']==1e-10,'fixture protocol/tolerance')
    refs=read(ROOT/'reference-values.json');design=read(ROOT/'design.json');keys(design,['families'],'design')
    need(type(f['families']) is list and len(f['families'])==18,'family coverage')
    need([x['id'] for x in f['families']]==[x['id'] for x in refs]==[x['id'] for x in design['families']],'reference ID coverage')
    for fam,ref in zip(f['families'],refs):
        keys(fam,['id','intent','independence','reference'],'family');need(equal(fam['reference'],ref),'literal reference binding')
        need(all(string(fam[k]) and fam[k] for k in ['id','intent','independence']),'family strings')
        keys(ref,['id','normalized','alignments'],'reference')
        for a in ref['alignments']:
            keys(a,['characters','typedBytes','origins','targetBytes','contributingOrigins'],'alignment')
            need(type(a['characters']) is list and all(string(x) for x in a['characters']),'characters')
            for k in ['typedBytes','targetBytes']:need(type(a[k]) is list and all(type(b) is int and 0<=b<=255 for b in a[k]),'reference bytes')
            need(type(a['origins']) is list and len(a['origins'])==len(a['typedBytes']) and all(type(i) is int and 0<=i<len(a['characters']) for i in a['origins']),'reference origins')
            need(a['contributingOrigins'] is None or type(a['contributingOrigins']) is list,'contributions type')
    need(type(f['instances']) is list and len(f['instances'])==36,'instances')
    ss={}
    for i in f['instances']:
        keys(i,['id','family','mode'],'instance');need(i['id']==i['family']+'/'+i['mode'] and i['mode'] in ['local','persistent'] and i['id'] not in ss,'instance identity');ss[i['id']]=i
    for fam in f['families']:need(all(fam['id']+'/'+m in ss for m in ['local','persistent']),'instance pair')
    need(type(f['operations']) is list,'operations');need(equal([{k:o[k] for k in ['id','op','session','input']} for o in f['operations']],read(ROOT/'operation-manifest.json')),'immutable exact action manifest');prefixes={};accepted_inputs={};ids=set();seen={};last={};learnstate={};alignindex={};prior={};byid={}
    for o in f['operations']:
        keys(o,['id','op','session','input','expect'],'operation');need(string(o['id']) and o['id'] not in ids,'operation ID');ids.add(o['id']);byid[o['id']]=o
        inputcheck(o['op'],o['input']);e=o['expect'];need(type(e) is dict,'expect type')
        if o['session'] is None:
            need(o['op'] in ['center','normalize'],'global operation');keys(e,['kind'] if o['op']=='center' else ['kind','value'],'global expectation')
            need(e['kind']==('center' if o['op']=='center' else 'literal'),'global kind')
            if o['op']=='center':need(o['id']=='geometry/'+chr(o['input']['byte']),'center action ID')
            else:
                fam=next((x for x in f['families'] if o['id']=='normalize/'+x['id']),None);need(fam is not None,'normalize ID');need(equal(e['value'],fam['reference']['normalized']),'normalization literal');need(equal(o['input']['text'],next(x for x in design['families'] if x['id']==fam['id'])['normalizationInput']),'normalization input binding')
            continue
        sid=o['session'];need(sid in ss and o['id'].startswith(sid+'/'),'session ID binding')
        need(set(e).issubset({'kind','status','returned','learning','zero','nonzero','projectionEq','filesEq','projectionDiffersFrom','nonemptyFiles'}) and set(e)>={'kind','status','returned','learning'},'model expect fields')
        need(e['kind']=='model' and e['status'] in ['ok','invalid'] and type(e['learning']) is bool and (type(e['returned']) is bool or e['returned'] is None),'model expected types')
        for k in ['zero','nonzero','nonemptyFiles']:need(k not in e or e[k] is True,'positive oracle flag')
        for k in ['projectionEq','filesEq','projectionDiffersFrom']:
            if k in e:need(e[k] in ids and byid[e[k]]['session']==sid and e[k]!=o['id'],'backward same-session relation')
        if o['op']=='construct':
            need(sid not in seen and o['id']==sid+'/construct','constructor once');need(o['input']['persistent']==(ss[sid]['mode']=='persistent'),'constructor mode');seen[sid]=True;learnstate[sid]=True;alignindex[sid]=0;accepted_inputs[sid]=[]
            need(e.get('zero') is True and e['status']=='ok' and e['returned'] is None,'constructor zero literal')
        else:
            need(sid in seen,'use before construct')
            if o['op']=='setLearning':learnstate[sid]=o['input']['value']
            if o['op']=='reopen':need(ss[sid]['mode']=='persistent' and byid[last[sid]]['op']=='reload','settled reopen');learnstate[sid]=True
            if o['op']=='learn':
                if o['id']==sid+'/seed':
                    need(o['input']['text']=='cedar' and o['input']['target']=='cedar' and len(o['input']['taps'])==5,'nonvacuous seed');count=5;accepted=True
                else:
                    fam=next(x for x in f['families'] if x['id']==ss[sid]['family']);a=fam['reference']['alignments'][alignindex[sid]];alignindex[sid]+=1
                    source=[x for x in next(x for x in design['families'] if x['id']==fam['id'])['steps'] if x['op']=='learn'][alignindex[sid]-1]
                    need(equal(o['input'],{k:v for k,v in source.items() if k!='op'}),'learn frozen action binding')
                    taps=o['input']['taps'];orig=[];valid=len(a['targetBytes'])>=2 and len(a['targetBytes'])==len(a['typedBytes'])
                    if valid:
                        for b,origin in zip(a['targetBytes'],a['origins']):
                            if not 97<=b<=122:continue
                            p=taps[origin] if origin<len(taps) else None
                            if p is None:continue
                            if 'base' not in p and not all(number(v) for v in p.values()):valid=False;break
                            orig.append(origin)
                    expected_orig=orig if valid and orig else None
                    need(equal(expected_orig,a['contributingOrigins']),'exact structural contribution oracle')
                    count=len(orig);accepted=valid and count>0 and learnstate[sid] and (ss[sid]['mode']=='local' or count<=40)
                need(e['returned'] is accepted and e['status']==('ok' if accepted else 'invalid'),'learn policy')
                if accepted:
                    need(e.get('projectionDiffersFrom')==last[sid],'nonvacuous accepted learning');accepted_inputs[sid].append(o['input'])
                if not accepted:
                    need(e.get('projectionEq')==last[sid] and e.get('filesEq')==last[sid],'invalid conservation')
                    need(byid[last[sid]]['op'] in ['save','setLearning'],'invalid settled boundary')
            elif o['op']=='save':need(e['returned'] is True and e['status']=='ok' and e.get('projectionEq')==last[sid],'confirmed save relation')
            elif o['op']=='reload':need(e['returned'] is False and e['status']=='ok' and e.get('projectionEq')==last[sid],'unchanged successful observation')
            elif o['op']=='observe':need(e['returned'] is None and e['status']=='invalid' and e.get('projectionEq')==last[sid] and e.get('filesEq')==last[sid],'retained invalid status observation')
            elif o['op']=='setLearning':need(e['returned'] is None and e.get('projectionEq')==last[sid] and e.get('filesEq')==last[sid],'toggle state/file relation')
            elif o['op']=='reopen':need(e['returned'] is None and e['status']=='ok' and 'projectionEq' in e,'reopen relation')
        need(e['learning']==learnstate[sid],'learning value oracle');last[sid]=o['id'];prefixes[o['id']]=list(accepted_inputs[sid])
    need(set(seen)==set(ss),'constructed exact sessions')
    for sid in ss:
        fam=next(x for x in f['families'] if x['id']==ss[sid]['family']);need(alignindex[sid]==len(fam['reference']['alignments']),'all family learn actions')
    need([o['id'] for o in f['operations'][:26]]==['geometry/'+x for x in 'abcdefghijklmnopqrstuvwxyz'],'26 exact centers')
    need([o['id'] for o in f['operations'][26:44]]==['normalize/'+x['id'] for x in f['families']],'exact normalizations')
    rid=set()
    for r in f['relations']:
        keys(r,['id','left','right'],'relation');need(string(r['id']) and r['id'] not in rid and r['left'] in ids and r['right'] in ids,'relation IDs');rid.add(r['id'])
        l=byid[r['left']];rr=byid[r['right']];need(l['session'] and rr['session'] and ss[l['session']]['mode']=='persistent' and ss[rr['session']]['mode']=='local' and ss[l['session']]['family']==ss[rr['session']]['family'],'equivalence pair domain')
        need(equal(prefixes[l['id']],prefixes[rr['id']]),'same accepted calls in order for full-state equivalence')
        if l['op']=='learn':need(l['expect']['returned'] is True and rr['expect']['returned'] is True and equal(l['input'],rr['input']),'accepted same-call pair')
    expected_relations=[]
    for fam in f['families']:
        fid=fam['id'];expected_relations.append(fid+'/equivalent-seed')
        for o in f['operations']:
            if o['session']==fid+'/persistent' and o['op']=='learn' and o['id']!=fid+'/persistent/seed' and o['expect']['returned'] is True:expected_relations.append(fid+'/equivalent-'+o['id'].split('/')[-1])
        expected_relations.append(fid+'/saved-equivalence')
    need([r['id'] for r in f['relations']]==expected_relations,'complete exact relation ID coverage')
    actual={'families':len(f['families']),'instances':len(ss),'operations':len(ids),'relations':len(rid),'modelOperations':sum(o['session'] is not None for o in f['operations']),'normalizationCalls':18,'geometryCalls':26,'learnCalls':sum(o['op']=='learn' for o in f['operations']),'expectedAcceptedLearnCalls':sum(o['op']=='learn' and o['expect']['returned'] is True for o in f['operations']),'expectedRejectedLearnCalls':sum(o['op']=='learn' and o['expect']['returned'] is False for o in f['operations']),'persistentReopens':sum(o['op']=='reopen' for o in f['operations'])}
    need(equal(actual,f['denominators']),'exact intended denominators')
    return f

def point(p,label):
    keys(p,['x','y'],label);need(number(p['x']) and number(p['y']),label+' finite dimensions')
def inventory(fs):
    need(type(fs) is list and len(fs)<=128,'bounded file list');paths=[];total=0
    for f in fs:
        keys(f,['path','bytes','sha256'],'file');p=f['path'];need(string(p) and p and not p.startswith('/') and all(s not in ['','.','..'] for s in p.split('/')),'relative file path');paths.append(p)
        need(type(f['bytes']) is int and 0<=f['bytes']<=16*1024*1024,'file byte bound');total+=f['bytes'];need(string(f['sha256']) and re.fullmatch('[0-9a-f]{64}',f['sha256']) is not None,'file hash')
    need(paths==sorted(set(paths)) and total<=32*1024*1024,'sorted unique bounded inventory')
def shape(s):
    keys(s,['weight','offsets','learning'],'state');need(number(s['weight']) and s['weight']>=0 and type(s['learning']) is bool,'state scalars');need(type(s['offsets']) is list and len(s['offsets'])==26,'all26 dimensions')
    for p in s['offsets']:point(p,'offset')
def close(a,b,tol):return abs(a-b)<=tol
def projectioneq(a,b,tol):return close(a['weight'],b['weight'],tol) and all(close(p[k],q[k],tol) for p,q in zip(a['offsets'],b['offsets']) for k in ['x','y'])
def statevalid(s,tol):return s['weight']>=0 and all(abs(p[k])<=.4+tol for p in s['offsets'] for k in ['x','y'])
def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def evaluate(rawpath):
    f=preflight();raw=read(rawpath);keys(raw,['format','environment','operations'],'raw');need(raw['format']=='pulpo-r48-raw-v1','raw format')
    env=raw['environment'];keys(env,['compiler','runtime','architecture','productSourceSHA256','runnerSHA256','fixturesSHA256','versionLabel'],'environment')
    need(all(string(v) and v for v in env.values()),'environment strings');need(env['architecture']=='arm64' and 'swiftlang-6.4.0.34.1' in env['compiler'],'approved runtime/compiler binding')
    need('27.0.1' in env['runtime'] and '26A434' in env['runtime'],'approved OS binding')
    for k in ['productSourceSHA256','runnerSHA256','fixturesSHA256']:need(re.fullmatch('[0-9a-f]{64}',env[k]) is not None,'environment hash')
    need(env['runnerSHA256']==hashfile(ROOT/'Runner.swift') and env['fixturesSHA256']==hashfile(ROOT/'fixtures.json'),'execution artifact hashes')
    need(type(raw['operations']) is list and len(raw['operations'])==len(f['operations']),'exact record count')
    recs={};centers={};urls={};evidenceids=set();tol=f['tolerance'];checks=[];unavailable=[];unexpected=[]
    def score(i,ok):checks.append({'id':i,'pass':bool(ok)})
    for r,o in zip(raw['operations'],f['operations']):
        keys(r,['id','op','session','input','resolvedInput','returned','status','state','files','available','invoked','error'],'record')
        for k in ['id','op','session','input']:need(equal(r[k],o[k]),'exact record/action binding '+o['id']+'/'+k)
        need(type(r['available']) is bool and type(r['invoked']) is bool,'availability/invocation boolean');need(not r['available'] or r['invoked'],'available operation must execute');need(r['error'] is None if r['available'] else string(r['error']) and bool(r['error']),'error availability distinction')
        inventory(r['files']);need(r['files']==[] if o['session'] and o['session'].endswith('/local') else True,'nil-URL inventory');recs[r['id']]=r
        if not r['available']:
            need(r['status'] is None or (string(r['status']) and r['status'] in ['ok','invalid','busy','capacity','io','uncertain','cleanup']),'unavailable status shape')
            if r['state'] is not None:shape(r['state'])
            need(r['resolvedInput'] is None or o['op'] in ['learn','construct','reopen'],'unavailable resolved input op')
            if r['resolvedInput'] is not None and o['op'] in ['construct','reopen']:
                keys(r['resolvedInput'],['url'],'unavailable constructor input');need(r['resolvedInput']['url'] is None or string(r['resolvedInput']['url']),'unavailable url type')
            if r['resolvedInput'] is not None and o['op']=='learn':
                keys(r['resolvedInput'],['text','target','taps'],'unavailable resolved learn')
                need(string(r['resolvedInput']['text']) and string(r['resolvedInput']['target']) and type(r['resolvedInput']['taps']) is list,'unavailable resolved types')
                for p in r['resolvedInput']['taps']:
                    if p is not None:
                        keys(p,['x','y'],'unavailable resolved point')
                        for v in p.values():need(number(v) or (string(v) and v in ['nan','posInf','negInf']),'unavailable resolved number')
            if r['returned'] is not None:
                if o['op']=='center':point(r['returned'],'unavailable center')
                elif o['op']=='normalize':need(string(r['returned']),'unavailable normalized value')
                else:need(o['op'] in ['learn','save','reload'] and type(r['returned']) is bool,'unavailable return type')
            unavailable.append(r['id'])
            for n in names(o):score(o['id']+'/'+n,False)
            continue
        e=o['expect']
        if o['session'] is None:
            score(o['id']+'/available',True)
            need(r['state'] is None and r['status'] is None and r['files']==[] and r['resolvedInput'] is None,'global observation envelope')
            if o['op']=='center':
                point(r['returned'],'geometry center');centers[chr(o['input']['byte'])]=r['returned'];score(o['id']+'/finite-center',True)
            else:need(string(r['returned']),'normalized string');score(o['id']+'/literal',equal(r['returned'],e['value']))
            continue
        need(string(r['status']) and r['status'] in ['ok','invalid','busy','capacity','io','uncertain','cleanup'],'operation status enum');shape(r['state'])
        if r['status']!=e['status']:unexpected.append(r['id'])
        need(type(r['returned']) is bool if o['op'] in ['learn','save','reload'] else r['returned'] is None,'operation return type')
        if o['op']=='learn':
            ri=r['resolvedInput'];keys(ri,['text','target','taps'],'resolved learn');need(equal(ri['text'],o['input']['text']) and equal(ri['target'],o['input']['target']) and type(ri['taps']) is list and len(ri['taps'])==len(o['input']['taps']),'resolved learn binding')
            for actual,spec in zip(ri['taps'],o['input']['taps']):
                if spec is None:need(actual is None,'resolved nil point');continue
                keys(actual,['x','y'],'resolved point')
                if 'base' in spec:
                    need(spec['base'] in centers,'available center prerequisite');expected={k:centers[spec['base']][k]+spec['d'+k] for k in ['x','y']}
                else:expected=spec
                for k in ['x','y']:
                    v=expected[k];need((number(actual[k]) and close(actual[k],v,tol)) if number(v) else equal(actual[k],v),'resolved exact point/tags')
        elif o['op'] in ['construct','reopen']:
            ri=r['resolvedInput'];keys(ri,['url'],'resolved constructor URL');u=ri['url']
            if o['op']=='construct':
                if o['input']['persistent']:
                    need(string(u) and u.startswith('/') and u.endswith('/TouchModel.json') and len(u)<=4096 and all(x not in ['.','..',''] for x in u.split('/')[1:]),'canonical persistent URL shape');need(u not in urls.values(),'unique session URL')
                else:need(u is None,'nil local URL')
                urls[o['session']]=u
            else:need(o['session'] in urls and equal(u,urls[o['session']]),'same URL reopen')
        else:need(r['resolvedInput'] is None,'nonlearn resolved null')
        evidence=r['status'] in ['ok','invalid'] and not (o['op'] in ['construct','reopen','reload','save'] and r['status']!='ok') and not (o['op']=='save' and r['returned'] is not True)
        if not evidence:
            unavailable.append(r['id'])
            for n in names(o):score(o['id']+'/'+n,False)
            continue
        evidenceids.add(r['id']);score(o['id']+'/available',True)
        score(o['id']+'/status',r['status']==e['status']);score(o['id']+'/return',equal(r['returned'],e['returned']));score(o['id']+'/learning',r['state']['learning']==e['learning']);score(o['id']+'/state-shape-finite-bounds',statevalid(r['state'],tol))
        for k in ['zero','nonzero','projectionEq','filesEq','projectionDiffersFrom','nonemptyFiles']:
            if k not in e:continue
            s=r['state']
            if k=='zero':ok=s['weight']==0 and all(p[c]==0 for p in s['offsets'] for c in ['x','y'])
            elif k=='nonemptyFiles':ok=any(x['bytes']>0 for x in r['files'])
            elif k=='nonzero':ok=s['weight']>0 and any(abs(p[c])>tol for p in s['offsets'] for c in ['x','y'])
            else:
                ref=recs[e[k]];ok=e[k] in evidenceids and (equal(r['files'],ref['files']) if k=='filesEq' else (projectioneq(s,ref['state'],tol) if k=='projectionEq' else not projectioneq(s,ref['state'],tol)))
            score(o['id']+'/'+k,ok)
    for rel in f['relations']:
        l=recs[rel['left']];r=recs[rel['right']];score('relation/'+rel['id'],rel['left'] in evidenceids and rel['right'] in evidenceids and l['state'] is not None and r['state'] is not None and projectioneq(l['state'],r['state'],tol))
    intended=sum(len(names(o)) for o in f['operations'])+len(f['relations']);need(len(checks)==intended,'complete check accounting')
    family_results=[]
    for family in f['families']:
        fid=family['id'];related=[c for c in checks if c['id'].startswith((fid+'/', 'normalize/'+fid+'/', 'relation/'+fid+'/'))];need(bool(related),'nonvacuous family checks');family_results.append({'id':fid,'pass':all(c['pass'] for c in related),'checks':len(related)})
    actual_accounting={'executedActions':sum(r['invoked'] for r in raw['operations']),'unexecutedActions':sum(not r['invoked'] for r in raw['operations']),'actualLearnInvocations':sum(r['invoked'] and r['op']=='learn' for r in raw['operations']),'observedAcceptedLearnCalls':sum(r['invoked'] and r['op']=='learn' and r['returned'] is True and r['status']=='ok' for r in raw['operations']),'observedExpectedInvalidRejections':sum(r['invoked'] and r['op']=='learn' and r['returned'] is False and r['status']=='invalid' and o['expect']['returned'] is False for r,o in zip(raw['operations'],f['operations'])),'unavailableActions':len(unavailable),'unexpectedStatuses':len(unexpected)}
    return {'actualAccounting':actual_accounting,'format':'pulpo-r48-evaluation-v1','versionLabel':env['versionLabel'],'denominators':dict(f['denominators'],individualChecks=intended),'passedChecks':sum(c['pass'] for c in checks),'failedCheckIDs':[c['id'] for c in checks if not c['pass']],'passedFamilies':sum(x['pass'] for x in family_results),'familyResults':family_results,'unavailableCallIDs':unavailable,'unexpectedStatusCallIDs':unexpected,'pass':all(c['pass'] for c in checks)}
def main():
    a=argparse.ArgumentParser();a.add_argument('raw',nargs='?');a.add_argument('--preflight',action='store_true');args=a.parse_args()
    try:
        if args.preflight:
            f=preflight();result={'preflight':'pass','denominators':dict(f['denominators'],individualChecks=sum(len(names(o)) for o in f['operations'])+len(f['relations']))}
        else:need(args.raw is not None,'raw path required');result=evaluate(args.raw)
        print(json.dumps(result,sort_keys=True,indent=2));return 0 if result.get('pass',True) else 1
    except (Invalid,KeyError,TypeError,ValueError,IndexError,StopIteration,OSError) as e:
        print(json.dumps({'pass':False,'validationError':str(e)},sort_keys=True));return 2
if __name__=='__main__':sys.exit(main())
