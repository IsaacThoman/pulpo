import collections,copy,hashlib,importlib.util,json,pathlib,subprocess,sys
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/tmp/pulpo-r48-paired-final-v2');B=R/'author/author-review-v2';freeze=pathlib.Path('/Users/isaacthoman/.t3/worktrees/pulpo/t3-a3218df3/apps/keyboard-ios/audits/reset-integration-r48/execution-freeze-v2.json')
def need(x,m):
 if not x:raise RuntimeError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
need(sha(freeze)=='b89f52ecce3cefd535fc799e6f44a16651eddcc9b6cbaa474bd33eb17217d7b8','freeze hash')
s=importlib.util.spec_from_file_location('frozen_evaluator',B/'evaluate.py');E=importlib.util.module_from_spec(s);s.loader.exec_module(E);F=E.preflight();A=E.read(B/'accounting.json');intended=A['intendedCheckIDs'];need(len(set(intended))==len(intended)==2285,'intended IDs');runs=E.read(R/'execution.json');binding={x['name']:x for x in runs};results={}
for label in ['original-a9e','integrated-82165']:
 d=R/label;raw=E.read(d/'raw.json');previous=E.read(d/'evaluation-normal.json');env=E.read(d/'environment.json');need(sha(d/'raw.json')==binding[label]['rawSHA256'],'raw execution binding');need(binding[label]['productAttempts']==1 and binding[label]['exit']==0,'single attempt receipt');need(raw['environment']['productSourceSHA256']==env['productSourceSHA256'],'source env binding')
 captured=[]
 def trace(frame,event,arg):
  if frame.f_code is not E.evaluate.__code__:return None
  frame.f_trace_lines=False
  if event=='return' and 'checks' in frame.f_locals:captured.extend(copy.deepcopy(frame.f_locals['checks']))
  return trace
 sys.settrace(trace)
 try:ev=E.evaluate(d/'raw.json')
 finally:sys.settrace(None)
 need(ev==previous,'normal archived evaluation exact reconstruction');need([x['id'] for x in captured]==intended,'every intended actual check row');need(ev['failedCheckIDs']==[x['id'] for x in captured if not x['pass']],'all failed rows retained');need(len(captured)==2285 and sum(x['pass'] for x in captured)==ev['passedChecks'],'full check count')
 (P/(label+'-evaluation-reconstructed.json')).write_text(json.dumps(ev,indent=2)+'\n');(P/(label+'-all-check-rows.json')).write_text(json.dumps(captured,indent=2)+'\n')
 p=subprocess.run([sys.executable,'-O',str(B/'evaluate.py'),str(d/'raw.json')],capture_output=True,text=True);(P/(label+'-evaluation-optimized.json')).write_text(p.stdout);(P/(label+'-evaluation-optimized.stderr')).write_text(p.stderr);need(p.returncode==1,'optimized frozen failure exit');need(json.loads(p.stdout)==ev,'optimized identical frozen score')
 # Independently compute actual accounting rather than trusting evaluator summaries.
 fops={o['id']:o for o in F['operations']};recs={o['id']:o for o in raw['operations']}
 independent={'executedActions':sum(r['invoked'] is True for r in raw['operations']),'unexecutedActions':sum(r['invoked'] is False for r in raw['operations']),'actualLearnInvocations':sum(r['invoked'] is True and r['op']=='learn' for r in raw['operations']),'observedAcceptedLearnCalls':sum(r['available'] and r['invoked'] and r['op']=='learn' and r['returned'] is True and r['status']=='ok' for r in raw['operations']),'observedExpectedInvalidRejections':sum(r['available'] and r['invoked'] and r['op']=='learn' and r['returned'] is False and r['status']=='invalid' and fops[r['id']]['expect']['returned'] is False for r in raw['operations']),'unavailableActions':sum(not r['available'] for r in raw['operations']),'unexpectedStatuses':sum(r['invoked'] and r['session'] is not None and r['status'] is not None and r['status']!=fops[r['id']]['expect']['status'] for r in raw['operations'])}
 need(independent==ev['actualAccounting'],'independent actual accounting')
 opcounts=[]
 for op in A['operationCounts']:
  rows=[r for r in raw['operations'] if r['op']==op];opcounts.append({'op':op,'intended':A['operationCounts'][op],'invoked':sum(r['invoked'] for r in rows),'available':sum(r['available'] for r in rows),'unavailable':sum(not r['available'] for r in rows),'uninvoked':sum(not r['invoked'] for r in rows)})
 instances=[]
 for inst in F['instances']:
  rows=[r for r in raw['operations'] if r['session']==inst['id']];checks=[x for x in captured if x['id'].startswith(inst['id']+'/')];unavail=[r for r in rows if not r['available']];first=unavail[0] if unavail else None
  instances.append(dict(inst,intendedActions=len(rows),invokedActions=sum(r['invoked'] for r in rows),availableActions=sum(r['available'] for r in rows),uninvokedActions=sum(not r['invoked'] for r in rows),allActionEvidenceAvailable=not unavail,passedChecks=sum(x['pass'] for x in checks),failedCheckIDs=[x['id'] for x in checks if not x['pass']],intendedChecks=len(checks),instanceActionChecksPass=all(x['pass'] for x in checks),firstUnavailable=None if first is None else {k:first[k] for k in ['id','op','invoked','available','status','error','resolvedInput']},maxErrorCharacters=max([len(r['error']) for r in rows if r['error']]+[0])))
 # Preserve one explicit row attribution for each of all 2285 checks, including failures.
 attribution=[]
 for x in captured:
  id=x['id']
  if id.startswith('relation/'):
   rel=next(v for v in F['relations'] if 'relation/'+v['id']==id);classification='relation_unavailable_persistent_evidence' if not recs[rel['left']]['available'] or not recs[rel['right']]['available'] else 'observed_projection_relation'
  else:
   # Longest matching operation ID avoids prefix ambiguity from /save and /observe.
   opid=max((k for k in recs if id.startswith(k+'/')),key=len);r=recs[opid]
   classification=('persistent_inventory_failure_at_constructor' if r['invoked'] else 'persistent_cascade_uninvoked') if not r['available'] else ('observed_local_or_global_pass' if x['pass'] else 'observed_local_behavior_failure')
  attribution.append(dict(x,classification=classification))
 need(len(attribution)==2285,'complete attribution');failed_groups=collections.Counter(x['classification'] for x in attribution if not x['pass']);all_groups=collections.Counter(x['classification'] for x in attribution)
 (P/(label+'-check-attribution.json')).write_text(json.dumps(attribution,indent=2)+'\n')
 (P/(label+'-instance-accounting.json')).write_text(json.dumps(instances,indent=2)+'\n')
 family=[]
 for fam in F['families']:
  fid=fam['id'];rows=[r for r in raw['operations'] if r['session'] is not None and r['session'].startswith(fid+'/')];checks=[x for x in captured if x['id'].startswith((fid+'/', 'normalize/'+fid+'/', 'relation/'+fid+'/'))];family.append({'id':fid,'intendedActions':len(rows),'availableActions':sum(r['available'] for r in rows),'invokedActions':sum(r['invoked'] for r in rows),'persistentActionEvidenceAvailable':all(r['available'] for r in rows if r['session'].endswith('/persistent')),'intendedChecks':len(checks),'passedChecks':sum(x['pass'] for x in checks),'failedChecks':sum(not x['pass'] for x in checks),'frozenFamilyPass':all(x['pass'] for x in checks)})
 (P/(label+'-family-accounting.json')).write_text(json.dumps(family,indent=2)+'\n')
 results[label]={'actualAccounting':independent,'operationCounts':opcounts,'passedChecks':ev['passedChecks'],'failedChecks':len(ev['failedCheckIDs']),'frozenPassedFamilies':ev['passedFamilies'],'intendedFamilies':18,'intendedInstances':36,'availableLocalInstances':sum(x['mode']=='local' and x['allActionEvidenceAvailable'] for x in instances),'completeLocalInstanceActionCheckPasses':sum(x['mode']=='local' and x['instanceActionChecksPass'] for x in instances),'availablePersistentInstances':sum(x['mode']=='persistent' and x['allActionEvidenceAvailable'] for x in instances),'persistentConstructorInvokedInventoryFailures':sum(x['mode']=='persistent' and x['firstUnavailable']['op']=='construct' and x['firstUnavailable']['invoked'] and x['firstUnavailable']['status']=='ok' and x['firstUnavailable']['error']=='invalid("inventory escape")' for x in instances),'allCheckAttributionCounts':dict(all_groups),'failedCheckAttributionCounts':dict(failed_groups),'maxErrorCharacters':max(x['maxErrorCharacters'] for x in instances),'optimizedEvaluationExit':p.returncode,'normalOptimizedAndArchivedEvaluationsIdentical':True,'sourceSHA256':env['productSourceSHA256'],'rawSHA256':sha(d/'raw.json'),'archivedEvaluationSHA256':sha(d/'evaluation-normal.json')}
left=E.read(R/'original-a9e/evaluation-normal.json');right=E.read(R/'integrated-82165/evaluation-normal.json');lf=set(left['failedCheckIDs']);rf=set(right['failedCheckIDs']);delta={'repairedCheckIDs':sorted(lf-rf),'newFailedCheckIDs':sorted(rf-lf),'commonFailedCheckIDs':[x for x in left['failedCheckIDs'] if x in rf],'deltaPassedChecks':right['passedChecks']-left['passedChecks']}
(P/'exact-check-delta.json').write_text(json.dumps(delta,indent=2)+'\n');(P/'accounting-summary.json').write_text(json.dumps({'format':'pulpo-r48-independent-outcome-accounting-v1','intendedDenominators':A['denominators'],'results':results,'delta':{k:v for k,v in delta.items() if k!='commonFailedCheckIDs'},'all2285ChecksActuallyReevaluated':True,'productExecutionsDuringAudit':0},indent=2)+'\n')
print(json.dumps({'results':results,'delta':{k:v for k,v in delta.items() if k!='commonFailedCheckIDs'}},indent=2))
