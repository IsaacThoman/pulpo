from pathlib import Path
import json,copy,hashlib
D=Path('/tmp/pulpo-r49-fresh-validator-v2');A=Path('/tmp/pulpo-r49-fresh-author-v2')
ns={};source=(D/'independent-counterchecks.py').read_text().split('results=[];raw_archive=')[0];exec(compile(source,'reviewer-counter-reference','exec'),ns)
truth=ns['truth'];validate=ns['validate'];need=ns['need'];base=ns['base'];cases=json.loads((A/'accounting-witnesses.json').read_text());reports=json.loads((D/'replay/accounting-results.json').read_text())['results'];frozen=json.loads((A/'accounting-countertruth.json').read_text())['cases'];results=[]
for c in cases:
 value=copy.deepcopy(base)
 for p in c['patches']:
  t=value
  for k in p['path'][:-1]:t=t[k]
  k=p['path'][-1]
  if p['action']=='set':t[k]=copy.deepcopy(p['value'])
  elif p['action']=='delete':del t[k]
  elif p['action']=='append':t[k].append(copy.deepcopy(p['value']))
  else:raise RuntimeError('patch')
 expected=truth(value,c['expected_exit']);subset={k:expected[k] for k in ('known','observed','unknown_operation_ids')}
 for k,v in subset.items():need(frozen[c['id']][k]==v,c['id']+' frozen countertruth differs')
 selected=[r for r in reports if r['id']==c['id']];need(len(selected)==2,c['id']+' modes')
 for r in selected:validate(r['report'],expected)
 results.append({'id':c['id'],'expected_exit':c['expected_exit'],'full_observed_ids_counts_ledgers_match_independent_inventory':True,'normal_and_optimized':True})
# Confirm reproductions and immutable author files after every supplied run.
for name in ['adversarial-results.json','accounting-results.json','report-schema-results.json','v2-preservation-proof.json']:
 need((D/'replay'/name).read_bytes()==(A/name).read_bytes(),'reproduction drift '+name)
manifest=json.loads((A/'author-manifest.json').read_text())
for n,h in manifest['files'].items():need(hashlib.sha256((A/n).read_bytes()).hexdigest()==h,'author mutation '+n)
(D/'supplied-countertruth-review.json').write_text(json.dumps({'result':'pass','cases':len(cases),'reports':len(reports),'results':results,'all_reproduced_reports_byte_identical':True,'author_files_unchanged':True},indent=2)+'\n');print(json.dumps({'result':'pass','independent_countertruth_cases':len(cases),'reports':len(reports),'all_reproduced_bytes_match':True}))
