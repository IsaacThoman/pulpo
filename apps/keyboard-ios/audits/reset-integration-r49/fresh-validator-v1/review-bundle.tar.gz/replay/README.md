# R49 fresh public TouchModel author bundle

This is an independently authored, source/output-blind compatibility workload.
The sole product-facing action binding is the separately approved, unchanged
`Runner.swift`. No product source, dictionaries, prior payloads or product output
were read and no product/API/binary/device/build was executed by this author.
The only executed Swift program was the Foundation-only public reference.

The archive and `author-manifest.json` seal literal actions, expected observations,
relations, schemas, evaluator, synthetic tests, references and this execution map.
`metadata.json` is an external sidecar containing the archive hash, avoiding a
self-referential archive digest. The compiled Foundation reference utility is an
unsealed convenience artifact excluded from the archive; its reproducible source
and the exact reference JSON are sealed. Do not change or reseal this round after
review/reveal. Review findings require preserving the failed round and authoring
another independently fresh round.

## Files and review order

1. `metadata.json` exposes counts, paths and hashes without the fresh payload.
2. Independent reviewers inspect `schema.json`, `fixtures-schema.json`,
   `evaluate.py`, `reference-assumptions.md` and the approved unchanged runner.
3. Independent semantic reviewers inspect `fixtures.json`, `expectations.json`,
   `reference-requests.json`, `reference.json`, `verify_author.py` and its report.
   Every check is frozen before product execution. The parent keeps fresh payloads
   unopened until semantic/evaluator review permits the final freeze.
4. `adversarial-cases.json` is an explicit mutation program over
   `synthetic-raw.json`. `test_evaluator.py` materializes every adversarial input,
   records its SHA256 and reports under ordinary and optimized Python in
   `adversarial-results.json`. These are fabricated validator tests, never product
   evidence. No sample estimator in the synthetic generator is an oracle.
5. The parent checks exact duplicate *programs* against earlier revealed inputs.
   Any exposed repeats must be reported; spelling changes alone do not establish
   independent accuracy or a new model resource mode.

## Reproduce preexecution author validation

Use this exact Swift runtime: Apple Swift 6.4 (swiftlang-6.4.0.34.1), arm64,
macOS 27.0.1 build 26A434. `runtime-binding.json` records the author toolchain.
Do not substitute Python Unicode, NSString lowercase or full case folding.

In a writable review copy of the sealed archive, run:

```sh
swiftc PublicDomainReference.swift ReferenceMain.swift -o reference-tool
./reference-tool reference-requests.json /tmp/review-reference.json
cmp reference.json /tmp/review-reference.json
python3 verify_author.py
python3 -O verify_author.py
python3 test_evaluator.py
```

`verify_author.py` checks every acceptance against the approved public reference,
actual contributing samples, explicit policy and persistent/local caps. It also
symbolically verifies every declared state relation from independently determined
ordered target-byte/tap streams. Its equality checks do not implement or assume
the product's learning formula. The structural report has only counts/runtime.

The author generated literal declarations using `author.py`, the public reference
using `ReferenceMain.swift`, schemas using `make_schema.py`, and fabricated
validator data using `make_synthetic.py` and `make_adversaries.py`.
`seal_manifest.py` is provenance for the original author seal, not permission to
modify or reseal any reviewed/revealed artifact. Do not run it in execution.

## Final parent freeze and one paired execution

There is no additional product/native prerequisite imposed by this bundle.
The generic runner mechanics were separately approved before authoring.

Before any fresh product invocation, the independent executor freezes:

- This exact archive/manifest, runner, public domain and protocol hashes.
- Both already compiled comparison/candidate binaries, complete source tree
  manifests/differences, compiler/OS/architecture and all runtime/environment
  bytes. Whole-tree differences remain an explicit attribution limitation.
- Semantic/evaluator approvals and each exact environment JSON file.

Create one environment JSON per variant from `environment-template.json`, outside
this immutable bundle. Replace every `execution` placeholder with the actual
frozen variant, binary SHA256, source-manifest SHA256, approval SHA256, compiler
and platform. Preserve the fixed round/fixture/runner binding. The runner adds
`runtime`; the evaluator requires the approved Foundation runtime exactly.
The evaluator validates the execution envelope shape and hash syntax. The parent
must independently verify those claimed hashes against the final frozen binaries,
sources and approvals; unknown future binary bytes cannot be preattested by this
author. The synthetic environment is explicitly fictitious and must never be
used for product evidence.

Compile/run the unchanged runner using the environment's independently approved
public KeyboardCore module/library linkage. The bundle does not choose product
source paths, package targets or linker flags. The executable invocation is:

```sh
/path/to/frozen-comparison-runner fixtures.json /path/to/comparison-raw.json /path/to/comparison-environment.json
/path/to/frozen-candidate-runner fixtures.json /path/to/candidate-raw.json /path/to/candidate-environment.json
python3 evaluate.py /path/to/comparison-raw.json
python3 evaluate.py /path/to/candidate-raw.json
```

Exactly one invocation per frozen binary/environment/input tuple is admitted.
No automatic mutation retries, background saving or concurrent workloads occur.
Retain both complete raw outputs, exit codes, reports and fresh storage, including
failed, unavailable or unfired actions. No post-reveal input/oracle/runner/source
repairs or reruns can admit this round. Evaluator exit codes are 0 complete pass,
1 well-formed behavioral/unavailability failure, and 2 strict malformed or
binding-invalid data. A completed transport is never a workload pass by itself.

All evaluator reports retain the complete operation/check denominators. An
unavailable record is not removed or converted to an expected invalid control.
Failed constructors/reopens/reloads cannot establish durable evidence. Invalid
learn status may coexist with a valid retained in-memory projection. Persistent
reload false/ok is accepted as successful unchanged evidence.

## Scope and correlated counts

The 15 families contain 45 instances: one local, one persistent and one local
canonical control per family. All controls within a family are correlated. The
normalization checks are separately enumerated public-string observations,
not language-model resource modes. Operation/check counts are coverage counts,
not independent population samples. Check count is one aggregate observation
check per ordered operation plus each declared enforced relation; it does not
count every numeric component as another independent check.

This workload addresses the declared public TouchModel compatibility domain.
It does not establish EN/ES/BI population accuracy, candidate ranking, native iOS
UX/latency, accessibility speech, inaccessible-store erasure, whole shared reset,
durability beyond these actions or superiority over another keyboard.
