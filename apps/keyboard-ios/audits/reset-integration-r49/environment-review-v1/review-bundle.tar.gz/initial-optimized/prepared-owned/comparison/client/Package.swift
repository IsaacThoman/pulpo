// swift-tools-version: 6.2
import PackageDescription
let package = Package(name: "BoundaryClient", platforms: [.macOS(.v15)], dependencies: [.package(path: "/private/tmp/pulpo-r49-environment-review-v1/optimized/prepared-owned/comparison/PulpoKeyboardKit")], targets: [.executableTarget(name: "BoundaryRunner", dependencies: [.product(name: "KeyboardCore", package: "PulpoKeyboardKit")])])
