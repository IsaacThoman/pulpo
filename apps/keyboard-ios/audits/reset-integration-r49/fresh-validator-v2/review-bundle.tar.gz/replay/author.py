from pathlib import Path
import json
D=Path(__file__).resolve().parent

def dump(name,v): (D/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def p(k,x=.073,y=-.041):return {'base':k,'dx':x,'dy':y}
def nf(x='nan',y=0):return {'x':x,'y':y}
def call(text,target,taps):return {'text':text,'target':target,'taps':taps}
A='abcdefghijklmnopqrstuvwxyz'
# Independently authored literal actions; no product imports, executions or answers.
families=[
('target_geometry',call('map','sun',[p('s'),p('u'),p('n')]),call('sun','sun',[p('s'),p('u'),p('n')]),[]),
('missing_sparse',call('rivet','rivet',[p('r'),None,p('v',-.058,.091)]),call('rivet','rivet',[p('r'),None,p('v',-.058,.091),None,None]),[]),
('ligature_expansion',call('ﬃt','ffit',[p('f'),p('t')]),call('ffit','ffit',[p('f'),p('f'),p('f'),p('t')]),[]),
('removed_apostrophe',call('a’b','ab',[p('a'),nf(),p('b')]),call('ab','ab',[p('a'),p('b')]),[]),
('grapheme_marks',call('o\u0308p','op',[p('o'),p('p')]),call('op','op',[p('o'),p('p')]),[]),
('ignored_nonletters',call('u7v?','u7v?',[p('u'),nf(),p('v'),nf('negInf')]),call('u7v?','u7v?',[p('u'),None,p('v'),None]),[]),
('utf8_origin_duplication',call('øa','bca',[p('b'),p('a')]),call('bca','bca',[p('b'),p('b'),p('a')]),[]),
('compatibility_uppercase',call('ᴬz','ᴬz',[nf('posInf'),p('z')]),call('7z','7z',[None,p('z')]),[]),
('extra_taps',call('dew','dew',[p('d'),p('e'),p('w'),nf(),nf('posInf')]),call('dew','dew',[p('d'),p('e'),p('w')]),[]),
('learning_policy',call('hex','hex',[p('h'),p('e'),p('x')]),call('hex','hex',[p('h'),p('e'),p('x')]),[('off',call('orb','orb',[p('o'),p('r'),p('b')]))]),
('transactional_invalid',call('jog','jog',[p('j'),p('o'),p('g')]),call('jog','jog',[p('j'),p('o'),p('g')]),[('on',call('jog','jog',[p('j'),p('o'),nf('nan')])),('on',call('jog','jog',[p('j'),nf('negInf'),p('g')])),('on',call('jog','jog',[nf('posInf'),p('o'),p('g')]))]),
('length_and_no_samples',call('kit','kit',[p('k'),p('i'),p('t')]),call('kit','kit',[p('k'),p('i'),p('t')]),[('on',call('x','ab',[p('a')])),('on',call('a','a',[p('a')])),('on',call("''","''",[nf(),nf()])),('on',call('no','no',[None,None])),('on',call('!?','!?',[nf(),nf()]))]),
('actual_sample_boundary',call('q'*40,'q'*40,[p('q')]*40),call('q'*40,'q'*40,[p('q')]*40),[]),
('long_sparse_target',call('g'+'.'*81+'h','g'+'.'*81+'h',[p('g')]+[nf()]*81+[p('h')]),call('gh','gh',[p('g'),p('h')]),[]),
('complete_alphabet',call(A,A,[p(k,.025+i*.001,.037+i*.001) for i,k in enumerate(A)]),call(A,A,[p(k,.025+i*.001,.037+i*.001) for i,k in enumerate(A)]),[])
]
ops=[]; exp={}; rel=[]; sessions=[]; family_rows=[]; states={}; policy={}; status={}
def emit(id,op,input,s=None,ret=None,sts=None,zero=False):
 row={'id':id,'op':op,'input':input}
 if s:row['session']=s
 ops.append(row)
 e={'returned':ret,'status':sts,'learning':policy.get(s),'zero':zero}
 if s:e['persistent']=states[s]
 exp[id]=e
 return id

def equal(a,b,files=False,why=''):
 rel.append({'kind':'equal','left':a,'right':b,'files':files,'reason':why})
def changed(a,b,why=''):
 rel.append({'kind':'changed','left':a,'right':b,'reason':why})
def learn(s,label,c,accepted):
 id=s+'.'+label; prev=s+'.latest'; pre=last[s]
 status[s]='ok' if accepted else 'invalid'
 emit(id,'learn',c,s,accepted,status[s]);last[s]=id
 if accepted:changed(pre,id,'Accepted nonzero calibration must alter the settled projection')
 else:equal(pre,id,True,'Intentional rejection after settlement preserves state and bounded regular-file inventory')
 return id
last={}
for k in A:emit('center.'+k,'center',{'byte':ord(k)},ret='point')
norms=["D'R_8\x00\n",'ᴬz','Az','ΟςΣ','ﬃt','o\u0308p','a’b','øa','A\u0903B','x\u20ddy','\u200dx','\uff26\uff2f\uff32\uff2d','\u2121a','\u2167x']
for i,t in enumerate(norms):emit('normalize.%02d'%i,'normalize',{'text':t},ret='reference')
for family,primary,canonical,invalids in families:
 slots={}
 for mode in ['local','persistent','canonical']:
  s=family+'.'+mode; persistent=mode=='persistent'; states[s]=persistent;policy[s]=None;status[s]='ok';sessions.append({'id':s,'persistent':persistent,'family':family,'role':mode})
  first=emit(s+'.construct','construct',{'persistent':persistent},s,sts='ok',zero=True);last[s]=first
  emit(s+'.on','setLearning',{'value':True},s,sts='ok');policy[s]=True;exp[s+'.on']['learning']=True;last[s]=s+'.on'
  base=learn(s,'seed',canonical if mode=='canonical' else primary,True)
  seed=emit(s+'.settle','save',{},s,True,'ok');last[s]=seed
  equal(base,seed,False,'Synchronous save retains calibration');slots[mode]={'seed':seed}
  for j,(pol,c) in enumerate(invalids):
   if pol=='off':
    policy[s]=False;emit(s+'.off'+str(j),'setLearning',{'value':False},s,sts=status[s]);last[s]=s+'.off'+str(j)
   invalid=learn(s,'invalid'+str(j),c,False)
   observed=emit(s+'.retained'+str(j),'observe',{},s,sts='invalid');equal(invalid,observed,True,'Last invalid status is diagnostic; settled retained projection remains valid');last[s]=observed
   status[s]='ok';settled=emit(s+'.resettle'+str(j),'save',{},s,True,'ok');equal(observed,settled,False,'Saving retained state confirms settlement');last[s]=settled
   if pol=='off':
    policy[s]=True;emit(s+'.on_again'+str(j),'setLearning',{'value':True},s,sts='ok');last[s]=s+'.on_again'+str(j)
  if family=='actual_sample_boundary':
   boundary=call('q'*41,'q'*41,[p('q')]*41)
   learn(s,'forty_one',boundary,mode!='persistent')
   status[s]='ok';settled=emit(s+'.boundary_settle','save',{},s,True,'ok');last[s]=settled
  if family=='learning_policy':
   # Reopen policy is never inferred from construction. Explicitly off first.
   reopened=emit(s+'.policy_reopen','reopen',{},s,sts='ok',zero=not persistent);policy[s]=None;exp[reopened]['learning']=None;last[s]=reopened
   if persistent:equal(seed,reopened,False,'Successful reopen supplies durable evidence')
   else:rel.append({'kind':'zero','record':reopened,'reason':'Nil URL reopen constructs an empty new local model'})
   policy[s]=False;off=emit(s+'.reopened_off','setLearning',{'value':False},s,sts='ok');last[s]=off
   learn(s,'reopened_rejection',call('orb','orb',[p('o'),p('r'),p('b')]),False)
   status[s]='ok';settled=emit(s+'.reopened_settle','save',{},s,True,'ok');last[s]=settled
   policy[s]=True;emit(s+'.reopened_on','setLearning',{'value':True},s,sts='ok');last[s]=s+'.reopened_on'
   if not persistent:
    learn(s,'restore_seed',canonical if mode=='canonical' else primary,True)
    emit(s+'.restore_settle','save',{},s,True,'ok');last[s]=s+'.restore_settle'
  finish=emit(s+'.final','observe',{},s,sts='ok');last[s]=finish;slots[mode]['final']=finish
  rel.append({'kind':'positive','record':finish,'reason':'Every final comparison is anchored by accepted nonzero samples'})
  if family=='complete_alphabet':rel.append({'kind':'all_keys_nonzero','record':finish,'reason':'Each ASCII key has a finite nonzero accepted control'})
  if persistent:
   before=finish;policy[s]=None
   reopened=emit(s+'.durable','reopen',{},s,sts='ok');equal(before,reopened,False,'Only successful constructor/reopen establishes durable projection');last[s]=reopened
   policy[s]=True;emit(s+'.durable_on','setLearning',{'value':True},s,sts='ok');last[s]=s+'.durable_on'
   reload=emit(s+'.reload','reload',{},s,'bool','ok');equal(reopened,reload,False,'Reload may report unchanged with false/ok');last[s]=reload
  else:
   reload=emit(s+'.reload','reload',{},s,False,'ok');equal(finish,reload,False,'Nil URL reload is a successful unchanged observation');last[s]=reload
 if family=='actual_sample_boundary':
  equal(slots['local']['seed'],slots['persistent']['final'],False,'Persistent 41-contribution rejection retains the same accepted 40-sample prefix')
  equal(slots['local']['final'],slots['canonical']['final'],False,'Uncapped local policy accepts both 40 and 41 contribution calls')
 else:
  equal(slots['local']['final'],slots['persistent']['final'],False,'Same ordered accepted calls agree across local and persistent models')
  equal(slots['local']['final'],slots['canonical']['final'],False,'Canonical sample stream independently checks sparse, normalized or expanded alignment')
 family_rows.append({'id':family,'instances':[x['id'] for x in sessions if x['family']==family],'correlation':'All checks in a family share the accepted seed; local/persistent and canonical checks are correlated, not independent accuracy examples.'})
fixture={'format':'pulpo-r49-fixtures-v1','operations':ops}
dump('fixtures.json',fixture)
dump('expectations.json',{'format':'pulpo-r49-expectations-v1','tolerance':{'absolute':1e-9,'relative':1e-9},'operations':exp,'relations':rel,'families':family_rows,'sessions':sessions})
# Pure Foundation requests; approved reference computes structural oracle, never product output.
dump('reference-requests.json',{'normalize':[{'id':o['id'],'text':o['input']['text']} for o in ops if o['op']=='normalize'],'learn':[{'id':o['id'],**o['input']} for o in ops if o['op']=='learn']})
