#!/usr/bin/env python3
"""Synthetic admission-validator adversaries, never production performance evidence."""
import copy,hashlib,importlib.util,json,pathlib,subprocess,sys,tempfile,xml.etree.ElementTree as ET
p=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('gate',p/'freeze_gate.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
results=[]
def sha(data):return hashlib.sha256(data).hexdigest()
with tempfile.TemporaryDirectory(prefix='pulpo-r47-admission-') as td:
 root=pathlib.Path(td)
 def put(name,data):
  target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data if isinstance(data,bytes) else json.dumps(data).encode());return target
 engine=g.CORE+'Input/KeyboardEngine.swift';put(engine,b'candidate fixture')
 for name in g.required(root):
  if not (root/name).exists():put(name,b'fixture')
 hashes={engine:g.sha(root/engine)}
 put(g.AUDIT+'pre-edit-freeze.json',{'sources':{engine:sha(b'baseline fixture')}})
 put(g.AUDIT+'baseline-KeyboardEngine.swift.txt',b'baseline fixture')
 bins={'baseline':'1'*64,'candidate':'2'*64};resources={x+'.pkdict':str(i)*64 for i,x in enumerate(['en_US','es','en_es'],3)}
 for variant in bins:
  sources={**hashes,'Runner.swift':g.sha(root/(g.AUDIT+'Runner.swift.txt'))}
  if variant=='baseline':sources[engine]=sha(b'baseline fixture')
  put(g.AUDIT+variant+'-final-build-receipt.json',{'exit':0,'binarySHA256':bins[variant],'sourceHashes':sources})
 for name in ['source-controls-final.json','ordinary-final-summary.json','native-admission.json']:put(g.AUDIT+name,{'status':'PASS','sources':hashes})
 evidence={name:g.AUDIT+name+'.md' for name in g.EVIDENCE}
 for name in evidence.values():put(name,b'SYNTHETIC admitted fixture, not a review')
 input=put('input.json',b'{}')
 freeze={'version':1,'inputSHA256':g.sha(input),'executables':bins,'resources':resources,'evidence':evidence,'files':{name:g.sha(root/name) for name in g.required(root)|set(evidence.values())}}
 g.verify(freeze,input,bins,resources,root)
 def reject(name,change):
  f=copy.deepcopy(freeze);change(f);invocations=0
  try:g.verify(f,input,bins,resources,root);invocations+=1
  except Exception:pass
  g.need(invocations==0,'freeze adversary escaped '+name);results.append(name)
 reject('wrong-sealed-input-with-complete-files',lambda f:f.__setitem__('inputSHA256','0'*64))
 reject('empty-source-files',lambda f:f.__setitem__('files',{}))
 reject('omitted-evaluator-file',lambda f:f['files'].pop(g.AUDIT+'check.py'))
 reject('omitted-source-file',lambda f:f['files'].pop(engine))
 reject('omitted-build-receipt',lambda f:f['files'].pop(g.AUDIT+'candidate-final-build-receipt.json'))
 reject('wrong-resource-binding',lambda f:f['resources'].__setitem__('es.pkdict','0'*64))
 reject('missing-review-evidence',lambda f:f['evidence'].pop('oracleReview'))
 # Mutate only structured evidence; validation rejects before source hashes can certify it.
 original=ET.parse('/tmp/pulpo-r47-source-controls-swift-testing.xml')
 def xml_reject(name,change):
  tree=copy.deepcopy(original);change(tree);xml=root/(name+'.xml');tree.write(xml)
  out=root/(name+'.json')
  r=subprocess.run([sys.executable,str(p/'validate-source-controls.py'),str(xml),'/tmp/pulpo-r47-swift-tests/out/Products/Release/KeyboardCoreTests.xctest/Contents/MacOS/KeyboardCoreTests','0',str(out)],capture_output=True,text=True)
  g.need(r.returncode!=0 and json.loads(out.read_text())['status']=='WHOLE_GATE_ERROR','XML adversary escaped '+name);results.append(name)
 def suite_error(t):
  suite=next(x for x in t.findall('.//testsuite') if int(x.get('tests'))>0);suite.set('errors','1');ET.SubElement(suite,'error',message='unavailable')
 xml_reject('suite-level-error',suite_error)
 xml_reject('nan-test-time',lambda t:t.find('.//testcase').set('time','NaN'))
 xml_reject('inconsistent-suite-total',lambda t:t.find('.//testsuite').set('tests','99'))
 xml_reject('mandatory-skip',lambda t:ET.SubElement(t.find('.//testcase'),'skipped'))
 xml_reject('missing-mandatory-definition',lambda t:next(x for x in t.findall('.//testsuite') if len(x.findall('testcase'))>0).remove(t.find('.//testcase')))
print(json.dumps({'syntheticFreezeGood':'PASS','rejectedCount':len(results),'rejected':results},sort_keys=True))
