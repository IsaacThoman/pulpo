import json,pathlib
P=pathlib.Path(__file__).resolve().parent
S={'type':'string'};N={'type':'number'};B={'type':'boolean'};Z={'type':'null'}
def obj(p,required=None):return {'type':'object','additionalProperties':False,'properties':p,'required':list(p) if required is None else required}
def arr(i,**kw):return dict(type='array',items=i,**kw)
def ref(k):return {'$ref':'#/$defs/'+k}
def either(*a):return {'oneOf':list(a)}
def nullable(a):return either(a,Z)
point=obj({'x':N,'y':N});tagnum=either(N,{'enum':['nan','posInf','negInf']});tagpoint=obj({'x':tagnum,'y':tagnum})
relpoint=obj({'base':{'enum':list('abcdefghijklmnopqrstuvwxyz')},'dx':N,'dy':N})
learn=obj({'text':S,'target':S,'taps':arr(either(Z,relpoint,tagpoint))})
inputs={'center':obj({'byte':{'type':'integer','minimum':97,'maximum':122}}),'normalize':obj({'text':S}),'construct':obj({'persistent':B}),'learn':learn,'save':obj({'inBackground':{'const':False}}),'reload':obj({}),'observe':obj({}),'reopen':obj({}),'setLearning':obj({'value':B})}
status={'enum':['ok','invalid','busy','capacity','io','uncertain','cleanup']}
state=obj({'weight':{'type':'number','minimum':0},'offsets':arr(ref('point'),minItems=26,maxItems=26),'learning':B})
file=obj({'path':{'type':'string','minLength':1,'pattern':'^(?!/)(?!.*(?:^|/)\\.\\.?(?:/|$)).+$'},'bytes':{'type':'integer','minimum':0,'maximum':16777216},'sha256':{'type':'string','pattern':'^[0-9a-f]{64}$'}})
record=obj({'id':{'type':'string','minLength':1},'op':{'enum':list(inputs)},'session':nullable(S),'input':{'type':'object'},'resolvedInput':nullable(either(obj({'url':nullable(S)}),obj({'text':S,'target':S,'taps':arr(nullable(tagpoint))}))), 'returned':either(Z,B,S,ref('point')),'status':nullable(status),'state':nullable(ref('state')),'files':arr(ref('file'),maxItems=128),'available':B,'invoked':B,'error':nullable(S)})
record['allOf']=[{'if':{'properties':{'op':{'const':op}}},'then':{'properties':{'input':schema}}} for op,schema in inputs.items()]
record['allOf']+=[{'if':{'properties':{'available':{'const':True}}},'then':{'properties':{'error':Z}}},{'if':{'properties':{'available':{'const':False}}},'then':{'properties':{'error':{'type':'string','minLength':1}}}}]
modelExpect=obj({'kind':{'const':'model'},'status':{'enum':['ok','invalid']},'returned':nullable(B),'learning':B,'zero':{'const':True},'nonzero':{'const':True},'projectionEq':S,'filesEq':S,'projectionDiffersFrom':S,'nonemptyFiles':{'const':True}},['kind','status','returned','learning'])
operation=obj({'id':S,'op':{'enum':list(inputs)},'session':nullable(S),'input':{'type':'object'},'expect':either(obj({'kind':{'const':'center'}}),obj({'kind':{'const':'literal'},'value':S}),modelExpect)})
operation['allOf']=[{'if':{'properties':{'op':{'const':op}}},'then':{'properties':{'input':schema}}} for op,schema in inputs.items()]
alignment=obj({'characters':arr(S),'typedBytes':arr({'type':'integer','minimum':0,'maximum':255}),'origins':arr({'type':'integer','minimum':0}),'targetBytes':arr({'type':'integer','minimum':0,'maximum':255}),'contributingOrigins':nullable(arr({'type':'integer','minimum':0}))})
reference=obj({'id':S,'normalized':S,'alignments':arr(alignment)})
family=obj({'id':S,'intent':S,'independence':S,'reference':reference})
instance=obj({'id':S,'family':S,'mode':{'enum':['local','persistent']}})
relation=obj({'id':S,'left':S,'right':S})
import evaluate as E
f=E.preflight()
den=obj({k:{'const':v} for k,v in f['denominators'].items()})
fixtures=obj({'format':{'const':'pulpo-r48-fixtures-v1'},'tolerance':{'const':1e-10},'families':arr(family,minItems=18,maxItems=18),'instances':arr(instance,minItems=36,maxItems=36),'operations':arr(ref('operation'),minItems=321,maxItems=321),'relations':arr(relation,minItems=49,maxItems=49),'denominators':den})
env=obj({k:({'type':'string','pattern':'^[0-9a-f]{64}$'} if k.endswith('SHA256') else {'type':'string','minLength':1}) for k in ['compiler','runtime','architecture','productSourceSHA256','runnerSHA256','fixturesSHA256','versionLabel']})
raw=obj({'format':{'const':'pulpo-r48-raw-v1'},'environment':env,'operations':arr(ref('record'),minItems=321,maxItems=321)})
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:pulpo:r48:fresh-author:v1','description':'Structural interchange schema; evaluate.py additionally enforces exact IDs, types, reference alignment, finite numbers, availability, all oracle relations and frozen hashes.','oneOf':[ref('fixtures'),ref('raw')],'$defs':{'point':point,'state':state,'file':file,'record':record,'operation':operation,'fixtures':fixtures,'raw':raw}}
(P/'schema.json').write_text(json.dumps(schema,indent=2)+'\n')
checks=[o['id']+'/'+n for o in f['operations'] for n in E.names(o)]+['relation/'+r['id'] for r in f['relations']]
account={'format':'pulpo-r48-accounting-v1','denominators':dict(f['denominators'],individualChecks=len(checks)),'operationCounts':{k:sum(o['op']==k for o in f['operations']) for k in inputs},'intendedOperationIDs':[o['id'] for o in f['operations']],'intendedCheckIDs':checks,'intendedRelationIDs':[r['id'] for r in f['relations']],'independenceUnit':'intent family; all instances/checks within a family are correlated','languageModelResourceModes':0,'populationAccuracyDenominator':None,'readObservationRetries':0,'mutationRetries':0,'backgroundOperations':0}
(P/'accounting.json').write_text(json.dumps(account,indent=2)+'\n')
