#!/usr/bin/env python3
"""Compare reporting-only v2 against frozen independent synthetic countertruth.
No runner/product imports or invocations. Existing adversaries remain separate.
"""
from pathlib import Path
import copy,hashlib,json,subprocess,sys,tempfile
D=Path(__file__).resolve().parent

def need(v,s):
 if not v:raise RuntimeError(s)
def apply(value,p):
 target=value
 for k in p['path'][:-1]:target=target[k]
 key=p['path'][-1]
 if p['action']=='set':target[key]=copy.deepcopy(p['value'])
 elif p['action']=='delete':del target[key]
 elif p['action']=='append':target[key].append(copy.deepcopy(p['value']))
 else:raise RuntimeError('unknown patch')
def main():
 baseline=json.loads((D/'synthetic-raw.json').read_text());cases=json.loads((D/'accounting-witnesses.json').read_text());truth=json.loads((D/'accounting-countertruth.json').read_text());results=[]
 with tempfile.TemporaryDirectory(prefix='.accounting-test-',dir=D) as tmp:
  for c in cases:
   value=copy.deepcopy(baseline)
   for p in c['patches']:apply(value,p)
   s=json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False);mode=c['text_mutation']
   if mode=='duplicate_top_format':s='{"format":"pulpo-r48-raw-v2",'+s[1:]
   elif mode=='nan_token':s=s.replace('"weight":0','"weight":NaN',1)
   elif mode=='truncate':s=s[:-3]
   elif mode not in (None,'missing_file'):raise RuntimeError('unknown mutation')
   path=Path(tmp)/(c['id']+'.json');digest=None
   if mode=='missing_file':argument='.accounting-deliberately-missing.json';need(not (D/argument).exists(),'missing-file witness unexpectedly exists')
   else:path.write_text(s,encoding='utf-8');argument=str(path);digest=hashlib.sha256(path.read_bytes()).hexdigest()
   reports=[]
   for optimized in (False,True):
    run=subprocess.run([sys.executable]+(['-O'] if optimized else [])+[str(D/'evaluate.py'),argument],cwd=D,text=True,capture_output=True,check=False)
    need(run.returncode==c['expected_exit'],c['id']+': exit mismatch '+run.stdout+run.stderr)
    report=json.loads(run.stdout);expect=truth['cases'][c['id']];account=report['accounting']
    need(report['operations_denominator']==452 and report['checks_denominator']==772,c['id']+': denominator')
    need(account['format']=='pulpo-r49-observed-accounting-v2' and account['known']==expect['known'],c['id']+': known/unknown status')
    need(account['planned']==truth['planned'],c['id']+': planned counts')
    need(account['observed']==expect['observed'],c['id']+': complete observed counts/ID lists/status ledger/outcome countertruth')
    need(account['unknown_operation_ids']==expect['unknown_operation_ids'],c['id']+': unknown ID accounting')
    need('expected_invalid_rejections' not in report,c['id']+': old planned-as-observed field remains')
    if c['expected_exit']==2:
     need(report['unavailable_operations'] is None and report['unfired_operations'] is None,c['id']+': corrupt facts falsely known')
    else:
     need(report['failure_count_unit']=='diagnostic_messages_not_failed_aggregates',c['id']+': diagnostic unit')
     need(report['diagnostic_message_count']==report['failure_count']==len(report['failures']),c['id']+': diagnostic count')
    reports.append(report);results.append({'id':c['id'],'optimized':optimized,'expected_exit':c['expected_exit'],'actual_exit':run.returncode,'raw_sha256':digest,'missing_file':mode=='missing_file','report':report})
   need(reports[0]==reports[1],c['id']+': optimization changes reporting truth')
 result={'format':'pulpo-r49-accounting-test-results-v2','result':'pass','synthetic_only':True,'cases':len(cases),'executions':len(results),'normal_executions':len(cases),'optimized_executions':len(cases),'countertruth_sha256':hashlib.sha256((D/'accounting-countertruth.json').read_bytes()).hexdigest(),'results':results}
 (D/'accounting-results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'result':'pass','synthetic_only':True,'cases':len(cases),'executions':len(results)},sort_keys=True))
if __name__=='__main__':main()
