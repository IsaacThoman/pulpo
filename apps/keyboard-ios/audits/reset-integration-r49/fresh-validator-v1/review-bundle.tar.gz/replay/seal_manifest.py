#!/usr/bin/env python3
# Authoring-only sealing helper. Never invoke on a revealed or frozen round.
from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
skip={'author-manifest.json','metadata.json','author-bundle.tar.gz','reference-tool'}
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(D.iterdir()) if p.is_file() and p.name not in skip and not p.name.startswith('.')}
(D/'author-manifest.json').write_text(json.dumps({'format':'pulpo-r49-author-manifest-v1','files':files},indent=2,sort_keys=True)+'\n')
