# R38 independent blind oracle review v2 — VALIDATED, UNSEALED

Static public-intent validation: **validated**. Remaining concrete contract/semantic/schema blockers: **0**. All 18 cases, 54 explicit locale variants and 1,272 step oracles were independently checked. Validation does not guarantee implementation outputs, establish runtime evidence, execute the corpus, or seal it.

## Authorized inputs and information boundary

Only the frozen contract and six explicitly authorized blind artifacts were read. No source, git, directory listing, calibration, development/candidate/baseline outputs, project executable, builds, devices, network, accounts, audio, smoke outputs or retained deliberate-error outputs were inspected. No subagent was spawned; provider/model inherited. Local standard-library JSON parsing, duplicate-key checks, literal UTF16 arithmetic, structural/policy reasoning and hashing are static review computations, not production execution. Only the two requested review files were written. Prior authorship/admission history is reported provenance, not independently witnessed history.

- `apps/keyboard-ios/audits/native-private-content-types-r38/contract.md` — SHA-256 `5b3f36bd029e740cd0c5f19074896f663f71078fcf533229294a81816297b5f6`
- `/tmp/pulpo-r38-blind/heldout.json` — SHA-256 `b4de5b05115d049fe2a8a4d71301b41d38f4b06dcdcacb9828104045cfa6b60e`
- `/tmp/pulpo-r38-blind/authorship.md` — SHA-256 `ea5fbfed31b852dd04f1608a114d41ce90e7dd16e37e305444d77843b31dc721`
- `/tmp/pulpo-r38-blind/oracle-review.md` — SHA-256 `36f992e0fc1ecd8dbc5885063e34937f3f6fdb330ecc074d03919aa16d265411`
- `/tmp/pulpo-r38-blind/oracle-review-summary.json` — SHA-256 `9106e786d7856ed638b268aefd64dd44b8187559a816915749ba580a2119abc4`
- `/tmp/pulpo-r38-blind/heldout-v2.json` — SHA-256 `b92aee89e5a0e989a14896189ba4d5a1c47ffe2a4b319ad92dac5e1671ac9a4c`
- `/tmp/pulpo-r38-blind/authorship-v2.md` — SHA-256 `6f3d95635c3e354c614999ebc0ce16f0c6cf8edfe95679a34d3c9fd118d5c696`

Validated v2 input SHA-256: `b92aee89e5a0e989a14896189ba4d5a1c47ffe2a4b319ad92dac5e1671ac9a4c`. All seven input byte sequences verified unchanged after writing.

## Totals and method

```json
{
  "cases": 18,
  "variants": 54,
  "steps": 1272,
  "duplicateJSONKeys": 0,
  "operationCounts": {
    "destination": 45,
    "type": 165,
    "space": 231,
    "delete": 153,
    "field": 354,
    "insert": 99,
    "host": 150,
    "capture": 6,
    "confirm": 18,
    "guardOrigin": 27,
    "automatic": 21,
    "invalidateGuard": 3
  },
  "fieldOccurrences": {
    "native": 294,
    "custom": 39,
    "legacy": 75
  },
  "nativePrivateIDs": 24,
  "normalNativeIDsIncludingNone": 22,
  "legacyIDs": 24,
  "customExactValues": 11,
  "captureRequests": 6,
  "chooseRequests": 0,
  "emptyCoreAutomaticAcceptances": 3,
  "nonemptyTranscriptAcceptances": 0,
  "validatedStaticCases": 18,
  "validatedStaticSteps": 1272,
  "nonvalidatedCases": 0,
  "nonvalidatedSteps": 0,
  "remainingBlockCount": 0,
  "schemaErrors": 0,
  "utf16ArithmeticErrors": 0,
  "policyGuardAssertionErrors": 0,
  "languageCorrelationErrors": 0,
  "nativePrivateStandardNumberPadCombinationsPerLocale": 48,
  "productionExecutions": 0
}
```

Every initial, host and expected selection was checked against complete-document UTF16 length and scalar boundaries. Every type/insert/space/delete was independently recomputed from operation arguments and prior document; nonmutating operations and refused transcript challenges preserve it. Backward deletion only targets ASCII; selected deletion never guesses grapheme/surrogate behavior. Non-BMP prefix/suffix conservation is explicit.

All root/case/variant/field/step/expect keys and scalar types conform to version 1, with no duplicate JSON keys. All three real language variants are expanded, structurally correlated and independently calculated. Meaningful English/Spanish/bilingual vocabulary is used without claiming lexicon offers or guaranteed implementation outcomes.

Availability comes only from the frozen contract: all 24 private named native IDs, 22 normal IDs including none, and all 24 explicit legacy aliases are valid. All private native IDs have standard and numberPad coverage in every locale. Eleven custom strings remain exact opaque values. No native programmer-name raw fixture or alias substitution supplies native evidence.

Every asserted private/plain/confirmation/automatic/accepted route was checked against active traits, UTF16 selection, stable core identity, both origin contexts and explicit invalidation. Private learning absences and normal positive touch are meaningful intended real-stack checks, with limits below. Each fired challenge declares both accepted routes. Every asserted native automatic is explicitly false/unavailable.

## Prior objections and author responses

### B01 — Normal enabled-autocorrection commit has no exact spelling/caret guarantee

Disposition: **resolved-by-explicit-replacement**.

Author response reviewed: Normal space boundary replaced by literal insert ASCII space; words replaced with real vocabulary.

Independent assessment: The declared insertText spacing:false operation supplies the literal boundary. Real words are not assumed immune to autocorrection. All three variants and dependent text/carets recompute correctly.

### B02 — Exact normal dictionary count and total-count units are unspecified

Disposition: **resolved-by-removing-unsupported-exact-units**.

Author response reviewed: Normal exact dictionary/total 1 and downstream assumptions removed; positive touch retained; normal dictionary/pair/total readbacks remain required but unasserted.

Independent assessment: No oracle assumes undocumented increment or bilingual aggregation units. Fresh private-only zero readbacks and distinct private-word absence remain meaningful. Normal centered taps and literal commit are a plausible real-stack positive touch-control intent, not a guarantee of implementation output. Touch positivity alone does not certify dictionary/pair positivity; retain and assess normal readbacks before claiming successful controls for those measures.

### B03 — Captured stale-choice refusal is not specified

Disposition: **resolved-by-explicit-scope-replacement**.

Author response reviewed: Cases renamed; choose replaced by fired selected-destination confirmation refusal; actual-offer-gated captures retained before unrelated host identity/context changes.

Independent assessment: No stale choose/no-op semantics remain assumed. Actual matching literal choices are plausible independent requests and may fail the benchmark if unavailable. A successful capture becomes stale, but no stale-choice dispatch/rejection is exercised. Confirmation refusal follows current selection/privacy independently. Missing captures remain explicit failures, never synthesized offers or safety wins.

### B04 — Private-origin permanence after return to normal is unspecified without invalidation

Disposition: **resolved-by-whole-case-replacement**.

Author response reviewed: Private-origin permanence removed; case replaced by normal-origin matching guard plus current selected/secure refusals.

Independent assessment: No surviving assertion needs origin-privacy permanence. Case 16 independently retains explicit persistent invalidation after restoring normal. The new normal-origin matching permission control follows the contract. No silent invalidation repair occurred.

### B05 — Successful insertTranscript exact spacing is unspecified

Disposition: **resolved-by-removing-successful-nonempty-transcripts**.

Author response reviewed: Allowed nonempty confirms removed; matching empty core automatic is permission-only, native unavailable; sentence established by host.

Independent assessment: All nonempty transcript challenges refuse, so complete documents remain unchanged. The sole permitted automatic payload and document are empty; the shared oracle is unchanged. Transcript spacing and nonempty core/native text divergence are not assumed. Confirmation permission is read independently; nonempty confirmation insertion success is not claimed.

### B06 — Apostrophe in type is outside the declared letter-tap semantics

Disposition: **resolved-by-supported-operation-split**.

Author response reviewed: Apostrophe-bearing type replaced by letter-only type, literal apostrophe insert, letter-only type; downstream carets recomputed.

Independent assessment: All type payloads contain ASCII letters only. Punctuation uses literal insert or host. Intermediate and dependent UTF16 oracles are correct in every language. Backward deletions target ASCII and selected deletions use valid scalar boundaries.

Original rejected assumptions are not retroactively accepted. These dispositions validate the explicit pre-reveal replacements/removals and downstream oracles. Parsed case values 7, 9, 14, 16 and 17 are unchanged; all v2 steps were checked again.

## Runtime evidence and claim limits

- Static public-intent validation does not guarantee the frozen implementation passes. Preserve every transition, missing actual offer, unavailable guard, failure and baseline/candidate outcome without early exit. No implementation-derived oracle retuning.
- Six actual-offer-gated literal captures are plausible independently intended runtime challenges. No lexicon offer is guaranteed or manufactured. Missing capture is explicit failure. Unrelated host identity/context changes make successful captures stale; no choose remains, so stale-choice dispatch/rejection is outside v2 claims.
- Fresh public PersonalDictionary(url:nil)/TouchModel(url:nil) through real LanguageStack remain mandatory. Normal centered taps plus literal boundary explicitly assert positive touch; normal dictionary/pair/total readbacks are required but unasserted. Assess those retained normal readbacks before claiming positive controls for each measure: touch positivity cannot establish dictionary/pair positivity, and zero normal readbacks cannot be called successful controls for those measures.
- Native automatic remains unavailable for normal and private because TextViewDocument lacks stable ID, never a private safety win. Normal matching core guard has an empty-payload fired permission control, proving no nonempty insertion effect. Confirmation is independent of native identity absence.
- Automatic/confirm accepted flags concern direct destination/guard challenges only; no controller, recorder, microphone, start/recovery or audio acceptance is claimed.
- No pair-count assertion, glide operation, raw-map fixture, platform-specific document oracle or schema extension is introduced. Candidate/source/core/native admission and sealing belong to parent. This report creates no seal.

The user reports all 13 operations and all 4 capture kinds independently smoked on core+UIKit, 105 transitions, zero failures, and 18 deliberate errors retained. No output was inspected or smoke rerun. V2 itself uses 12 operation kinds and literal captures; capability smoke is separate from heldout success.

## Per-case and per-step audit

For each step the argument object, independently calculated complete document/UTF16 selection and every asserted oracle field are listed. Six check groups cover schema, current field availability, UTF16 bounds/scalar boundaries, full-document arithmetic, asserted policy/readback intent and guard/accepted routes. Validated means supported static public intent; actual offered choices and readbacks remain runtime challenges.

### 1. r38-native-private-01 — validated-static

Native private group 1: real native IDs, standard/numeric, private real-word commits, zero readbacks, complete emoji-bearing selection edits.

#### en_US

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"username","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

#### es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"username","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

#### en_es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"username","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

### 2. r38-native-private-02 — validated-static

Native private group 2: real native IDs, standard/numeric, private real-word commits, zero readbacks, complete emoji-bearing selection edits.

#### en_US

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"emailAddress","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

#### es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"emailAddress","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

#### en_es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"emailAddress","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

### 3. r38-native-private-03 — validated-static

Native private group 3: real native IDs, standard/numeric, private real-word commits, zero readbacks, complete emoji-bearing selection edits.

#### en_US

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardSecurityCode","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardSecurityCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

#### es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardSecurityCode","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardSecurityCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

#### en_es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardSecurityCode","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardSecurityCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

### 4. r38-native-private-04 — validated-static

Native private group 4: real native IDs, standard/numeric, private real-word commits, zero readbacks, complete emoji-bearing selection edits.

#### en_US

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

#### es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

#### en_es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

### 5. r38-native-private-05 — validated-static

Native private group 5: real native IDs, standard/numeric, private real-word commits, zero readbacks, complete emoji-bearing selection edits.

#### en_US

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardType","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardType","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

#### es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardType","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardType","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

#### en_es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"creditCardType","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardType","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

### 6. r38-native-private-06 — validated-static

Native private group 6: real native IDs, standard/numeric, private real-word commits, zero readbacks, complete emoji-bearing selection edits.

#### en_US

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"birthdate","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdate","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:meadow:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:meadow7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:meadow7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

#### es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"birthdate","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdate","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:camino:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7 :fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"L😀:camino7 :fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:camino7:fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:camino7:fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

#### en_es

Initial complete text `"L😀:seed:fin"`; UTF16 selection `[4,4]`; field `{"id":"birthdate","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

2. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

3. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

4. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdate","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

7. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

13. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

15. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

17. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

19. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

20. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

21. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

22. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

23. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

24. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

25. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

26. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

27. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

28. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"L😀:seed:fin","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:seed:fin","selection":[4,4]}`

   Every asserted field checked: `{"text":"L😀:seed:fin","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

29. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

30. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo :fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo :fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

31. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

32. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo:fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"L😀:amigo:fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

33. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

34. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7 :fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7 :fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

35. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"L😀:amigo7:fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"L😀:amigo7:fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

### 7. r38-native-normal-exceptions — validated-static

All normal native exceptions including none retain nonprivate standard policy and unselected confirmation permission.

#### en_US

Initial complete text `"English 😀 tail"`; UTF16 selection `[12,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"namePrefix","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"givenName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"middleName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"familyName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"nameSuffix","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"nickname","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"jobTitle","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"organizationName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

11. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"location","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

12. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"fullStreetAddress","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"streetAddressLine1","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"streetAddressLine2","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

15. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressCity","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

16. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressState","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

17. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressCityAndState","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"sublocality","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

19. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"countryName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

20. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"dateTime","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

21. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"cellularEID","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

22. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"cellularIMEI","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"English 😀 tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"English 😀 tail","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true}`

#### es

Initial complete text `"Español 😀 fin"`; UTF16 selection `[11,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"namePrefix","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"givenName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"middleName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"familyName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"nameSuffix","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"nickname","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"jobTitle","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"organizationName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

11. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"location","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

12. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"fullStreetAddress","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"streetAddressLine1","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"streetAddressLine2","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

15. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressCity","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

16. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressState","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

17. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressCityAndState","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"sublocality","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

19. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"countryName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

20. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"dateTime","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

21. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"cellularEID","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

22. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"cellularIMEI","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Español 😀 fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"Español 😀 fin","selection":[11,0],"private":false,"plain":true,"allowsConfirmation":true}`

#### en_es

Initial complete text `"Hola English 😀 fin"`; UTF16 selection `[16,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"namePrefix","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"givenName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"middleName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"familyName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"nameSuffix","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"nickname","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"jobTitle","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"organizationName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

11. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"location","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

12. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"fullStreetAddress","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"streetAddressLine1","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"streetAddressLine2","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

15. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressCity","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

16. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressState","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

17. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"addressCityAndState","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

18. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"sublocality","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

19. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"countryName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

20. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"dateTime","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

21. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"cellularEID","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

22. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"cellularIMEI","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola English 😀 fin","selection":[16,0]}`

   Every asserted field checked: `{"text":"Hola English 😀 fin","selection":[16,0],"private":false,"plain":true,"allowsConfirmation":true}`

### 8. r38-normal-learning-control — validated-static

Normal word taps plus literal boundary provide positive touch control; distinct private word remains absent. No exact normal dictionary/total unit assumption.

#### en_US

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"givenName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"garden"}`

   Calculated complete document/UTF16 selection: `{"text":"garden","selection":[6,0]}`

   Every asserted field checked: `{"text":"garden","selection":[6,0],"private":false,"plain":true}`

2. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":" "}`

   Calculated complete document/UTF16 selection: `{"text":"garden ","selection":[7,0]}`

   Every asserted field checked: `{"text":"garden ","selection":[7,0],"private":false,"plain":true,"touchPositive":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"garden ","selection":[7,0]}`

   Every asserted field checked: `{"text":"garden ","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"touchPositive":true,"knownCounts":{"meadow":0}}`

4. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"garden meadow","selection":[13,0]}`

   Every asserted field checked: `{"text":"garden meadow","selection":[13,0],"private":true,"plain":false,"knownCounts":{"meadow":0}}`

5. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"garden meadow ","selection":[14,0]}`

   Every asserted field checked: `{"text":"garden meadow ","selection":[14,0],"private":true,"plain":false,"touchPositive":true,"knownCounts":{"meadow":0}}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"garden meadow ","selection":[14,0]}`

   Every asserted field checked: `{"text":"garden meadow ","selection":[14,0],"private":false,"plain":true,"touchPositive":true}`

#### es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"givenName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"escuela"}`

   Calculated complete document/UTF16 selection: `{"text":"escuela","selection":[7,0]}`

   Every asserted field checked: `{"text":"escuela","selection":[7,0],"private":false,"plain":true}`

2. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":" "}`

   Calculated complete document/UTF16 selection: `{"text":"escuela ","selection":[8,0]}`

   Every asserted field checked: `{"text":"escuela ","selection":[8,0],"private":false,"plain":true,"touchPositive":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"escuela ","selection":[8,0]}`

   Every asserted field checked: `{"text":"escuela ","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"touchPositive":true,"knownCounts":{"camino":0}}`

4. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"escuela camino","selection":[14,0]}`

   Every asserted field checked: `{"text":"escuela camino","selection":[14,0],"private":true,"plain":false,"knownCounts":{"camino":0}}`

5. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"escuela camino ","selection":[15,0]}`

   Every asserted field checked: `{"text":"escuela camino ","selection":[15,0],"private":true,"plain":false,"touchPositive":true,"knownCounts":{"camino":0}}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"escuela camino ","selection":[15,0]}`

   Every asserted field checked: `{"text":"escuela camino ","selection":[15,0],"private":false,"plain":true,"touchPositive":true}`

#### en_es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"givenName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"hello"}`

   Calculated complete document/UTF16 selection: `{"text":"hello","selection":[5,0]}`

   Every asserted field checked: `{"text":"hello","selection":[5,0],"private":false,"plain":true}`

2. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":" "}`

   Calculated complete document/UTF16 selection: `{"text":"hello ","selection":[6,0]}`

   Every asserted field checked: `{"text":"hello ","selection":[6,0],"private":false,"plain":true,"touchPositive":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"hello ","selection":[6,0]}`

   Every asserted field checked: `{"text":"hello ","selection":[6,0],"private":true,"plain":false,"suggestionsEmpty":true,"touchPositive":true,"knownCounts":{"amigo":0}}`

4. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"hello amigo","selection":[11,0]}`

   Every asserted field checked: `{"text":"hello amigo","selection":[11,0],"private":true,"plain":false,"knownCounts":{"amigo":0}}`

5. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"hello amigo ","selection":[12,0]}`

   Every asserted field checked: `{"text":"hello amigo ","selection":[12,0],"private":true,"plain":false,"touchPositive":true,"knownCounts":{"amigo":0}}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"hello amigo ","selection":[12,0]}`

   Every asserted field checked: `{"text":"hello amigo ","selection":[12,0],"private":false,"plain":true,"touchPositive":true}`

### 9. r38-custom-exact-opaque — validated-static

Custom whitespace, case and punctuation stay exact opaque values; literal insertion conserves suffix.

#### en_US

Initial complete text `"keep 😀 suffix"`; UTF16 selection `[0,0]`; field `{"id":" Username ","route":"custom","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":" Username ","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"USERNAME","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"user-name","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username.","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newpassword","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode.","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"EMAILADDRESS","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":" URL ","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode/","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"com.example.password","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 suffix","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 suffix","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

11. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"ok:"}`

   Calculated complete document/UTF16 selection: `{"text":"ok:keep 😀 suffix","selection":[3,0]}`

   Every asserted field checked: `{"text":"ok:keep 😀 suffix","selection":[3,0],"private":false,"plain":true}`

#### es

Initial complete text `"queda 😀 final"`; UTF16 selection `[0,0]`; field `{"id":" Username ","route":"custom","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":" Username ","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"USERNAME","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"user-name","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username.","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newpassword","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode.","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"EMAILADDRESS","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":" URL ","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode/","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"com.example.password","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"queda 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"queda 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

11. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"sí:"}`

   Calculated complete document/UTF16 selection: `{"text":"sí:queda 😀 final","selection":[3,0]}`

   Every asserted field checked: `{"text":"sí:queda 😀 final","selection":[3,0],"private":false,"plain":true}`

#### en_es

Initial complete text `"keep 😀 final"`; UTF16 selection `[0,0]`; field `{"id":" Username ","route":"custom","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":" Username ","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"USERNAME","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

3. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"user-name","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username.","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newpassword","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

6. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode.","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"EMAILADDRESS","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":" URL ","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode/","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"com.example.password","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"keep 😀 final","selection":[0,0]}`

   Every asserted field checked: `{"text":"keep 😀 final","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true}`

11. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"hola:"}`

   Calculated complete document/UTF16 selection: `{"text":"hola:keep 😀 final","selection":[5,0]}`

   Every asserted field checked: `{"text":"hola:keep 😀 final","selection":[5,0],"private":false,"plain":true}`

### 10. r38-explicit-legacy-aliases — validated-static

All 24 explicit legacy aliases retain private policy and fresh zero readbacks, separately from native evidence.

#### en_US

Initial complete text `"A|seed|Z"`; UTF16 selection `[2,4]`; field `{"id":"username","route":"legacy","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

2. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

8. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

14. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

15. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

17. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

18. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

19. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

20. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

21. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

22. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

23. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

24. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

25. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

26. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

27. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

28. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

29. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

30. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

31. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

32. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

33. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardSecurityCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

34. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

35. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

36. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

37. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

38. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

39. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

40. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

41. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

42. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

43. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

44. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

45. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

46. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

47. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

48. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

49. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

50. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

51. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

52. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

53. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

54. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

55. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

56. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

57. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

58. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

59. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

60. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

61. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

62. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

63. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

64. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

65. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardType","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

66. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

67. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

68. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

69. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

70. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

71. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

72. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

73. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

74. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

75. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

76. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

77. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

78. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

79. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

80. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

81. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdate","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

82. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

83. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

84. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

85. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

86. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

87. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

88. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

89. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

90. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

91. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

92. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

93. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

94. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

95. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|meadow|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

96. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

97. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|meadow |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|meadow |Z","selection":[9,0],"private":false,"plain":true,"allowsConfirmation":true}`

#### es

Initial complete text `"A|seed|Z"`; UTF16 selection `[2,4]`; field `{"id":"username","route":"legacy","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

2. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

8. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

14. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

15. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

17. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

18. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

19. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

20. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

21. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

22. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

23. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

24. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

25. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

26. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

27. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

28. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

29. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

30. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

31. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

32. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

33. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardSecurityCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

34. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

35. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

36. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

37. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

38. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

39. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

40. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

41. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

42. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

43. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

44. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

45. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

46. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

47. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

48. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

49. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

50. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

51. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

52. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

53. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

54. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

55. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

56. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

57. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

58. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

59. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

60. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

61. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

62. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

63. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

64. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

65. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardType","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

66. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

67. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

68. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

69. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

70. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

71. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

72. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

73. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

74. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

75. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

76. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

77. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

78. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

79. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

80. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

81. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdate","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

82. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

83. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

84. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

85. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

86. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

87. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

88. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

89. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

90. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

91. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

92. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

93. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

94. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

95. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino|Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|camino|Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

96. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

97. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|camino |Z","selection":[9,0]}`

   Every asserted field checked: `{"text":"A|camino |Z","selection":[9,0],"private":false,"plain":true,"allowsConfirmation":true}`

#### en_es

Initial complete text `"A|seed|Z"`; UTF16 selection `[2,4]`; field `{"id":"username","route":"legacy","keyboard":"standard","secure":false}`: validated.

1. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

2. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"password","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

8. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

9. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"newPassword","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

10. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

11. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

14. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

15. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

16. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

17. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"emailAddress","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

18. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

19. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

20. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

21. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

22. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

23. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

24. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

25. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

26. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

27. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

28. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

29. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

30. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

31. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

32. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

33. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardSecurityCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

34. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

35. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

36. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

37. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpiration","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

38. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

39. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

40. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

41. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationMonth","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

42. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

43. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

44. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

45. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardExpirationYear","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

46. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

47. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

48. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

49. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

50. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

51. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

52. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

53. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardGivenName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

54. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

55. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

56. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

57. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardFamilyName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

58. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

59. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

60. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

61. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardMiddleName","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

62. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

63. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

64. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

65. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardType","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

66. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

67. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

68. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

69. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"postalCode","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

70. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

71. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

72. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

73. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"flightNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

74. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

75. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

76. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

77. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"shipmentTrackingNumber","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

78. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

79. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

80. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

81. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdate","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

82. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

83. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

84. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

85. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateDay","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

86. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

87. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

88. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

89. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateMonth","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

90. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

91. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

92. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

93. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"birthdateYear","route":"legacy","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

94. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"A|seed|Z","selection":[2,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"A|seed|Z","selection":[2,4]}`

   Every asserted field checked: `{"text":"A|seed|Z","selection":[2,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

95. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo|Z","selection":[7,0]}`

   Every asserted field checked: `{"text":"A|amigo|Z","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

96. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

97. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"A|amigo |Z","selection":[8,0]}`

   Every asserted field checked: `{"text":"A|amigo |Z","selection":[8,0],"private":false,"plain":true,"allowsConfirmation":true}`

### 11. r38-secure-trait-transitions — validated-static

Secure entry overrides normal native/custom fields; restoration and later actual native username preserve complete document.

#### en_US

Initial complete text `"left|seed|right"`; UTF16 selection `[5,4]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"left|seed|right","selection":[5,4]}`

   Every asserted field checked: `{"text":"left|seed|right","selection":[5,4],"private":false,"plain":true,"allowsConfirmation":false}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"left|seed|right","selection":[5,4]}`

   Every asserted field checked: `{"text":"left|seed|right","selection":[5,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"meadow"}`

   Calculated complete document/UTF16 selection: `{"text":"left|meadow|right","selection":[11,0]}`

   Every asserted field checked: `{"text":"left|meadow|right","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"left|meadow |right","selection":[12,0]}`

   Every asserted field checked: `{"text":"left|meadow |right","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"meadow":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"harmless.type","route":"custom","keyboard":"numberPad","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"left|meadow |right","selection":[12,0]}`

   Every asserted field checked: `{"text":"left|meadow |right","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"4"}`

   Calculated complete document/UTF16 selection: `{"text":"left|meadow 4|right","selection":[13,0]}`

   Every asserted field checked: `{"text":"left|meadow 4|right","selection":[13,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"harmless.type","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"left|meadow 4|right","selection":[13,0]}`

   Every asserted field checked: `{"text":"left|meadow 4|right","selection":[13,0],"private":false,"plain":true,"allowsConfirmation":true,"totalCount":0,"touchWeight":0.0}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"left|meadow 4|right","selection":[13,0]}`

   Every asserted field checked: `{"text":"left|meadow 4|right","selection":[13,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

9. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"!"}`

   Calculated complete document/UTF16 selection: `{"text":"left|meadow 4!|right","selection":[14,0]}`

   Every asserted field checked: `{"text":"left|meadow 4!|right","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

#### es

Initial complete text `"izq|seed|der"`; UTF16 selection `[4,4]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"izq|seed|der","selection":[4,4]}`

   Every asserted field checked: `{"text":"izq|seed|der","selection":[4,4],"private":false,"plain":true,"allowsConfirmation":false}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"izq|seed|der","selection":[4,4]}`

   Every asserted field checked: `{"text":"izq|seed|der","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"camino"}`

   Calculated complete document/UTF16 selection: `{"text":"izq|camino|der","selection":[10,0]}`

   Every asserted field checked: `{"text":"izq|camino|der","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"izq|camino |der","selection":[11,0]}`

   Every asserted field checked: `{"text":"izq|camino |der","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"camino":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"harmless.type","route":"custom","keyboard":"numberPad","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"izq|camino |der","selection":[11,0]}`

   Every asserted field checked: `{"text":"izq|camino |der","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"4"}`

   Calculated complete document/UTF16 selection: `{"text":"izq|camino 4|der","selection":[12,0]}`

   Every asserted field checked: `{"text":"izq|camino 4|der","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"harmless.type","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"izq|camino 4|der","selection":[12,0]}`

   Every asserted field checked: `{"text":"izq|camino 4|der","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true,"totalCount":0,"touchWeight":0.0}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"izq|camino 4|der","selection":[12,0]}`

   Every asserted field checked: `{"text":"izq|camino 4|der","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

9. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"!"}`

   Calculated complete document/UTF16 selection: `{"text":"izq|camino 4!|der","selection":[13,0]}`

   Every asserted field checked: `{"text":"izq|camino 4!|der","selection":[13,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

#### en_es

Initial complete text `"left|seed|fin"`; UTF16 selection `[5,4]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"left|seed|fin","selection":[5,4]}`

   Every asserted field checked: `{"text":"left|seed|fin","selection":[5,4],"private":false,"plain":true,"allowsConfirmation":false}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"left|seed|fin","selection":[5,4]}`

   Every asserted field checked: `{"text":"left|seed|fin","selection":[5,4],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"amigo"}`

   Calculated complete document/UTF16 selection: `{"text":"left|amigo|fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"left|amigo|fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"left|amigo |fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"left|amigo |fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false,"knownCounts":{"amigo":0}}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"harmless.type","route":"custom","keyboard":"numberPad","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"left|amigo |fin","selection":[11,0]}`

   Every asserted field checked: `{"text":"left|amigo |fin","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"4"}`

   Calculated complete document/UTF16 selection: `{"text":"left|amigo 4|fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"left|amigo 4|fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"harmless.type","route":"custom","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"left|amigo 4|fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"left|amigo 4|fin","selection":[12,0],"private":false,"plain":true,"allowsConfirmation":true,"totalCount":0,"touchWeight":0.0}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"username","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"left|amigo 4|fin","selection":[12,0]}`

   Every asserted field checked: `{"text":"left|amigo 4|fin","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

9. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"!"}`

   Calculated complete document/UTF16 selection: `{"text":"left|amigo 4!|fin","selection":[13,0]}`

   Every asserted field checked: `{"text":"left|amigo 4!|fin","selection":[13,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

### 12. r38-captured-offer-stale-normal-selection — validated-static

Actual-offer-gated literal capture becomes stale after unrelated host; selected confirm refuses; literal replacement exact. No stale dispatch claim.

#### en_US

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"nickname","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"garden"}`

   Calculated complete document/UTF16 selection: `{"text":"garden","selection":[6,0]}`

   Every asserted field checked: `{"text":"garden","selection":[6,0],"private":false,"plain":true}`

2. **capture — validated-static**. All six check groups passed.

   Arguments: `{"kind":"literal","text":"garden"}`

   Calculated complete document/UTF16 selection: `{"text":"garden","selection":[6,0]}`

   Every asserted field checked: `{"text":"garden","selection":[6,0],"private":false,"plain":true}`

3. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Other 😀|old|tail","selection":[9,3],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"Other 😀|old|tail","selection":[9,3]}`

   Every asserted field checked: `{"text":"Other 😀|old|tail","selection":[9,3],"private":false,"plain":true,"allowsConfirmation":false}`

4. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"garden"}`

   Calculated complete document/UTF16 selection: `{"text":"Other 😀|old|tail","selection":[9,3]}`

   Every asserted field checked: `{"text":"Other 😀|old|tail","selection":[9,3],"private":false,"plain":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

5. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"new"}`

   Calculated complete document/UTF16 selection: `{"text":"Other 😀|new|tail","selection":[12,0]}`

   Every asserted field checked: `{"text":"Other 😀|new|tail","selection":[12,0],"private":false,"plain":true}`

#### es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"nickname","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"escuela"}`

   Calculated complete document/UTF16 selection: `{"text":"escuela","selection":[7,0]}`

   Every asserted field checked: `{"text":"escuela","selection":[7,0],"private":false,"plain":true}`

2. **capture — validated-static**. All six check groups passed.

   Arguments: `{"kind":"literal","text":"escuela"}`

   Calculated complete document/UTF16 selection: `{"text":"escuela","selection":[7,0]}`

   Every asserted field checked: `{"text":"escuela","selection":[7,0],"private":false,"plain":true}`

3. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Otro 😀|viejo|fin","selection":[8,5],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"Otro 😀|viejo|fin","selection":[8,5]}`

   Every asserted field checked: `{"text":"Otro 😀|viejo|fin","selection":[8,5],"private":false,"plain":true,"allowsConfirmation":false}`

4. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"escuela"}`

   Calculated complete document/UTF16 selection: `{"text":"Otro 😀|viejo|fin","selection":[8,5]}`

   Every asserted field checked: `{"text":"Otro 😀|viejo|fin","selection":[8,5],"private":false,"plain":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

5. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"nuevo"}`

   Calculated complete document/UTF16 selection: `{"text":"Otro 😀|nuevo|fin","selection":[13,0]}`

   Every asserted field checked: `{"text":"Otro 😀|nuevo|fin","selection":[13,0],"private":false,"plain":true}`

#### en_es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"nickname","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"hello"}`

   Calculated complete document/UTF16 selection: `{"text":"hello","selection":[5,0]}`

   Every asserted field checked: `{"text":"hello","selection":[5,0],"private":false,"plain":true}`

2. **capture — validated-static**. All six check groups passed.

   Arguments: `{"kind":"literal","text":"hello"}`

   Calculated complete document/UTF16 selection: `{"text":"hello","selection":[5,0]}`

   Every asserted field checked: `{"text":"hello","selection":[5,0],"private":false,"plain":true}`

3. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Otro 😀|old|tail","selection":[8,3],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"Otro 😀|old|tail","selection":[8,3]}`

   Every asserted field checked: `{"text":"Otro 😀|old|tail","selection":[8,3],"private":false,"plain":true,"allowsConfirmation":false}`

4. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"hello"}`

   Calculated complete document/UTF16 selection: `{"text":"Otro 😀|old|tail","selection":[8,3]}`

   Every asserted field checked: `{"text":"Otro 😀|old|tail","selection":[8,3],"private":false,"plain":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

5. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"fresh"}`

   Calculated complete document/UTF16 selection: `{"text":"Otro 😀|fresh|tail","selection":[13,0]}`

   Every asserted field checked: `{"text":"Otro 😀|fresh|tail","selection":[13,0],"private":false,"plain":true}`

### 13. r38-captured-offer-stale-private-selection — validated-static

Actual-offer-gated capture becomes stale after unrelated host; late native creditCardName and selection refuse confirmation; literal replacement exact.

#### en_US

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"organizationName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"garden"}`

   Calculated complete document/UTF16 selection: `{"text":"garden","selection":[6,0]}`

   Every asserted field checked: `{"text":"garden","selection":[6,0],"private":false,"plain":true}`

2. **capture — validated-static**. All six check groups passed.

   Arguments: `{"kind":"literal","text":"garden"}`

   Calculated complete document/UTF16 selection: `{"text":"garden","selection":[6,0]}`

   Every asserted field checked: `{"text":"garden","selection":[6,0],"private":false,"plain":true}`

3. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"P😀|keep|Q","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|keep|Q","selection":[4,4]}`

   Every asserted field checked: `{"text":"P😀|keep|Q","selection":[4,4],"private":false,"plain":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|keep|Q","selection":[4,4]}`

   Every asserted field checked: `{"text":"P😀|keep|Q","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"garden"}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|keep|Q","selection":[4,4]}`

   Every asserted field checked: `{"text":"P😀|keep|Q","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"X"}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|X|Q","selection":[5,0]}`

   Every asserted field checked: `{"text":"P😀|X|Q","selection":[5,0],"private":true,"plain":false,"suggestionsEmpty":true}`

#### es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"organizationName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"escuela"}`

   Calculated complete document/UTF16 selection: `{"text":"escuela","selection":[7,0]}`

   Every asserted field checked: `{"text":"escuela","selection":[7,0],"private":false,"plain":true}`

2. **capture — validated-static**. All six check groups passed.

   Arguments: `{"kind":"literal","text":"escuela"}`

   Calculated complete document/UTF16 selection: `{"text":"escuela","selection":[7,0]}`

   Every asserted field checked: `{"text":"escuela","selection":[7,0],"private":false,"plain":true}`

3. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"P😀|queda|Q","selection":[4,5],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|queda|Q","selection":[4,5]}`

   Every asserted field checked: `{"text":"P😀|queda|Q","selection":[4,5],"private":false,"plain":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|queda|Q","selection":[4,5]}`

   Every asserted field checked: `{"text":"P😀|queda|Q","selection":[4,5],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"escuela"}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|queda|Q","selection":[4,5]}`

   Every asserted field checked: `{"text":"P😀|queda|Q","selection":[4,5],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"X"}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|X|Q","selection":[5,0]}`

   Every asserted field checked: `{"text":"P😀|X|Q","selection":[5,0],"private":true,"plain":false,"suggestionsEmpty":true}`

#### en_es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"organizationName","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"hello"}`

   Calculated complete document/UTF16 selection: `{"text":"hello","selection":[5,0]}`

   Every asserted field checked: `{"text":"hello","selection":[5,0],"private":false,"plain":true}`

2. **capture — validated-static**. All six check groups passed.

   Arguments: `{"kind":"literal","text":"hello"}`

   Calculated complete document/UTF16 selection: `{"text":"hello","selection":[5,0]}`

   Every asserted field checked: `{"text":"hello","selection":[5,0],"private":false,"plain":true}`

3. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"P😀|save|Q","selection":[4,4],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|save|Q","selection":[4,4]}`

   Every asserted field checked: `{"text":"P😀|save|Q","selection":[4,4],"private":false,"plain":true}`

4. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"creditCardName","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|save|Q","selection":[4,4]}`

   Every asserted field checked: `{"text":"P😀|save|Q","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"hello"}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|save|Q","selection":[4,4]}`

   Every asserted field checked: `{"text":"P😀|save|Q","selection":[4,4],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

6. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"X"}`

   Calculated complete document/UTF16 selection: `{"text":"P😀|X|Q","selection":[5,0]}`

   Every asserted field checked: `{"text":"P😀|X|Q","selection":[5,0],"private":true,"plain":false,"suggestionsEmpty":true}`

### 14. r38-keyboard-classification-independent — validated-static

Nonprivate nil numeric/email/URL classification separated from privacy; real private native URL/telephone; core permission separated from native unavailability.

#### en_US

Initial complete text `"plain 😀"`; UTF16 selection `[8,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true}`

3. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

4. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"email","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true}`

6. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

7. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"url","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true}`

9. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

10. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

11. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

12. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

15. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"plain 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"plain 😀","selection":[8,0],"private":false,"plain":true,"allowsConfirmation":true}`

#### es

Initial complete text `"texto 😀"`; UTF16 selection `[8,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true}`

3. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

4. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"email","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true}`

6. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

7. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"url","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true}`

9. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

10. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

11. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

12. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

15. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto 😀","selection":[8,0]}`

   Every asserted field checked: `{"text":"texto 😀","selection":[8,0],"private":false,"plain":true,"allowsConfirmation":true}`

#### en_es

Initial complete text `"texto plain 😀"`; UTF16 selection `[14,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":true,"allowsConfirmation":true}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true}`

3. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

4. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

5. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"email","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true}`

6. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

7. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"url","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true}`

9. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

10. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

11. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

12. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"URL","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

13. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

14. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"telephoneNumber","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

15. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"texto plain 😀","selection":[14,0]}`

   Every asserted field checked: `{"text":"texto plain 😀","selection":[14,0],"private":false,"plain":true,"allowsConfirmation":true}`

### 15. r38-private-unicode-edit-conservation — validated-static

Letter-only taps, literal punctuation split, repeated spaces, ASCII delete, non-BMP conservation and selected deletion.

#### en_US

Initial complete text `"A😀|tomorrow|終"`; UTF16 selection `[4,8]`; field `{"id":"birthdate","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"rock"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|rock|終","selection":[8,0]}`

   Every asserted field checked: `{"text":"A😀|rock|終","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

2. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"'"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|rock'|終","selection":[9,0]}`

   Every asserted field checked: `{"text":"A😀|rock'|終","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"roll"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|rock'roll|終","selection":[13,0]}`

   Every asserted field checked: `{"text":"A😀|rock'roll|終","selection":[13,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|rock'roll |終","selection":[14,0]}`

   Every asserted field checked: `{"text":"A😀|rock'roll |終","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

5. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|rock'roll  |終","selection":[15,0]}`

   Every asserted field checked: `{"text":"A😀|rock'roll  |終","selection":[15,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|rock'roll |終","selection":[14,0]}`

   Every asserted field checked: `{"text":"A😀|rock'roll |終","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"😀z"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|rock'roll 😀z|終","selection":[17,0]}`

   Every asserted field checked: `{"text":"A😀|rock'roll 😀z|終","selection":[17,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|rock'roll 😀|終","selection":[16,0]}`

   Every asserted field checked: `{"text":"A😀|rock'roll 😀|終","selection":[16,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

9. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"pre😀|abcd|終tail","selection":[7,2],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"pre😀|abcd|終tail","selection":[7,2]}`

   Every asserted field checked: `{"text":"pre😀|abcd|終tail","selection":[7,2],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

10. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"pre😀|ad|終tail","selection":[7,0]}`

   Every asserted field checked: `{"text":"pre😀|ad|終tail","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

11. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"'!"}`

   Calculated complete document/UTF16 selection: `{"text":"pre😀|a'!d|終tail","selection":[9,0]}`

   Every asserted field checked: `{"text":"pre😀|a'!d|終tail","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"pre😀|a'! d|終tail","selection":[10,0]}`

   Every asserted field checked: `{"text":"pre😀|a'! d|終tail","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

#### es

Initial complete text `"A😀|mañana|終"`; UTF16 selection `[4,6]`; field `{"id":"birthdate","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"luz"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|luz|終","selection":[7,0]}`

   Every asserted field checked: `{"text":"A😀|luz|終","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

2. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"'"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|luz'|終","selection":[8,0]}`

   Every asserted field checked: `{"text":"A😀|luz'|終","selection":[8,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"sol"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|luz'sol|終","selection":[11,0]}`

   Every asserted field checked: `{"text":"A😀|luz'sol|終","selection":[11,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|luz'sol |終","selection":[12,0]}`

   Every asserted field checked: `{"text":"A😀|luz'sol |終","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

5. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|luz'sol  |終","selection":[13,0]}`

   Every asserted field checked: `{"text":"A😀|luz'sol  |終","selection":[13,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|luz'sol |終","selection":[12,0]}`

   Every asserted field checked: `{"text":"A😀|luz'sol |終","selection":[12,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"😀z"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|luz'sol 😀z|終","selection":[15,0]}`

   Every asserted field checked: `{"text":"A😀|luz'sol 😀z|終","selection":[15,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|luz'sol 😀|終","selection":[14,0]}`

   Every asserted field checked: `{"text":"A😀|luz'sol 😀|終","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

9. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"izq😀|abcd|終fin","selection":[7,2],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"izq😀|abcd|終fin","selection":[7,2]}`

   Every asserted field checked: `{"text":"izq😀|abcd|終fin","selection":[7,2],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

10. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"izq😀|ad|終fin","selection":[7,0]}`

   Every asserted field checked: `{"text":"izq😀|ad|終fin","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

11. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"'!"}`

   Calculated complete document/UTF16 selection: `{"text":"izq😀|a'!d|終fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"izq😀|a'!d|終fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"izq😀|a'! d|終fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"izq😀|a'! d|終fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

#### en_es

Initial complete text `"A😀|later|終"`; UTF16 selection `[4,5]`; field `{"id":"birthdate","route":"native","keyboard":"standard","secure":false}`: validated.

1. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"hello"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|hello|終","selection":[9,0]}`

   Every asserted field checked: `{"text":"A😀|hello|終","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

2. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"'"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|hello'|終","selection":[10,0]}`

   Every asserted field checked: `{"text":"A😀|hello'|終","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

3. **type — validated-static**. All six check groups passed.

   Arguments: `{"text":"hola"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|hello'hola|終","selection":[14,0]}`

   Every asserted field checked: `{"text":"A😀|hello'hola|終","selection":[14,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

4. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|hello'hola |終","selection":[15,0]}`

   Every asserted field checked: `{"text":"A😀|hello'hola |終","selection":[15,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

5. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|hello'hola  |終","selection":[16,0]}`

   Every asserted field checked: `{"text":"A😀|hello'hola  |終","selection":[16,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

6. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|hello'hola |終","selection":[15,0]}`

   Every asserted field checked: `{"text":"A😀|hello'hola |終","selection":[15,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

7. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"😀z"}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|hello'hola 😀z|終","selection":[18,0]}`

   Every asserted field checked: `{"text":"A😀|hello'hola 😀z|終","selection":[18,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

8. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"A😀|hello'hola 😀|終","selection":[17,0]}`

   Every asserted field checked: `{"text":"A😀|hello'hola 😀|終","selection":[17,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

9. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"pre😀|abcd|終fin","selection":[7,2],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"pre😀|abcd|終fin","selection":[7,2]}`

   Every asserted field checked: `{"text":"pre😀|abcd|終fin","selection":[7,2],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

10. **delete — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"pre😀|ad|終fin","selection":[7,0]}`

   Every asserted field checked: `{"text":"pre😀|ad|終fin","selection":[7,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

11. **insert — validated-static**. All six check groups passed.

   Arguments: `{"text":"'!"}`

   Calculated complete document/UTF16 selection: `{"text":"pre😀|a'!d|終fin","selection":[9,0]}`

   Every asserted field checked: `{"text":"pre😀|a'!d|終fin","selection":[9,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

12. **space — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"pre😀|a'! d|終fin","selection":[10,0]}`

   Every asserted field checked: `{"text":"pre😀|a'! d|終fin","selection":[10,0],"private":true,"plain":false,"suggestionsEmpty":true,"totalCount":0,"touchWeight":0.0,"allowsConfirmation":false}`

### 16. r38-guard-late-private-and-invalidate — validated-static

Normal origin to late private before fired refusals; explicit invalidation persists after normal restoration.

#### en_US

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"plain":false,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

3. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

4. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"refused"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

6. **invalidateGuard — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"automaticCore":false,"automaticNative":false}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false}`

8. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"still blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

#### es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"plain":false,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

3. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

4. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"bloqueado"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"rechazado"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

6. **invalidateGuard — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"automaticCore":false,"automaticNative":false}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false}`

8. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"still blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

#### en_es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

2. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"oneTimeCode","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"plain":false,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

3. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

4. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"blocked hola"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"refused hola"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

6. **invalidateGuard — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":true,"automaticCore":false,"automaticNative":false}`

7. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"name","route":"native","keyboard":"standard","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false}`

8. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"still blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"text":"","selection":[0,0],"private":false,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

### 17. r38-guard-context-identity-selection — validated-static

Both-context mismatch, changed identity and selection each have fired refusals.

#### en_US

Initial complete text `"left|right"`; UTF16 selection `[5,0]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"left|right","selection":[5,0]}`

   Every asserted field checked: `{"text":"left|right","selection":[5,0],"private":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

2. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"else|where","selection":[5,0],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[5,0]}`

   Every asserted field checked: `{"text":"else|where","selection":[5,0],"private":false,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false}`

3. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[5,0]}`

   Every asserted field checked: `{"text":"else|where","selection":[5,0],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

4. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[5,0]}`

   Every asserted field checked: `{"text":"else|where","selection":[5,0],"automaticCore":true,"automaticNative":false}`

5. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"else|where","selection":[5,0],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[5,0]}`

   Every asserted field checked: `{"text":"else|where","selection":[5,0],"automaticCore":false,"automaticNative":false}`

6. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"identity blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[5,0]}`

   Every asserted field checked: `{"text":"else|where","selection":[5,0],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

7. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[5,0]}`

   Every asserted field checked: `{"text":"else|where","selection":[5,0],"automaticCore":true,"automaticNative":false}`

8. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"else|where","selection":[0,1],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[0,1]}`

   Every asserted field checked: `{"text":"else|where","selection":[0,1],"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

9. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"selection blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[0,1]}`

   Every asserted field checked: `{"text":"else|where","selection":[0,1],"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

10. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"selection blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"else|where","selection":[0,1]}`

   Every asserted field checked: `{"text":"else|where","selection":[0,1],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

#### es

Initial complete text `"izq|der"`; UTF16 selection `[4,0]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"izq|der","selection":[4,0]}`

   Every asserted field checked: `{"text":"izq|der","selection":[4,0],"private":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

2. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"otro|sitio","selection":[5,0],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[5,0]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[5,0],"private":false,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false}`

3. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[5,0]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[5,0],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

4. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[5,0]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[5,0],"automaticCore":true,"automaticNative":false}`

5. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"otro|sitio","selection":[5,0],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[5,0]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[5,0],"automaticCore":false,"automaticNative":false}`

6. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"identity blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[5,0]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[5,0],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

7. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[5,0]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[5,0],"automaticCore":true,"automaticNative":false}`

8. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"otro|sitio","selection":[0,1],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[0,1]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[0,1],"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

9. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"selection blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[0,1]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[0,1],"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

10. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"selection blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"otro|sitio","selection":[0,1]}`

   Every asserted field checked: `{"text":"otro|sitio","selection":[0,1],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

#### en_es

Initial complete text `"left|der"`; UTF16 selection `[5,0]`; field `{"id":"name","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"left|der","selection":[5,0]}`

   Every asserted field checked: `{"text":"left|der","selection":[5,0],"private":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false}`

2. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"other|sitio","selection":[6,0],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[6,0]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[6,0],"private":false,"allowsConfirmation":true,"automaticCore":false,"automaticNative":false}`

3. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[6,0]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[6,0],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

4. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[6,0]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[6,0],"automaticCore":true,"automaticNative":false}`

5. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"other|sitio","selection":[6,0],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[6,0]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[6,0],"automaticCore":false,"automaticNative":false}`

6. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"identity blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[6,0]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[6,0],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

7. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[6,0]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[6,0],"automaticCore":true,"automaticNative":false}`

8. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"other|sitio","selection":[0,1],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[0,1]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[0,1],"allowsConfirmation":false,"automaticCore":false,"automaticNative":false}`

9. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"selection blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[0,1]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[0,1],"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false}`

10. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"selection blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"other|sitio","selection":[0,1]}`

   Every asserted field checked: `{"text":"other|sitio","selection":[0,1],"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false}`

### 18. r38-normal-guard-permission-confirmation-refusals — validated-static

Normal matching empty automatic permission control; standard/numeric confirmation permission reads; selected/secure refusals; no origin permanence or nonempty spacing assumption.

#### en_US

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"text":"","selection":[0,0]}`

2. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":""}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"acceptedCore":true,"acceptedNative":false,"text":"","selection":[0,0]}`

3. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"text":"","selection":[0,0]}`

4. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Ready.","selection":[0,1],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[0,1]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"text":"Ready.","selection":[0,1]}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"blocked"}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[0,1]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false,"text":"Ready.","selection":[0,1]}`

6. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Ready.","selection":[6,0],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[6,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"text":"Ready.","selection":[6,0]}`

7. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[6,0]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":true,"text":"Ready.","selection":[6,0]}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[6,0]}`

   Every asserted field checked: `{"private":false,"plain":false,"allowsConfirmation":true,"text":"Ready.","selection":[6,0]}`

9. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[6,0]}`

   Every asserted field checked: `{"private":false,"plain":false,"allowsConfirmation":true,"text":"Ready.","selection":[6,0]}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[6,0]}`

   Every asserted field checked: `{"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"text":"Ready.","selection":[6,0]}`

11. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[6,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false,"text":"Ready.","selection":[6,0]}`

12. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[6,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"text":"Ready.","selection":[6,0]}`

13. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"8"}`

   Calculated complete document/UTF16 selection: `{"text":"Ready.","selection":[6,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false,"text":"Ready.","selection":[6,0]}`

#### es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"text":"","selection":[0,0]}`

2. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":""}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"acceptedCore":true,"acceptedNative":false,"text":"","selection":[0,0]}`

3. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"text":"","selection":[0,0]}`

4. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Listo.","selection":[0,1],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[0,1]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"text":"Listo.","selection":[0,1]}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"rechazado"}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[0,1]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false,"text":"Listo.","selection":[0,1]}`

6. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Listo.","selection":[6,0],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[6,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"text":"Listo.","selection":[6,0]}`

7. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[6,0]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":true,"text":"Listo.","selection":[6,0]}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[6,0]}`

   Every asserted field checked: `{"private":false,"plain":false,"allowsConfirmation":true,"text":"Listo.","selection":[6,0]}`

9. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[6,0]}`

   Every asserted field checked: `{"private":false,"plain":false,"allowsConfirmation":true,"text":"Listo.","selection":[6,0]}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[6,0]}`

   Every asserted field checked: `{"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"text":"Listo.","selection":[6,0]}`

11. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[6,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false,"text":"Listo.","selection":[6,0]}`

12. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[6,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"text":"Listo.","selection":[6,0]}`

13. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"8"}`

   Calculated complete document/UTF16 selection: `{"text":"Listo.","selection":[6,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false,"text":"Listo.","selection":[6,0]}`

#### en_es

Initial complete text `""`; UTF16 selection `[0,0]`; field `{"id":"none","route":"native","keyboard":"standard","secure":false}`: validated.

1. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"text":"","selection":[0,0]}`

2. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":""}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"acceptedCore":true,"acceptedNative":false,"text":"","selection":[0,0]}`

3. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"","selection":[0,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"automaticCore":true,"automaticNative":false,"text":"","selection":[0,0]}`

4. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Hola ready.","selection":[0,1],"newIdentity":true}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[0,1]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"text":"Hola ready.","selection":[0,1]}`

5. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"blocked hola"}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[0,1]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false,"text":"Hola ready.","selection":[0,1]}`

6. **host — validated-static**. All six check groups passed.

   Arguments: `{"text":"Hola ready.","selection":[11,0],"newIdentity":false}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[11,0]}`

   Every asserted field checked: `{"private":false,"plain":true,"allowsConfirmation":true,"text":"Hola ready.","selection":[11,0]}`

7. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[11,0]}`

   Every asserted field checked: `{"private":false,"allowsConfirmation":true,"text":"Hola ready.","selection":[11,0]}`

8. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":false}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[11,0]}`

   Every asserted field checked: `{"private":false,"plain":false,"allowsConfirmation":true,"text":"Hola ready.","selection":[11,0]}`

9. **destination — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[11,0]}`

   Every asserted field checked: `{"private":false,"plain":false,"allowsConfirmation":true,"text":"Hola ready.","selection":[11,0]}`

10. **field — validated-static**. All six check groups passed.

   Arguments: `{"field":{"id":"none","route":"native","keyboard":"numberPad","secure":true}}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[11,0]}`

   Every asserted field checked: `{"private":true,"plain":false,"suggestionsEmpty":true,"allowsConfirmation":false,"text":"Hola ready.","selection":[11,0]}`

11. **confirm — validated-static**. All six check groups passed.

   Arguments: `{"text":"7"}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[11,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"acceptedCore":false,"acceptedNative":false,"text":"Hola ready.","selection":[11,0]}`

12. **guardOrigin — validated-static**. All six check groups passed.

   Arguments: `{}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[11,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"text":"Hola ready.","selection":[11,0]}`

13. **automatic — validated-static**. All six check groups passed.

   Arguments: `{"text":"8"}`

   Calculated complete document/UTF16 selection: `{"text":"Hola ready.","selection":[11,0]}`

   Every asserted field checked: `{"private":true,"allowsConfirmation":false,"automaticCore":false,"automaticNative":false,"acceptedCore":false,"acceptedNative":false,"text":"Hola ready.","selection":[11,0]}`
