#!/usr/bin/env python3
"""R44 post-reveal raw-artifact review. No imports of audit scorers, execution,
builds, device access, or writes. Default emits complete JSON; --summary is terse.
This implements the frozen relations after reveal, not evidence of a preseal gate.
"""
import collections
import gzip
import hashlib
import json
import math
import pathlib
import subprocess
import sys
import xml.etree.ElementTree as ET

P = pathlib.Path(__file__).resolve().parent
ROOT = P.parents[3]
def read(name):
    def unique(items):
        result = {}
        for k, v in items:
            assert k not in result, (name, "duplicate key", k)
            result[k] = v
        return result
    return json.loads((P / name).read_text(), object_pairs_hook=unique,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def sha(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)

data = read("heldout-v3.json")
cases = data["cases"]
B, C = read("heldout-baseline.json"), read("heldout-candidate.json")
assert len({x['id'] for x in cases}) == len(cases)
manifest = [(x['id'], x['language'], i, op['op'])
            for x in cases for i, op in enumerate(x['ops'])]
ledger = []
for label, rows in [('baseline', B), ('candidate', C)]:
    assert [(r['id'], r['language'], r['index'], r['op']) for r in rows] == manifest
    table = {(r['id'], r['index']): r for r in rows}
    for case in cases:
        for i in range(len(case['ops'])):
            r=table[case['id'],i]
            assert set(r['counts'])==set(case['watch'])
            assert len(r['pairs'])==len(case['pairs'])
    checks = []
    for case in cases:
        assert [e['index'] for e in case['expect']] == list(range(len(case['ops'])))
        for exp in case['expect']:
            row = table[case['id'], exp['index']]
            for key, want in exp.items():
                if key == 'index':
                    continue
                actual = row.get(key)
                if key == 'counts':
                    passed = all(row['counts'].get(k) == v for k, v in want.items())
                elif key == 'weight':
                    passed = isinstance(actual, (int, float)) and abs(actual-want) <= 1e-9
                elif key in ('weightMin', 'weightMax', 'costMax', 'costLessThanIndex'):
                    raise AssertionError('Unexpected bound in sealed v3: ' + key)
                else:
                    passed = actual == want
                checks.append(dict(id=case['id'], index=exp['index'], key=key,
                                   expected=want, actual=actual, passed=passed))
    ledger.append(checks)
tables = [{(int(r['id'].split('-')[1]), r['index']): r for r in rows} for rows in (B, C)]
def row(v, n, i):
    return tables[v][n, i]
def touch(r):
    assert type(r['weight']) in (int, float) and math.isfinite(r['weight']) and r['weight'] >= 0
    offsets = r['offsets']
    assert len(offsets) == 26 and all(len(a) == 2 for a in offsets)
    assert all(type(v) in (int, float) and math.isfinite(v) for a in offsets for v in a)
    return [r['weight'], offsets]
for r in B + C:
    touch(r)
def T(v,n,i):
    return touch(row(v,n,i))
def delta(v,n,a,b):
    return row(v,n,b)['weight'] - row(v,n,a)['weight']
relations = []
def relation(name, ok, **detail):
    relations.append(dict(name=name, passed=bool(ok), **detail))
matches = [(41,0,1,1,0,1),(2,1,2,42,0,1),(2,1,2,43,1,2),
           (7,0,1,44,0,1),(8,0,1,45,0,1),(65,0,1,45,0,1),
           (9,0,1,46,0,1),(11,1,2,47,1,2),(23,2,3,48,2,3),
           (49,0,1,24,0,1),(25,0,1,50,0,1),(26,0,1,51,0,1),
           (31,2,3,52,2,3),(53,0,1,32,0,1),(33,0,1,54,0,1),
           (34,2,3,55,2,3),(67,0,1,68,0,1),(69,0,1,70,0,1),(2,8,9,43,8,9)]
for n,a,b,s,x,y in matches:
    for v in (0,1):
        relation(f'match {n}:{a}->{b} vs {s}:{x}->{y} reference {v}',
                 T(1,n,a)==T(v,s,x) and T(1,n,b)==T(v,s,y)
                 and delta(1,n,a,b)==delta(v,s,x,y),
                 conditionalAccent=n in (25,67,69))
    relation(f'Space reference unchanged {s}:{x},{y}',
             T(0,s,x)==T(1,s,x) and T(0,s,y)==T(1,s,y))
pools = {'en_US': [(1,0,1),(42,0,1),(44,0,1),(45,0,1),(46,0,1),(47,1,2),(48,0,1),(48,2,3)],
         'es': [(24,0,1),(51,0,1),(52,0,1),(52,2,3)],
         'en_es': [(32,0,1),(54,0,1),(55,0,1),(55,2,3)]}
positives = {}
for lang,pool in pools.items():
    positives[lang] = []
    for v in (0,1):
        values = [delta(v,*item) for item in pool]
        positives[lang].append(values)
        relation(f'{lang} positive coverage variant {v}',sum(x>0 for x in values)>=3)
for v in (0,1):
    for n,a,b in [(48,2,3),(52,2,3),(55,2,3),(32,0,1),(54,0,1),(43,1,2),(43,8,9)]:
        relation(f'mandatory positive {v}/{n}:{a}->{b}', delta(v,n,a,b)>0)
for n,anchor,indices,variants in [(2,2,range(3,9),(1,)),(23,3,range(4,7),(1,)),
                                    (34,3,[4],(1,)),(43,2,range(3,9),(0,1)),
                                    (48,3,range(4,7),(0,1)),(55,3,[4],(0,1))]:
    for v in variants:
        for i in indices:
            relation(f'no follow-on update {v}/{n}:{i}',T(v,n,i)==T(v,n,anchor))
zero_cases = [3,4,5,6,10,12,13,14,15,18,19,20,21,22,27,28,29,37,38,39,61,62,63,64,66]
for v in (0,1):
    for n in zero_cases:
        for i in range(len(cases[n-1]['ops'])):
            relation(f'zero touch {v}/{n}:{i}',T(v,n,i)==[0,[[0,0] for _ in range(26)]])
    relation(f'correction freeze {v}/36',all(T(v,36,i)==T(v,36,0) for i in range(3)))
    for n in (11,47):
        relation(f'empty payload {v}/{n}',T(v,n,0)==T(v,n,1))
preservation = []
raw_differences = []
base_keys = ['text','cursor','selection','total','counts','pairs','learns']
for old,new in zip(B,C):
    for k in base_keys + (['decoded','autocorrection','slots','cost'] if old['op']=='probe' else []):
        if old[k] != new[k]:
            preservation.append(dict(id=old['id'],index=old['index'],key=k,baseline=old[k],candidate=new[k]))
    changes = [k for k in old if old[k]!=new[k]]
    if changes:
        raw_differences.append(dict(id=old['id'],index=old['index'],keys=changes,
                                    baselineTouch=touch(old),candidateTouch=touch(new)))
allowed = {2:range(2,10),7:[1],8:[1],9:[1],11:[2],23:range(3,7),25:[1],26:[1],
           31:[3],33:[1],34:[3,4],41:[1],49:[1],53:[1],65:[1],67:[1],69:[1]}
diagnostic_cases = [16,17,30,35,40,56,57,58,59,60]
diagnostics = []
for n in range(1,71):
    for i in range(len(cases[n-1]['ops'])):
        if n in diagnostic_cases:
            diagnostics.append(dict(case=n,index=i,baseline=T(0,n,i),candidate=T(1,n,i)))
        elif i not in allowed.get(n,[]):
            relation(f'unchanged touch {n}:{i}',T(0,n,i)==T(1,n,i))
freeze,seal,proc = read('source-binary-freeze.json'),read('seal.json'),read('paired-process.json')
provenance = []
def attest(name,ok):
    provenance.append(dict(name=name,matched=ok))
for name,want in seal['files'].items():
    attest('seal/'+name,sha((P/name).read_bytes())==want)
candidate='e5d03a77931d1761ffa4d3e44ce0a23e266b039c'
parent=freeze['baseCommit']
for name,want in freeze['files'].items():
    path=ROOT/name
    if '/audits/' in name:
        observed=path.read_bytes()
    else:
        observed=git('show',candidate+':'+name)
    attest('candidate freeze/'+name,sha(observed)==want)
    if '/LanguageData/' in name or '/Sources/KeyboardUI/' in name:
        attest('current resource/UI/'+name,sha(path.read_bytes())==want)
    if '/Sources/KeyboardCore/' in name and not name.endswith('/KeyboardEngine.swift'):
        attest('other Core unchanged/'+name,git('show',parent+':'+name)==observed)
for path,want in freeze['binaries'].items():
    archive='baseline.gz' if 'baseline' in path else 'candidate.gz'
    attest('binary/'+archive,sha(gzip.decompress((P/'binaries'/archive).read_bytes()))==want)
engine='apps/keyboard-ios/PulpoKeyboardKit/Sources/KeyboardCore/Input/KeyboardEngine.swift'
attest('candidate snapshot',git('show',candidate+':'+engine)==(P/'candidate-KeyboardEngine.swift.txt').read_bytes())
attest('baseline snapshot',git('show',parent+':'+engine)==(P/'baseline-KeyboardEngine.swift.txt').read_bytes())
attest('exact retained patch',git('diff',parent,candidate)==(P/'implementation.patch').read_bytes())
attest('revert restores tracked tree',git('rev-parse',parent+'^{tree}')==git('rev-parse','83f22439630629860c7653ea3017b8b3fd953331^{tree}'))
attest('process statuses',proc['preflight']['exit']==0 and len(proc['runs'])==2 and
       all(x['exit']==0 and x['stderr']=='' and x['outputExists'] for x in proc['runs']))
attest('source freeze digest',sha((P/'source-binary-freeze.json').read_bytes())==read('production-commit.json')['sourceBinaryFreezeSHA256'])
for name, entry in read('protected-source-check.json').items():
    attest('protected/'+name,sha(git('show',parent+':'+name))==entry['sha256'] and
           git('show',parent+':'+name)==git('show',candidate+':'+name))
native_provenance=read('native-binary-provenance.json')
attest('native provenance freeze',native_provenance['sourceFreezeSHA256']==sha((P/'source-binary-freeze.json').read_bytes()))
for name,want in native_provenance['paths'].items():
    path=pathlib.Path(name)
    attest('native binary/'+name,path.exists() and sha(path.read_bytes())==want)
native = {}
for name in ['native-baseline.json','native-sealable.json','native-final.json']:
    native[name]=[dict(language=r['language'],route=r['route'],weight=r['weight'],
                       count=r['count'],text=r['text']) for r in read(name)]
native_raw=read('native-final.json')
for lang in pools:
    routes={r['route']:r for r in native_raw if r['language']==lang}
    attest('native final touch parity/'+lang, all(touch(routes[k])==touch(routes['space']) for k in ['picker','search']))
adapt_input=read('adaptation-v2-input.json')
adapt_B,adapt_C=read('adaptation-v2-baseline.json'),read('adaptation-final-candidate.json')
adapt_expected=[(c['id'],c['language'],i,o['op']) for c in adapt_input['cases'] for i,o in enumerate(c['ops'])]
for rows in (adapt_B,adapt_C):
    assert [(r['id'],r['language'],r['index'],r['op']) for r in rows]==adapt_expected
adaptation=[]
for old,new in zip(adapt_B,adapt_C):
    if old['op']=='probe' and 'external' in old['id']:
        adaptation.append(dict(id=old['id'],index=old['index'],intended=old['intended'],
                               decoded=new['decoded'],baselineCost=old['cost'],candidateCost=new['cost'],
                               baselineOffer=old['autocorrection'],candidateOffer=new['autocorrection']))
adapt_table={(r['id'],r['index']):r for r in adapt_C}
adaptation_parity=[]
for case in adapt_input['cases']:
    if 'external' not in case['id']:
        continue
    other=case['id'].replace('external','space')
    index=max(i for i,o in enumerate(case['ops']) if o['op']=='external')
    a,b=adapt_table[case['id'],index],adapt_table[other,index]
    adaptation_parity.append(dict(language=case['language'],weight=a['weight'],
                                 allTouchEqual=touch(a)==touch(b),counts=a['counts']))
    # Independently derive all offsets for the 32 x 5 equal-offset labels.
    word='music' if case['language']=='en_US' else 'mundo'
    frequency=collections.Counter(word)
    expected=[]
    for letter in 'abcdefghijklmnopqrstuvwxyz':
        w=32*frequency[letter]
        expected.append([(w*d+12*(160*d/184))/(w+12) for d in (.1,.4)])
    adaptation_parity[-1]['formulaMaxError']=max(abs(x-y) for a,b in zip(a['offsets'],expected) for x,y in zip(a,b))
tests=[]
for path in sorted(P.glob('*testing.xml.gz')):
    tree=ET.fromstring(gzip.decompress(path.read_bytes()))
    items=list(tree.iter('testcase'))
    tests.append(dict(file=path.name,cases=len(items),skipped=sum(x.find('skipped') is not None for x in items),
                      failures=[dict(test=x.attrib,messages=[e.attrib for e in x.findall('failure')+x.findall('error')])
                                for x in items if x.find('failure') is not None or x.find('error') is not None]))
result = dict(cases=len(cases), rowsPerVariant=len(B), checkpoints=sum(len(c['expect']) for c in cases),
              resourceCases=dict(collections.Counter(c['language'] for c in cases)),
              resourceRows=dict(collections.Counter(r['language'] for r in B)),
              rawChecks=ledger,gains=[b for a,b in zip(*ledger) if not a['passed'] and b['passed']],
              losses=[b for a,b in zip(*ledger) if a['passed'] and not b['passed']],
              preservationKeys=base_keys,preservationDifferences=preservation,
              rawDifferences=raw_differences,relations=relations,positiveIncrements=positives,
              diagnostics=diagnostics,provenance=provenance,native=native,adaptation=adaptation,
              adaptationParity=adaptation_parity,retainedTests=tests,
              inactivePatchSHA256=sha((P/'implementation.patch').read_bytes()))
if '--summary' in sys.argv:
    result.pop('rawChecks')
    result['scores']=[dict(checks=len(x),passed=sum(y['passed'] for y in x),failed=[y for y in x if not y['passed']]) for x in ledger]
    result['relationCount']=len(relations)
    result['relations']=[x for x in relations if not x['passed']]
    result['provenanceCount']=len(provenance)
    result['provenance']=[x for x in provenance if not x['matched']]
    result['rawDifferences']=[dict(id=x['id'],index=x['index'],keys=x['keys'],baselineWeight=x['baselineTouch'][0],candidateWeight=x['candidateTouch'][0]) for x in raw_differences]
    result['diagnostics']=[dict(case=x['case'],index=x['index'],baselineWeight=x['baseline'][0],candidateWeight=x['candidate'][0]) for x in diagnostics]
print(json.dumps(result,ensure_ascii=False,indent=2))
