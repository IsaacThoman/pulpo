import Foundation

// Independent implementation of the public R48 specification only.
// No product import/calls, learning formula, storage, cases or results.
func publicKeyReference(_ input: String) -> String {
  let scalars: [Unicode.Scalar]
  if input.unicodeScalars.allSatisfy({ $0.value < 128 }) {
    scalars = input.unicodeScalars.compactMap { scalar in
      if scalar.value == 39 { return nil }
      let value = scalar.value
      return Unicode.Scalar((65...90).contains(value) ? value + 32 : value)
    }
  } else {
    let decomposed = input.lowercased().decomposedStringWithCompatibilityMapping
    scalars = decomposed.unicodeScalars.filter {
      $0.value != 39 && $0.value != 0x2019 && $0.properties.generalCategory != .nonspacingMark
    }
  }
  return String(String.UnicodeScalarView(scalars))
}

struct PublicReferenceAlignment {
  let characters: [String]
  let typedBytes: [UInt8]
  let origins: [Int]
  let targetBytes: [UInt8]
  var lengthMatches: Bool { targetBytes.count >= 2 && typedBytes.count == targetBytes.count }

  // Pure structural contribution selection. Nil denotes an absent point;
  // true/false denotes finite/nonfinite displacement at an available point.
  // Unknown extra entries are never indexed beyond original Characters.
  func contributingOrigins(finitePoints: [Bool?]) -> [Int]? {
    guard lengthMatches else { return nil }
    var result: [Int] = []
    for (i, byte) in targetBytes.enumerated() where (97...122).contains(byte) {
      let origin = origins[i]
      let finite = origin < finitePoints.count ? finitePoints[origin] : nil
      guard let finite else { continue }
      guard finite else { return nil }
      result.append(origin)
    }
    return result.isEmpty ? nil : result
  }
}

func publicAlignmentReference(text: String, target: String) -> PublicReferenceAlignment {
  let characters = text.map(String.init)
  var bytes: [UInt8] = []
  var origins: [Int] = []
  for (i, character) in characters.enumerated() {
    let part = Array(publicKeyReference(character).utf8)
    bytes += part
    origins += Array(repeating: i, count: part.count)
  }
  return PublicReferenceAlignment(characters: characters, typedBytes: bytes,
                                  origins: origins, targetBytes: Array(publicKeyReference(target).utf8))
}
import Foundation
let root = URL(fileURLWithPath: "/tmp/pulpo-r48-fresh-author-v2")
let data = try Data(contentsOf: root.appendingPathComponent("design.json"))
let design = try JSONSerialization.jsonObject(with: data) as! [String: Any]
var refs: [[String: Any]] = []
for family in design["families"] as! [[String: Any]] {
  let normalizationInput = family["normalizationInput"] as! String
  var alignments: [[String: Any]] = []
  for step in family["steps"] as! [[String: Any]] where step["op"] as! String == "learn" {
    let a = publicAlignmentReference(text: step["text"] as! String, target: step["target"] as! String)
    let taps = step["taps"] as! [Any]
    let finite: [Bool?] = taps.map { t in
      guard let d = t as? [String: Any] else { return nil }
      if d["base"] != nil { return true }
      return d["x"] is NSNumber && d["y"] is NSNumber
    }
    let contributing = a.contributingOrigins(finitePoints: finite)
    alignments.append(["characters": a.characters, "typedBytes": a.typedBytes.map(Int.init), "origins": a.origins, "targetBytes": a.targetBytes.map(Int.init), "contributingOrigins": contributing as Any? ?? NSNull()])
  }
  refs.append(["id": family["id"]!, "normalized": publicKeyReference(normalizationInput), "alignments": alignments])
}
let result = try JSONSerialization.data(withJSONObject: refs, options: [.prettyPrinted, .sortedKeys, .fragmentsAllowed])
try result.write(to: root.appendingPathComponent("reference-values.json"))
