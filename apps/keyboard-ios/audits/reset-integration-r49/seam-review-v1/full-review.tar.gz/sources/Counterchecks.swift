import Foundation
import CryptoKit

enum CheckError: Error { case failed(String) }
func need(_ value: Bool, _ message: String) throws { if !value { throw CheckError.failed(message) } }
@main struct Counterchecks {
  static func main() throws {
    let fm = FileManager.default
    let root = fm.temporaryDirectory.appendingPathComponent("pulpo-r49-parent-countercheck-" + UUID().uuidString, isDirectory: true)
    try fm.createDirectory(at: root, withIntermediateDirectories: false)
    defer { try? fm.removeItem(at: root) }
    var reports: [[String:Any]] = []
    var reads = 0
    let diagnostic: (String,String) -> Void = { stage,_ in if stage == "beforeRead" { reads += 1 } }
    func rejection(_ id: String, _ reason: String, body: () throws -> Void) throws {
      reads = 0
      do { try body(); throw CheckError.failed(id + " accepted") }
      catch InventoryError.invalid(let actual) {
        try need(actual == reason && reads == 0, id + " wrong error/read ordering")
        reports.append(["id":id,"pass":true,"reason":actual,"contentReadAttempts":reads])
      }
    }
    let file = root.appendingPathComponent("file")
    try Data([1,2,3]).write(to: file)
    try rejection("regular-file-root", "inventory root directory") { _ = try inventoryRegularFiles(file,diagnostic:diagnostic) }
    try rejection("non-file-root", "inventory nonfile root") { _ = try inventoryRegularFiles(URL(string:"https://example.invalid/owned")!,diagnostic:diagnostic) }
    let fifo = root.appendingPathComponent("fifo")
    let status = fifo.path.withCString { mkfifo($0, 0o600) }
    try need(status == 0,"owned FIFO creation failed")
    try rejection("FIFO-unsupported-before-read", "inventory nonregular entry") {
      var collector = try InventoryCollector(root:root,diagnostic:diagnostic);try collector.visit(fifo)
    }
    try fm.removeItem(at:fifo)
    let canonical = inventoryCanonicalURL(root)
    let alias: URL
    if canonical.path.hasPrefix("/var/") { alias = URL(fileURLWithPath:"/private" + canonical.path,isDirectory:true) }
    else if canonical.path.hasPrefix("/private/var/") { alias = URL(fileURLWithPath:String(canonical.path.dropFirst("/private".count)),isDirectory:true) }
    else { throw CheckError.failed("this runtime does not expose expected actual temp alias") }
    var collector = try InventoryCollector(root:canonical,diagnostic:diagnostic)
    try collector.visit(canonical.appendingPathComponent("file"))
    try rejection("duplicate-through-opposite-system-alias", "inventory duplicate") { try collector.visit(alias.appendingPathComponent("file")) }
    let empty = root.appendingPathComponent("empty",isDirectory:true)
    try fm.createDirectory(at:empty,withIntermediateDirectories:false)
    let nested = empty.appendingPathComponent("nested",isDirectory:true)
    try fm.createDirectory(at:nested,withIntermediateDirectories:false)
    try need(try inventoryRegularFiles(empty).isEmpty,"empty nested directory gained a regular row")
    reports.append(["id":"empty-nested-directories","pass":true])
    let result: [String:Any] = ["scope":"Foundation/CryptoKit and owned disposable files only; exact unchanged Inventory.swift; no product calls","root":root.path,"probeCount":reports.count,"probes":reports,"newProductExecutions":0,"cleanup":"defer removes only own UUID root"]
    print(String(decoding:try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]),as:UTF8.self))
  }
}
