import Foundation
import Testing
@testable import KeyboardCore

struct EmojiLocalizedSearchTests {
  private func index(_ entries: [Emoji]) -> EmojiSuggester {
    EmojiSuggester(catalog: EmojiCatalog(version: "fixture", categories: [
      EmojiCategory(id: "fixture", name: "Fixture", emoji: entries),
    ]))
  }
  private func englishOnly(_ entries: [Emoji]) -> EmojiSuggester {
    index(entries.map { Emoji(value: $0.value, name: $0.name, version: $0.version,
                              tones: $0.tones, keywords: $0.keywords) })
  }

  @Test func spanishAndMixedIntentsFindExistingEmoji() {
    let search = EmojiSuggesterTests.suggester
    for (spanish, mixed, target) in [
      ("corazón rojo", "red corazón", "❤️"), ("gato negro", "black gato", "🐈‍⬛"),
      ("montaña con nieve", "snow montaña", "🏔️"), ("enchufe eléctrico", "electric enchufe", "🔌"),
      ("balón de fútbol", "soccer balón", "⚽"), ("ratón de ordenador", "computer ratón", "🖱️"),
      ("coche de bomberos", "fire coche", "🚒"), ("helado", "ice helado", "🍨"),
      ("tren bala", "bullet tren", "🚅"), ("libro abierto", "open libro", "📖"),
      ("paraguas cerrado", "closed paraguas", "🌂"), ("auricular de teléfono", "receiver teléfono", "📞"),
    ] {
      #expect(search.search(spanish).map(\.value).contains(target), "\(spanish)")
      #expect(search.search(mixed).map(\.value).contains(target), "\(mixed)")
    }
    #expect(search.search("red corazón", limit: 1).first?.value == "❤️")
    #expect(search.search("gato perro xyz").isEmpty)
  }

  @Test func internalEnglishSubstringsLeaveLocalizedCapacityAtEveryCap() {
    for token in ["ñ", "ç", "ł", "β", "n\u{093E}", "n\u{034F}", "n\u{20DD}"] {
      let folded = token.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX"))
      let entries = (0..<86).map {
        Emoji(value: "L\($0)", name: "zz\(folded)zz beacon item\($0)", version: 1,
              tones: nil, spanishName: token + "avoru")
      }
      let search = index(entries)
      for cap in [1, 48, 60] {
        for query in [token, token.uppercased(), token.decomposedStringWithCanonicalMapping, token + " " + token] {
          #expect(search.search(query, limit: cap).map(\.value) == (0..<cap).map { "L\($0)" })
        }
      }
    }
  }

  @Test func orthographyDistinguishesConsonantsAndFoldsVowelMarks() {
    let search = index([
      Emoji(value: "N", name: "opaque", version: 1, tones: nil, spanishName: "pina"),
      Emoji(value: "Ñ", name: "opaque", version: 1, tones: nil, spanishName: "piña"),
      Emoji(value: "V", name: "opaque", version: 1, tones: nil, spanishName: "árbol"),
    ])
    #expect(search.search("pina").map(\.value) == ["N"])
    for query in ["PIÑA", "pin\u{0303}a", "piñ"] { #expect(search.search(query).map(\.value) == ["Ñ"]) }
    #expect(search.search("arbol").map(\.value) == ["V"])
    #expect(search.search("ÁRBOL").map(\.value) == ["V"])
    #expect(search.search("piña xyz").isEmpty)
    #expect(search.search("123 !!!").isEmpty)
  }

  @Test func embeddedNulUsesTheActualFoundationOperationForQueriesAndAliases() {
    let locale = Locale(identifier: "en_US_POSIX")
    let search = index([
      Emoji(value: "L", name: "opaque", version: 1, tones: nil, spanishName: "a b"),
      Emoji(value: "M", name: "opaque", version: 1, tones: nil, spanishName: "ab cd"),
    ])
    // Follow the operation on the executing platform; macOS behavior is not an
    // assumption about iOS. An ASCII byte loop bypassed this operation entirely.
    for raw in ["A\u{0}B", "\u{0}AB", "AB\u{0}", "AB\u{0}absent", "A\u{0}B A"] {
      let canonical = raw.lowercased(with: locale).decomposedStringWithCanonicalMapping
      for cap in [1, 48, 60] {
        #expect(search.search(raw, limit: cap).map(\.value) == search.search(canonical, limit: cap).map(\.value))
      }
    }
    let rawName = "cobre\u{0}linterna"
    let literal = index([Emoji(value: "L", name: "opaque", version: 1, tones: nil, spanishName: rawName)])
    let reference = index([Emoji(value: "L", name: "opaque", version: 1, tones: nil,
                                 spanishName: rawName.lowercased(with: locale).decomposedStringWithCanonicalMapping)])
    for query in ["cobre", "linterna", "cobre linterna", "COBRE", "linterna cobre"] {
      #expect(literal.search(query).map(\.value) == reference.search(query).map(\.value))
    }
  }

  @Test func localizationKeepsEnglishContextualAndSingleAsciiBehavior() {
    let entries = [
      Emoji(value: "A", name: "vicuña", version: 1, tones: nil, keywords: ["beacon"], spanishName: "llama"),
      Emoji(value: "B", name: "copper lantern", version: 1, tones: nil, keywords: ["beacon"], spanishName: "teclado"),
    ]
    let search = index(entries), legacy = englishOnly(entries)
    for query in ["vicuna", "VICUÑA", "vicun\u{0303}a", "beacon", "copper", "copper lantern", "t", "T", "(t)", "t t", "t't"] {
      let baseline = legacy.search(query).map(\.value), found = search.search(query).map(\.value)
      #expect(Array(found.prefix(baseline.count)) == baseline)
      if ["t", "T", "(t)", "t t", "t't"].contains(query) { #expect(found == baseline) }
      #expect(search.suggestions(for: query).map(\.value) == legacy.suggestions(for: query).map(\.value))
      #expect(search.suggestions(for: query, prefixes: false).map(\.value) == legacy.suggestions(for: query, prefixes: false).map(\.value))
    }
    #expect(search.search("teclado").map(\.value) == ["B"])
    #expect(search.suggestions(for: "teclado").isEmpty)
    #expect(search.search(String(repeating: "t", count: 81)).isEmpty)
    #expect(search.search("teclado", limit: 0).isEmpty)
    #expect(search.search("teclado", limit: -1).isEmpty)
  }

  @Test func canonicalTrancheStaysFixedWhenEnglishOrderAndOccupancyChange() {
    let english = (0..<18).map {
      Emoji(value: "E\($0)", name: $0 % 2 == 0 ? "red heart" : "heart red", version: 1, tones: nil)
    }
    let local = (0..<96).map {
      Emoji(value: "L\($0)", name: "opaque", version: 1, tones: nil, spanishName: "red heart")
    }
    let entries = english + local, search = index(entries), legacy = englishOnly(entries)
    for cap in [1, 48, 60] {
      let expected = (0..<max(0, cap - 18)).map { "L\($0)" }
      for query in ["red heart", "heart red", "heart red heart", "RED HEART"] {
        for preferred in [[:], ["E17": 1_000_000, "L95": 1_000_000, "E0": -1_000_000]] {
          let baseline = legacy.search(query, limit: cap, preferring: preferred).map(\.value)
          let found = search.search(query, limit: cap, preferring: preferred).map(\.value)
          #expect(Array(found.prefix(baseline.count)) == baseline)
          #expect(Array(found.dropFirst(baseline.count)) == expected)
          #expect(found.count <= cap)
          #expect(Set(found).count == found.count)
        }
      }
    }
  }

  @Test func exactFoldedNamesReserveCapacityWhenNormalizedWordsDiffer() {
    let entries = [
      Emoji(value: "E", name: "\u{0D4E}'", version: 1, tones: nil),
      Emoji(value: "L", name: "opaque", version: 1, tones: nil, spanishName: "\u{0D4E}"),
      Emoji(value: "M", name: "\u{093E}ñ", version: 1, tones: nil),
      Emoji(value: "N", name: "opaque", version: 1, tones: nil, spanishName: "ñavoru"),
    ]
    let search = index(entries), legacy = englishOnly(entries)
    for query in ["\u{0D4E}' ", "\t\u{093E}ñ"] {
      for cap in [1, 48, 60] {
        let baseline = legacy.search(query, limit: cap).map(\.value), found = search.search(query, limit: cap).map(\.value)
        #expect(!baseline.isEmpty)
        #expect(Array(found.prefix(baseline.count)) == baseline)
        #expect(found.count <= cap)
        #expect(Set(found).count == found.count)
      }
    }
    #expect(search.search("\u{0D4E}", limit: 1).map(\.value) == ["L"])
  }

  @Test func localizedWrapperUsesPreferredToneWithoutWritingHistory() throws {
    let search = index([Emoji(value: "👍", name: "thumbs up", version: 1, tones: ["👍🏽"],
                              spanishName: "pulgar hacia arriba")])
    let suite = "EmojiLocalizedSearchTests-\(UUID())"
    let defaults = try #require(UserDefaults(suiteName: suite))
    defer { defaults.removePersistentDomain(forName: suite) }
    let history = EmojiHistory(defaults: defaults)
    let base = try #require(search.emoji(for: "👍🏽"))
    history.setPreferred("👍🏽", for: base)
    let found = EmojiSearch.results(for: EmojiSearchQuery("pulgar"), suggester: search, history: history)
    #expect(found.map(\.value) == ["👍🏽"])
    #expect(found.map(\.base.value) == ["👍"])
    #expect(history.recents.isEmpty)
    history.use(found[0].value)
    #expect(history.recents == ["👍🏽"])
  }
}
