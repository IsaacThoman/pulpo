"""Synthetic harness checks only: no product, worker, or sealed schedule execution."""
import errno, importlib.util, io, json, os
from pathlib import Path
from unittest.mock import patch
P=Path('/tmp/pulpo-r33-blind')
R=Path('/Users/isaacthoman/.t3/worktrees/pulpo/t3-75300fc6/apps/keyboard-ios/audits/learning-reset-r33')
def load(version):
 spec=importlib.util.spec_from_file_location('runner_'+version,R/('run-'+version+'.py'))
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
m=load('v5'); results=[]
def check(name,fn):
 try: fn(); results.append({'name':name,'pass':True})
 except Exception as e: results.append({'name':name,'pass':False,'error':type(e).__name__+': '+str(e)})
BUSY={'completed':False,'dictionary':'busy'}
OK={'completed':True,'dictionary':'ok'}
NEW_OK={'dictionary':'ok','touch':'ok'}
NEW_BUSY={'dictionary':'busy','touch':'busy'}
COMMAND={'op':'save','store':'dictionary'}
ERRORS=[TimeoutError('synthetic response deadline'),json.JSONDecodeError('synthetic malformed reply','?',0),BrokenPipeError('synthetic pipe failure'),RuntimeError('synthetic stdout closed'),OSError('synthetic transport error'),KeyError('synthetic missing response key')]
class SequenceActor:
 def __init__(self,items):self.items=iter(items);self.commands=[]
 def command(self,command):
  self.commands.append(command);item=next(self.items)
  if isinstance(item,Exception):raise item
  return item

def retry_exception(error,initial=False):
 actor=SequenceActor([NEW_BUSY if initial else BUSY,error])
 try:m.await_expected(actor,{'op':'new'} if initial else COMMAND,NEW_BUSY if initial else BUSY,NEW_OK if initial else OK,initial)
 except m.RetryInterrupted as exc:
  assert exc.__cause__ is error
  assert len(exc.retries)==2
  assert all(h['actual']==(NEW_BUSY if initial else BUSY) for h in exc.retries)
  assert actor.commands==([{'op':'reload','store':'both'}]*2 if initial else [COMMAND]*2)
 else:raise AssertionError('exception not retained')
for error in ERRORS:check('await_retry_'+type(error).__name__,lambda e=error:retry_exception(e))
check('constructor_reload_retry_exception_history',lambda:retry_exception(TimeoutError('synthetic reload deadline'),True))

def success_history():
 a=SequenceActor([BUSY,OK]);actual,history=m.await_expected(a,COMMAND,BUSY,OK)
 assert actual==OK and len(history)==2 and len(a.commands)==2
check('busy_then_success_retains_all_history',success_history)

def nonbusy_result(result):
 actual={'completed':False,'dictionary':result};a=SequenceActor([])
 final,history=m.await_expected(a,COMMAND,actual,OK)
 assert final==actual and history==[] and a.commands==[]
for result in ['io','capacity','invalid','uncertain','cleanup']:
 check('never_retry_'+result,lambda r=result:nonbusy_result(r))
def expected_busy():
 a=SequenceActor([]);actual,history=m.await_expected(a,COMMAND,BUSY,BUSY)
 assert actual==BUSY and history==[] and a.commands==[]
check('expected_busy_not_retried',expected_busy)

def attempt_limit():
 a=SequenceActor([BUSY]*5000)
 with patch.object(m.time,'monotonic',return_value=0),patch.object(m.os,'sched_yield') as yielding:
  try:m.await_expected(a,COMMAND,BUSY,OK)
  except m.BusyDeadline as exc:
   assert len(exc.retries)==5000 and len(a.commands)==4999 and yielding.call_count==4999
  else:raise AssertionError('missing bounded deadline')
check('5000_attempt_limit_preserves_history',attempt_limit)

def time_limit():
 a=SequenceActor([])
 with patch.object(m.time,'monotonic',side_effect=[0,5]):
  try:m.await_expected(a,COMMAND,BUSY,OK)
  except m.BusyDeadline as exc:assert len(exc.retries)==1 and a.commands==[]
  else:raise AssertionError('missing five-second limit')
check('five_second_limit_preserves_history',time_limit)

def yield_error():
 a=SequenceActor([])
 with patch.object(m.os,'sched_yield',side_effect=OSError('synthetic yield error')):
  try:m.await_expected(a,COMMAND,BUSY,OK)
  except m.RetryInterrupted as exc:assert len(exc.retries)==1 and isinstance(exc.__cause__,OSError)
  else:raise AssertionError('missing wrapped yield error')
check('yield_exception_preserves_history',yield_error)

def malformed_reload():
 a=SequenceActor([{'dictionary':{'result':'ok'}}])
 try:m.await_expected(a,{'op':'new'},NEW_BUSY,NEW_OK,True)
 except m.RetryInterrupted as exc:assert len(exc.retries)==1 and isinstance(exc.__cause__,KeyError)
 else:raise AssertionError('missing malformed reload failure')
check('constructor_reload_shape_exception_preserves_history',malformed_reload)

class CaseActor(SequenceActor):
 plan=[];initial_plan=NEW_OK;instances=[]
 def __init__(self,*unused):
  super().__init__(self.plan);self.initial=self.initial_plan;self.closed=False
  self.p=type('FakeProcess',(),{'stdin':io.StringIO()})();self.instances.append(self)
 def read(self):return BUSY
 def close(self):self.closed=True

def case_failure(error,mode='command'):
 CaseActor.instances=[];CaseActor.initial_plan=NEW_BUSY if mode=='new' else NEW_OK
 CaseActor.plan=[BUSY,error] if mode=='command' else [error]
 new={'op':'new','actor':'synthetic','expected':NEW_OK}
 failure=dict(COMMAND,actor='synthetic',expected=OK)
 actions=[new,failure]
 if mode=='new':actions=[new]
 if mode=='receive':
  actions=[new,{'op':'send','actor':'synthetic','action':COMMAND},{'op':'receive','actor':'synthetic','expected':OK}]
 with patch.object(m,'Actor',CaseActor):r=m.run_case({'id':'synthetic','actions':actions},'unused-worker','unused-dylib')
 assert r['available'] is False and r['pass'] is False
 event=r['events'][-1];assert event['command']==actions[-1] and event['unavailable']==r['unavailable']
 assert len(event['confirmedBusyRetries'])==(2 if mode=='command' else 1)
 assert all(a.closed for a in CaseActor.instances)
 assert type(error).__name__ in r['unavailable']
for error in ERRORS:check('run_case_logs_'+type(error).__name__,lambda e=error:case_failure(e))
check('run_case_logs_constructor_reload_timeout',lambda:case_failure(TimeoutError('synthetic'),'new'))
check('run_case_logs_receive_retry_timeout',lambda:case_failure(TimeoutError('synthetic'),'receive'))

def initial_command_error():
 CaseActor.plan=[BrokenPipeError('synthetic first command')];CaseActor.initial_plan=NEW_OK
 actions=[{'op':'new','actor':'synthetic','expected':NEW_OK},dict(COMMAND,actor='synthetic',expected=OK)]
 with patch.object(m,'Actor',CaseActor):r=m.run_case({'id':'synthetic','actions':actions},'unused','unused')
 assert not r['available'] and not r['pass'] and r['events'][-1]['command']==actions[-1]
 assert r['events'][-1]['confirmedBusyRetries']==[]
check('first_command_error_has_failure_event',initial_command_error)

class FakeProcess:
 instances=[]
 def __init__(self,*args,**kwargs):
  self.stdin=io.StringIO();self.stdout=io.StringIO();self.stderr=io.StringIO();self.killed=False;self.waited=False;self.instances.append(self)
 def poll(self):return None
 def kill(self):self.killed=True
 def wait(self,timeout):self.waited=True;return -9

def constructor_cleanup(error):
 captured=[];real_pipe=os.pipe
 def pipe():
  pair=real_pipe();captured.extend(pair);return pair
 with patch.object(m.os,'pipe',side_effect=pipe),patch.object(m.subprocess,'Popen',FakeProcess),patch.object(m.Actor,'read',side_effect=error):
  try:m.Actor('unused','unused','unused',False)
  except type(error):pass
  else:raise AssertionError('constructor failure swallowed')
 process=FakeProcess.instances[-1]
 assert process.killed and process.waited
 assert all(stream.closed for stream in [process.stdin,process.stdout,process.stderr])
 for fd in captured:
  try:os.fstat(fd)
  except OSError as e:assert e.errno==errno.EBADF
  else:raise AssertionError('construction leaked pipe')
for error in ERRORS[:2]+[ERRORS[3]]:
 check('post_spawn_construction_cleanup_'+type(error).__name__,lambda e=error:constructor_cleanup(e))

def old_regression(version):
 old=load(version);actor=SequenceActor([TimeoutError('synthetic retry timeout')])
 try:old.await_expected(actor,COMMAND,BUSY,OK)
 except TimeoutError as e:assert not hasattr(e,'retries')
 else:raise AssertionError('old failure path not reproduced')
for version in ['v3','v4']:check(version+'_historical_retry_loss_reproduced',lambda v=version:old_regression(v))
report={'scope':'Synthetic actors and mocked process objects only. No real worker/product/process launch and no sealed case executed.','tests':len(results),'passed':sum(r['pass'] for r in results),'failed':sum(not r['pass'] for r in results),'results':results}
(P/'reseal-v5-fake-tests.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['tests','passed','failed','scope']}))
assert report['failed']==0
