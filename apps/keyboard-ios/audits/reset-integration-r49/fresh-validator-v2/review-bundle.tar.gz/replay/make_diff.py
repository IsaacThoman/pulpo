#!/usr/bin/env python3
"""Preexecution provenance helper; does not authorize postfreeze modification.
The explicit approved immutable v1 author archive is the sole baseline input.
"""
from pathlib import Path
import difflib,hashlib,json,tarfile
D=Path(__file__).resolve().parent
BASE=Path('/tmp/pulpo-r49-fresh-author-v1/author-bundle.tar.gz')
SKIP={'author-manifest.json','metadata.json','author-bundle.tar.gz','v1-v2.diff','v1-v2-files.json','reference-tool'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 if sha(BASE.read_bytes())!='bfa62181addfade8b2e0011c059b7608941cddf4c53e9876294071b412f15fe4':raise RuntimeError('v1 baseline altered')
 with tarfile.open(BASE,'r:gz') as archive:
  old={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile() and m.name not in SKIP}
 new={p.name:p.read_bytes() for p in D.iterdir() if p.is_file() and p.name not in SKIP and not p.name.startswith('.')}
 rows=[]
 with (D/'v1-v2.diff').open('w') as diff:
  for name in sorted(set(old)|set(new)):
   a=old.get(name);b=new.get(name);state='unchanged' if a==b else 'added' if a is None else 'removed' if b is None else 'modified'
   rows.append({'file':name,'state':state,'v1_sha256':sha(a) if a is not None else None,'v2_sha256':sha(b) if b is not None else None})
   if a!=b:
    diff.writelines(difflib.unified_diff(a.decode().splitlines(keepends=True) if a is not None else [],b.decode().splitlines(keepends=True) if b is not None else [],fromfile='v1/'+name if a is not None else '/dev/null',tofile='v2/'+name if b is not None else '/dev/null',n=3))
 result={'format':'pulpo-r49-exact-v1-v2-file-delta','baseline_archive_sha256':sha(BASE.read_bytes()),'scope':'Every baseline/new author artifact except derived self-referential seal/metadata/archive/diff files and unretained Foundation convenience executable. All excluded derived seals are separately bound by v2 manifest/archive metadata. Added files have full contents in unified diff and archive.','excluded_derived_names':sorted(SKIP),'files':rows}
 (D/'v1-v2-files.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'result':'pass','unchanged':sum(r['state']=='unchanged' for r in rows),'modified':sum(r['state']=='modified' for r in rows),'added':sum(r['state']=='added' for r in rows),'removed':sum(r['state']=='removed' for r in rows),'diff_bytes':(D/'v1-v2.diff').stat().st_size},sort_keys=True))
if __name__=='__main__':main()
