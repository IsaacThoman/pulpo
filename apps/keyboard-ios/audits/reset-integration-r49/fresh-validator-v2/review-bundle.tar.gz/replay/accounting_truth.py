"""Independent synthetic facts, not imported by the evaluator or runner.
Comprehension-based inventory over literal synthetic rows provides countertruth;
well-formed cases are separately fixed to expected exit codes in declarations.
Strict-invalid inputs deliberately have no validated observed fact set.
"""
from pathlib import Path
import copy,json,collections
D=Path(__file__).resolve().parent

def apply(value,p):
 target=value
 for k in p['path'][:-1]:target=target[k]
 key=p['path'][-1]
 if p['action']=='set':target[key]=copy.deepcopy(p['value'])
 elif p['action']=='delete':del target[key]
 elif p['action']=='append':target[key].append(copy.deepcopy(p['value']))
 else:raise RuntimeError('unknown patch')

def facts(rows,fixture,spec):
 look={r['id']:r for r in rows};ids=[o['id'] for o in fixture];learn=[o['id'] for o in fixture if o['op']=='learn'];fired=[id for id in ids if look[id]['invoked']];calls=[id for id in learn if id in fired]
 matchaccept=[id for id in calls if look[id]['available'] and (spec[id]['returned'],look[id]['returned'],look[id]['status'])==(True,True,'ok')]
 matchinvalid=[id for id in calls if look[id]['available'] and (spec[id]['returned'],spec[id]['status'],look[id]['returned'],look[id]['status'])==(False,'invalid',False,'invalid')]
 outcomes=[{'id':id,'returned':look[id]['returned'],'status':look[id]['status'],'available':look[id]['available'],'expected_returned':spec[id]['returned'],'expected_status':spec[id]['status'],'classification':'verified_expected_acceptance' if id in matchaccept else 'verified_intended_invalid_rejection' if id in matchinvalid else 'unavailable_outcome' if not look[id]['available'] else 'unexpected_outcome'} for id in calls]
 statuses=[{'id':id,'status':look[id]['status'],'available':look[id]['available'],'expected_status':spec[id]['status'],'unexpected':look[id]['status']!=spec[id]['status']} for id in fired if look[id]['session'] is not None and look[id]['status'] is not None]
 lists={
 'actual_invocation':fired,
 'actual_learn_call':calls,
 'observed_true_learn_return':[id for id in calls if look[id]['returned'] is True],
 'observed_true_ok_learn_outcome':[id for id in calls if look[id]['returned'] is True and look[id]['status']=='ok'],
 'verified_expected_accepted_learn':matchaccept,
 'verified_intended_invalid_rejection':matchinvalid,
 'unexpected_learn_outcome':[id for id in calls if look[id]['returned'] is not None and (look[id]['returned'] is not spec[id]['returned'] or look[id]['status'] is not None and look[id]['status']!=spec[id]['status'])],
 'unavailable_operation':[id for id in ids if not look[id]['available']],
 'unfired_operation':[id for id in ids if id not in fired],
 'unknown_learn_outcome':[id for id in learn if not look[id]['available'] or id not in fired],
 'unknown_invoked_model_status':[id for id in fired if look[id]['session'] is not None and look[id]['status'] is None],
 'unexpected_observed_status':[r['id'] for r in statuses if r['unexpected']],
 'unexpected_storage_status':[r['id'] for r in statuses if r['status'] in ('busy','capacity','io','uncertain','cleanup')]}
 observed={key+suffix:value for name,values in lists.items() for key,suffix,value in [(name,'_count',len(values)),(name,'_ids',values)]}
 counted=collections.Counter(r['status'] for r in statuses);observed['status_counts']={s:counted[s] for s in ('ok','invalid','busy','capacity','io','uncertain','cleanup')};observed['status_ledger']=statuses;observed['learn_outcome_ledger']=outcomes
 return observed

def main():
 f=json.loads((D/'fixtures.json').read_text())['operations'];spec=json.loads((D/'expectations.json').read_text())['operations'];base=json.loads((D/'synthetic-raw.json').read_text());cases=json.loads((D/'accounting-witnesses.json').read_text());expected={}
 baseline=facts(base['operations'],f,spec)
 fixed={'actual_invocation_count':452,'actual_learn_call_count':80,'verified_expected_accepted_learn_count':49,'verified_intended_invalid_rejection_count':31}
 for k,v in fixed.items():
  if baseline[k]!=v:raise RuntimeError('independent baseline fixed fact '+k)
 if baseline['status_counts']!={'ok':354,'invalid':58,'busy':0,'capacity':0,'io':0,'uncertain':0,'cleanup':0}:raise RuntimeError('independent baseline status facts')
 for c in cases:
  value=copy.deepcopy(base)
  for p in c['patches']:apply(value,p)
  expected[c['id']]={'exit':c['expected_exit'],'known':c['expected_exit']!=2,'observed':facts(value['operations'],f,spec) if c['expected_exit']!=2 else None,'unknown_operation_ids':[] if c['expected_exit']!=2 else [o['id'] for o in f]}
 planned={'operations':452,'learn_calls':80,'expected_accepted_learn_calls':49,'intended_invalid_learn_calls':31}
 (D/'accounting-countertruth.json').write_text(json.dumps({'format':'pulpo-r49-synthetic-countertruth-v2','planned':planned,'cases':expected},indent=2,allow_nan=False)+'\n')
if __name__=='__main__':main()
