from pathlib import Path
import json,copy,io,sys,contextlib,tempfile,gzip,hashlib
D=Path('/tmp/pulpo-r49-fresh-validator-v2');A=Path('/tmp/pulpo-r49-fresh-author-v2');ns={};exec(compile((D/'independent-counterchecks.py').read_text().split('results=[];raw_archive=')[0],'counter-reference','exec'),ns)
truth=ns['truth'];validate=ns['validate'];need=ns['need'];base=ns['base'];f=ns['f'];m=ns['m'];mode='optimized' if sys.flags.optimize else 'normal';cases=[];results=[]
for op in ['construct','reopen','reload']:
 index=next(i for i,o in enumerate(f) if o['op']==op and o.get('session') and '.persistent' in o['session'])
 for available in [False,True]:
  for invoked in [False,True]:
   for status in [None,*ns['statuses']]:
    v=copy.deepcopy(base);v['operations'][index].update(available=available,invoked=invoked,status=status,error=None if available else 'independent unavailable read')
    wanted=2 if available and invoked and status is None else 0 if available and invoked and status=='ok' else 1
    cases.append((op+'_'+str(available)+'_'+str(invoked)+'_'+str(status),v,wanted))
# Entire unavailable schedule: zeros and stale ok are not a successful workload.
v=copy.deepcopy(base)
for r in v['operations']:r.update(available=False,invoked=False,error='independent all blocked',returned=None,status=None,state=None,resolvedInput=None,files=[])
cases.append(('all_unavailable_unfired',v,1))
# Constructor state exists but inventory unavailable, despite status ok.
v=copy.deepcopy(base)
for r in v['operations']:
 if r['op']=='construct':r.update(available=False,error='independent inventory unavailable')
cases.append(('all_constructors_unavailable',v,1))
with tempfile.TemporaryDirectory(dir=D) as tmp,gzip.open(D/('read-evidence-inputs-'+mode+'.jsonl.gz'),'wt') as g:
 path=Path(tmp)/'raw.json'
 for name,v,want in cases:
  s=json.dumps(v,separators=(',',':'));path.write_text(s);old=sys.argv;sys.argv=['evaluate.py',str(path)];cap=io.StringIO()
  try:
   with contextlib.redirect_stdout(cap):code=m.main()
  finally:sys.argv=old
  need(code==want,name+' exit');report=json.loads(cap.getvalue());validate(report,truth(v,code));sha=hashlib.sha256(s.encode()).hexdigest();g.write(json.dumps({'id':name,'raw_sha256':sha,'raw':v},separators=(',',':'))+'\n');results.append({'id':name,'exit':code,'raw_sha256':sha,'report':report})
  if name=='all_unavailable_unfired':
   o=report['accounting']['observed'];need(o['actual_invocation_count']==0 and o['actual_learn_call_count']==0 and o['verified_expected_accepted_learn_count']==0 and o['verified_intended_invalid_rejection_count']==0 and o['unavailable_operation_count']==452 and o['unfired_operation_count']==452,'all unavailable false success')
(D/('read-evidence-results-'+mode+'.json')).write_text(json.dumps({'mode':mode,'cases':len(results),'results':results,'synthetic_only':True},indent=2)+'\n');print(json.dumps({'mode':mode,'read_evidence_cases':len(results),'counters_match':True}))
