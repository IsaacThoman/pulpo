import json, pathlib
P=pathlib.Path('/tmp/pulpo-r48-fresh-author-v2')
def pt(k='a',x=.13,y=-.07): return {'base':k,'dx':x,'dy':y}
def learn(text,target,taps):return {'op':'learn','text':text,'target':target,'taps':taps}
f=[]
def add(id,intent,text,target,taps,more=None):f.append({'id':id,'intent':intent,'normalizationInput':text,'steps':[learn(text,target,taps)]+(more or [])})
add('ascii_bytes','ASCII apostrophe removal preserves NUL, controls and punctuation',"A'B\x00_9\n",'ab\x00_9\n',[pt('a'),pt(),pt('b'),None,None,None,None])
add('accent_marks','Complete and Character Latin diacritic removal','PÍÑATA','pinata',[pt(k) for k in 'pinata'])
add('compat_expansion','One compatibility ligature supplies multiple aligned bytes','raﬄe','raffle',[pt('r'),pt('a'),pt('f'),pt('l'),pt('e')])
add('curly_removal','Removed standalone curly apostrophe consumes its original point',"d’Árte",'darte',[pt('d'),{'x':'nan','y':0},pt('a'),pt('r'),pt('t'),pt('e')])
add('spacing_mark','Spacing mark bytes remain but do not sample','a\u0903b','a\u0903b',[pt('a'),pt('b')])
add('enclosing_mark','Enclosing mark retained within one original Character','u\u20ddv','u\u20ddv',[pt('u'),pt('v')])
add('format_character','Joiner bytes retained while adjacent letters contribute','p\u200dq','p\u200dq',[pt('p'),pt('q')])
add('sparse_decomposed','Decomposed grapheme uses Character indexing with missing tail points','e\u0301xtra','extra',[pt('e'),None,pt('t')])
add('target_relocation','Displacements use intended target centers despite spelling difference','nube','lago',[pt(k) for k in 'lago'])
add('short_target','Normalized target below two bytes rejects without teaching',"’A",'a',[None,pt('a')])
add('length_mismatch','Compatibility expansion length mismatch rejects','ﬄa','fla',[pt('f'),pt('a')])
add('zero_samples','Matching length containing only target nonletters rejects','ab','73',[pt('a'),pt('b')])
add('late_nonfinite','Later contributing infinite displacement rejects all earlier samples','vale','vale',[pt('v'),pt('a'),pt('l'),{'x':'posInf','y':0}])
add('ignored_nonfinite','Nonfinite taps on punctuation and extra positions are ignored','a-b','a-b',[pt('a'),{'x':'negInf','y':'nan'},pt('b'),{'x':'nan','y':'posInf'}])
add('missing_points','No taps produces zero contributions despite letter target','sol','sol',[])
add('learning_policy','Disabled learning rejects and reenabled learning resumes','cima','cima',[pt(k) for k in 'cima'])
f[-1]['steps']=[{'op':'setLearning','value':False}]+f[-1]['steps']+[{'op':'setLearning','value':True},learn('cima','cima',[pt(k) for k in 'cima'])]
add('sample_cap','Actual samples at forty accepted and forty one local only','a'*40,'a'*40,[pt('a',.23,.09)]*40,[learn('b'*41,'b'*41,[pt('b',-.16,.12)]*41)])
add('long_sparse','Target beyond forty bytes accepted with forty actual finite samples','c'*57,'c'*57,[pt('c',.11,-.19)]*40)
# Include exact normalization reference cases tied to every family; no API examples from map.
(P/'design.json').write_text(json.dumps({'families':f},ensure_ascii=False,indent=2)+'\n')
